import type { Response } from 'express';
import {
  calculateSleepDuration,
  calculateTimeRangeHours,
  getLocalDateStr,
  parseTimeToMinutes,
} from '../../src/shared/math.ts';
import { logger } from '../config/logger.ts';
import type { AuthenticatedRequest } from '../middleware/requestLogger.ts';

export function isValidDateStr(dateStr: unknown): dateStr is string {
  if (typeof dateStr !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) return false;
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

export function isFutureDate(dateStr: string): boolean {
  return dateStr > getLocalDateStr(0);
}

export function isValidTimeStr(timeStr: unknown): timeStr is string {
  return typeof timeStr === 'string' && !Number.isNaN(parseTimeToMinutes(timeStr));
}

export function parsePositiveIntId(raw: string): number | null {
  if (!/^\d+$/.test(raw)) return null;
  const num = Number(raw);
  return Number.isSafeInteger(num) && num > 0 ? num : null;
}

export function parseDaysWindow(raw: unknown): number {
  const num = Number(raw);
  return Number.isInteger(num) && [7, 14, 21, 30].includes(num) ? num : 21;
}

export function sendValidationError(
  res: Response,
  req: AuthenticatedRequest,
  status: number,
  message: string,
): void {
  logger.warn('Input validation error', {
    method: req.method,
    path: req.path,
    userId: req.authUser?.id ?? null,
    statusCode: status,
    reason: message,
  });
  res.status(status).json({ error: message });
}

export type ValidationOutcome<T> = { ok: true; data: T } | { ok: false; status: number; message: string };

export interface ValidatedSleepPayload {
  date: string;
  bedtime: string;
  wakeTime: string;
  duration: number;
  sleepQuality: number;
  notes: string;
}

export function validateSleepPayload(body: Record<string, unknown> | undefined): ValidationOutcome<ValidatedSleepPayload> {
  const { date, bedtime, wakeTime, sleepQuality, notes = '' } = body ?? {};
  if (!isValidDateStr(date)) {
    return { ok: false, status: 400, message: 'Valid date (YYYY-MM-DD) is required.' };
  }
  if (isFutureDate(date)) {
    return { ok: false, status: 400, message: 'Future dates cannot be logged for sleep records.' };
  }
  if (!isValidTimeStr(bedtime) || !isValidTimeStr(wakeTime)) {
    return {
      ok: false,
      status: 400,
      message: 'Valid bedtime and wake-up time (HH:mm) are required.',
    };
  }
  const quality = Number(sleepQuality);
  if (!Number.isInteger(quality) || quality < 1 || quality > 5) {
    return {
      ok: false,
      status: 400,
      message: 'Sleep quality rating must be an integer between 1 and 5.',
    };
  }
  const duration = calculateSleepDuration(bedtime, wakeTime);
  if (duration < 0.25 || duration > 20) {
    return {
      ok: false,
      status: 400,
      message:
        'Calculated sleep duration must be between 15 minutes and 20 hours. Check bedtime and wake-up time.',
    };
  }

  return {
    ok: true,
    data: {
      date,
      bedtime,
      wakeTime,
      duration,
      sleepQuality: quality,
      notes: String(notes ?? '').trim(),
    },
  };
}

export interface ValidatedStudyPayload {
  date: string;
  subject: string;
  studyHours: number;
  focusRating: number;
  startTime: string;
  endTime: string;
  notes: string;
}

export function validateStudyPayload(body: Record<string, unknown> | undefined): ValidationOutcome<ValidatedStudyPayload> {
  const {
    date,
    subject,
    studyHours,
    focusRating,
    startTime = '',
    endTime = '',
    notes = '',
  } = body ?? {};

  if (!isValidDateStr(date)) {
    return { ok: false, status: 400, message: 'Valid date (YYYY-MM-DD) is required.' };
  }
  if (isFutureDate(date)) {
    return { ok: false, status: 400, message: 'Future dates cannot be logged for study sessions.' };
  }
  if (typeof subject !== 'string' || subject.trim().length === 0 || subject.trim().length > 80) {
    return { ok: false, status: 400, message: 'Subject name (1–80 characters) is required.' };
  }

  let hours = Number(studyHours);
  if ((!hours || Number.isNaN(hours)) && isValidTimeStr(startTime) && isValidTimeStr(endTime)) {
    hours = calculateTimeRangeHours(startTime, endTime);
  }
  if (Number.isNaN(hours) || hours < 0.25 || hours > 16) {
    return { ok: false, status: 400, message: 'Study duration must be between 0.25 and 16 hours.' };
  }

  const focus = Number(focusRating);
  if (!Number.isInteger(focus) || focus < 1 || focus > 5) {
    return {
      ok: false,
      status: 400,
      message: 'Focus rating must be an integer between 1 and 5.',
    };
  }

  return {
    ok: true,
    data: {
      date,
      subject: subject.trim(),
      studyHours: Math.round(hours * 100) / 100,
      focusRating: focus,
      startTime: String(startTime ?? ''),
      endTime: String(endTime ?? ''),
      notes: String(notes ?? '').trim(),
    },
  };
}
