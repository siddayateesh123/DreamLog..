import type { Response } from 'express';
import type { SqliteDatabase } from '../config/database.ts';
import type { AuthenticatedRequest } from '../middleware/requestLogger.ts';
import { SleepRepository } from '../repositories/sleepRepository.ts';
import { rebuildDailyMetricsForUser } from '../services/analyticsService.ts';
import {
  parsePositiveIntId,
  sendValidationError,
  validateSleepPayload,
} from './validation.ts';

export function createSleepController(db: SqliteDatabase) {
  const sleepRepo = new SleepRepository(db);

  return {
    list: (req: AuthenticatedRequest, res: Response) => {
      const userId = req.authUser!.id;
      res.json(sleepRepo.findAllByUser(userId));
    },

    create: (req: AuthenticatedRequest, res: Response) => {
      const userId = req.authUser!.id;
      const parsed = validateSleepPayload(req.body);
      if (!parsed.ok) {
        sendValidationError(res, req, parsed.status, parsed.message);
        return;
      }
      if (sleepRepo.findByDateForUser(parsed.data.date, userId)) {
        sendValidationError(
          res,
          req,
          409,
          `A sleep log for ${parsed.data.date} already exists. Please edit or delete the existing record instead.`,
        );
        return;
      }

      const created = db.transaction(() => {
        const row = sleepRepo.createForUser(userId, parsed.data);
        rebuildDailyMetricsForUser(db, userId);
        return row;
      })();
      res.status(201).json(created);
    },

    update: (req: AuthenticatedRequest, res: Response) => {
      const userId = req.authUser!.id;
      const id = parsePositiveIntId(req.params.id);
      if (id === null) {
        sendValidationError(res, req, 400, 'Invalid sleep log ID.');
        return;
      }
      if (!sleepRepo.findByIdForUser(id, userId)) {
        res.status(404).json({ error: 'Sleep log not found.' });
        return;
      }

      const parsed = validateSleepPayload(req.body);
      if (!parsed.ok) {
        sendValidationError(res, req, parsed.status, parsed.message);
        return;
      }
      if (sleepRepo.findByDateForUser(parsed.data.date, userId, id)) {
        sendValidationError(
          res,
          req,
          409,
          `Another sleep log already exists for ${parsed.data.date}. Delete or edit that record instead.`,
        );
        return;
      }

      const updated = db.transaction(() => {
        const row = sleepRepo.updateForUser(id, userId, parsed.data);
        rebuildDailyMetricsForUser(db, userId);
        return row;
      })();
      res.json(updated);
    },

    remove: (req: AuthenticatedRequest, res: Response) => {
      const userId = req.authUser!.id;
      const id = parsePositiveIntId(req.params.id);
      if (id === null) {
        sendValidationError(res, req, 400, 'Invalid sleep log ID.');
        return;
      }
      const deleted = db.transaction(() => {
        const ok = sleepRepo.deleteForUser(id, userId);
        if (ok) rebuildDailyMetricsForUser(db, userId);
        return ok;
      })();
      if (!deleted) {
        res.status(404).json({ error: 'Sleep log not found.' });
        return;
      }
      res.json({ deleted: true, id });
    },
  };
}
