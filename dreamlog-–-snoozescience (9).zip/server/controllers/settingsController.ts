import type { Response } from 'express';
import type { SqliteDatabase } from '../config/database.ts';
import type { AuthenticatedRequest } from '../middleware/requestLogger.ts';
import { SleepRepository } from '../repositories/sleepRepository.ts';
import { UserRepository } from '../repositories/userRepository.ts';
import { getDashboardAnalyticsForUser, rebuildDailyMetricsForUser } from '../services/analyticsService.ts';
import {
  clearDemoDataForUser,
  resetDemoDataForUser,
  resetDemoScenarioTodayForUser,
  runDemoScenarioTodayForUser,
  seedDemoDataForUser,
} from '../services/demoSeedService.ts';
import { isValidTimeStr } from './validation.ts';

export function createSettingsController(db: SqliteDatabase) {
  const userRepo = new UserRepository(db);
  const sleepRepo = new SleepRepository(db);

  return {
    getSettings: (req: AuthenticatedRequest, res: Response) => {
      res.json(userRepo.getSettings(req.authUser!.id));
    },

    updateSettings: (req: AuthenticatedRequest, res: Response) => {
      const userId = req.authUser!.id;
      const cur = userRepo.getSettings(userId);
      const {
        studentName = cur.studentName,
        sleepBaselineHours = cur.sleepBaselineHours,
        caffeineHalfLifeHours = cur.caffeineHalfLifeHours,
        preferredWakeTime = cur.preferredWakeTime,
        dailyAvailableHours = cur.dailyAvailableHours,
        onboardingDismissed = cur.onboardingDismissed,
      } = req.body ?? {};

      const safeBaseline = Math.max(5, Math.min(11, Number(sleepBaselineHours) || 8));
      const safeHalfLife = Math.max(2, Math.min(12, Number(caffeineHalfLifeHours) || 5));
      const safeDailyHours = Math.max(1, Math.min(8, Number(dailyAvailableHours) || 7));
      const safeWake = isValidTimeStr(preferredWakeTime)
        ? preferredWakeTime
        : cur.preferredWakeTime;

      const updated = userRepo.updateSettings(userId, {
        studentName: String(studentName).trim() || cur.studentName || 'Student',
        sleepBaselineHours: safeBaseline,
        caffeineHalfLifeHours: safeHalfLife,
        preferredWakeTime: safeWake,
        dailyAvailableHours: safeDailyHours,
        onboardingDismissed: Boolean(onboardingDismissed),
      });
      rebuildDailyMetricsForUser(db, userId);
      res.json(updated);
    },

    clearDemo: (req: AuthenticatedRequest, res: Response) => {
      clearDemoDataForUser(db, req.authUser!.id);
      res.json({ cleared: true });
    },

    resetDemo: (req: AuthenticatedRequest, res: Response) => {
      resetDemoDataForUser(db, req.authUser!.id);
      res.json({ reset: true });
    },

    runDemoScenario: (req: AuthenticatedRequest, res: Response) => {
      const userId = req.authUser!.id;
      if (sleepRepo.countDemoForUser(userId) === 0) {
        seedDemoDataForUser(db, userId);
      }
      runDemoScenarioTodayForUser(db, userId);
      res.json(getDashboardAnalyticsForUser(db, userId, 21));
    },

    resetDemoScenario: (req: AuthenticatedRequest, res: Response) => {
      const userId = req.authUser!.id;
      resetDemoScenarioTodayForUser(db, userId);
      res.json(getDashboardAnalyticsForUser(db, userId, 21));
    },
  };
}
