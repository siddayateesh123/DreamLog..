import type { Response } from 'express';
import { simulateSleepShift } from '../../src/shared/math.ts';
import type { SqliteDatabase } from '../config/database.ts';
import type { AuthenticatedRequest } from '../middleware/requestLogger.ts';
import { getDashboardAnalyticsForUser } from '../services/analyticsService.ts';
import { parseDaysWindow, sendValidationError } from './validation.ts';

export function createAnalyticsController(db: SqliteDatabase) {
  return {
    dashboard: (req: AuthenticatedRequest, res: Response) => {
      const days = parseDaysWindow(req.query.days);
      res.json(getDashboardAnalyticsForUser(db, req.authUser!.id, days));
    },

    correlation: (req: AuthenticatedRequest, res: Response) => {
      const days = parseDaysWindow(req.query.days);
      res.json(getDashboardAnalyticsForUser(db, req.authUser!.id, days).correlation);
    },

    sleepDebt: (req: AuthenticatedRequest, res: Response) => {
      const days = parseDaysWindow(req.query.days);
      res.json(getDashboardAnalyticsForUser(db, req.authUser!.id, days).sleepDebt);
    },

    weeklyInsights: (req: AuthenticatedRequest, res: Response) => {
      const days = parseDaysWindow(req.query.days);
      res.json(getDashboardAnalyticsForUser(db, req.authUser!.id, days).insights);
    },

    simulate: (req: AuthenticatedRequest, res: Response) => {
      const { sleepHours = 8, nights = 3, daysWindow = 21 } = req.body ?? {};
      const parsedSleep = Number(sleepHours);
      const parsedNights = Number(nights);
      if (Number.isNaN(parsedSleep) || parsedSleep < 4 || parsedSleep > 12) {
        sendValidationError(res, req, 400, 'Simulated sleepHours must be between 4 and 12.');
        return;
      }
      if (!Number.isInteger(parsedNights) || parsedNights < 1 || parsedNights > 14) {
        sendValidationError(
          res,
          req,
          400,
          'Simulated nights must be an integer between 1 and 14.',
        );
        return;
      }

      const analytics = getDashboardAnalyticsForUser(
        db,
        req.authUser!.id,
        parseDaysWindow(daysWindow),
      );
      const existingPoints = analytics.correlation.points.map((p) => ({ x: p.x, y: p.y }));
      res.json(simulateSleepShift(existingPoints, parsedSleep, parsedNights));
    },
  };
}
