import type { NextFunction, Response } from 'express';
import type { SqliteDatabase } from '../config/database.ts';
import { extractSessionToken, SESSION_COOKIE_NAME } from '../middleware/authMiddleware.ts';
import type { AuthenticatedRequest } from '../middleware/requestLogger.ts';
import { AuthError, AuthService } from '../services/authService.ts';
import { sendValidationError } from './validation.ts';

const COOKIE_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;

function isSecureRequest(req: AuthenticatedRequest): boolean {
  return req.secure || req.headers['x-forwarded-proto'] === 'https';
}

function setSessionCookie(req: AuthenticatedRequest, res: Response, token: string): void {
  res.cookie(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: isSecureRequest(req),
    path: '/',
    maxAge: COOKIE_MAX_AGE_MS,
  });
}

export function createAuthController(db: SqliteDatabase) {
  const authService = new AuthService(db);

  return {
    register: async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
      try {
        const { name = '', email = '', password = '' } = req.body ?? {};
        const result = await authService.register({
          name: String(name),
          email: String(email),
          password: String(password),
        });
        setSessionCookie(req, res, result.token);
        res.status(201).json(result);
      } catch (err) {
        if (err instanceof AuthError) {
          sendValidationError(res, req, err.statusCode, err.message);
          return;
        }
        next(err);
      }
    },

    login: async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
      try {
        const { email = '', password = '' } = req.body ?? {};
        const result = await authService.login({
          email: String(email),
          password: String(password),
        });
        setSessionCookie(req, res, result.token);
        res.json(result);
      } catch (err) {
        if (err instanceof AuthError) {
          sendValidationError(res, req, err.statusCode, err.message);
          return;
        }
        next(err);
      }
    },

    demoSession: (req: AuthenticatedRequest, res: Response) => {
      const result = authService.createDemoSession();
      setSessionCookie(req, res, result.token);
      res.json(result);
    },

    logout: (req: AuthenticatedRequest, res: Response) => {
      const token = extractSessionToken(req);
      authService.logout(token ?? undefined);
      res.clearCookie(SESSION_COOKIE_NAME, {
        httpOnly: true,
        sameSite: 'lax',
        secure: isSecureRequest(req),
        path: '/',
      });
      res.json({ loggedOut: true });
    },

    me: (req: AuthenticatedRequest, res: Response) => {
      if (!req.authUser) {
        res.json({ authenticated: false, user: null });
        return;
      }
      res.json({ authenticated: true, user: req.authUser });
    },
  };
}
