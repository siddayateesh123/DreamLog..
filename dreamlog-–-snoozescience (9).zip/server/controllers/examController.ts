import type { Response } from 'express';
import type { SqliteDatabase } from '../config/database.ts';
import type { AuthenticatedRequest } from '../middleware/requestLogger.ts';
import { ExamRepository } from '../repositories/examRepository.ts';
import { ExamPlannerService } from '../services/examPlannerService.ts';
import {
  isFutureDate,
  isValidDateStr,
  isValidTimeStr,
  parsePositiveIntId,
  sendValidationError,
} from './validation.ts';

export function createExamController(db: SqliteDatabase) {
  const examRepo = new ExamRepository(db);
  const plannerService = new ExamPlannerService(db);

  return {
    listExams: (req: AuthenticatedRequest, res: Response) => {
      res.json(examRepo.findExamsByUser(req.authUser!.id));
    },

    createExam: (req: AuthenticatedRequest, res: Response) => {
      const userId = req.authUser!.id;
      const {
        examDate,
        subject,
        topics,
        priority,
        estimatedHours = 5,
        topicDifficulty = 3,
      } = req.body ?? {};
      if (!isValidDateStr(examDate)) {
        sendValidationError(res, req, 400, 'Valid exam date (YYYY-MM-DD) is required.');
        return;
      }
      if (typeof subject !== 'string' || subject.trim().length === 0) {
        sendValidationError(res, req, 400, 'Subject name is required.');
        return;
      }
      if (!['High', 'Medium', 'Low'].includes(priority)) {
        sendValidationError(res, req, 400, 'Priority must be High, Medium, or Low.');
        return;
      }
      const est = Math.max(1, Math.min(40, Number(estimatedHours) || 5));
      const diff = Math.max(1, Math.min(5, Math.round(Number(topicDifficulty) || 3)));
      const created = examRepo.createExamForUser(userId, {
        examDate,
        subject: subject.trim(),
        topics: String(topics ?? '').trim(),
        priority,
        estimatedHours: est,
        topicDifficulty: diff,
      });
      res.status(201).json(created);
    },

    updateExam: (req: AuthenticatedRequest, res: Response) => {
      const userId = req.authUser!.id;
      const id = parsePositiveIntId(req.params.id);
      if (id === null) {
        sendValidationError(res, req, 400, 'Invalid exam ID.');
        return;
      }
      if (!examRepo.findExamByIdForUser(id, userId)) {
        res.status(404).json({ error: 'Exam record not found.' });
        return;
      }
      const {
        examDate,
        subject,
        topics,
        priority,
        estimatedHours = 5,
        topicDifficulty = 3,
      } = req.body ?? {};
      if (!isValidDateStr(examDate) || typeof subject !== 'string' || !subject.trim()) {
        sendValidationError(res, req, 400, 'Valid exam date and subject are required.');
        return;
      }
      if (!['High', 'Medium', 'Low'].includes(priority)) {
        sendValidationError(res, req, 400, 'Invalid priority.');
        return;
      }
      const est = Math.max(1, Math.min(40, Number(estimatedHours) || 5));
      const diff = Math.max(1, Math.min(5, Math.round(Number(topicDifficulty) || 3)));
      const updated = examRepo.updateExamForUser(id, userId, {
        examDate,
        subject: subject.trim(),
        topics: String(topics ?? '').trim(),
        priority,
        estimatedHours: est,
        topicDifficulty: diff,
      });
      res.json(updated);
    },

    deleteExam: (req: AuthenticatedRequest, res: Response) => {
      const userId = req.authUser!.id;
      const id = parsePositiveIntId(req.params.id);
      if (id === null) {
        sendValidationError(res, req, 400, 'Invalid exam ID.');
        return;
      }
      if (!examRepo.deleteExamForUser(id, userId)) {
        res.status(404).json({ error: 'Exam not found.' });
        return;
      }
      res.json({ deleted: true, id });
    },

    listPlanTasks: (req: AuthenticatedRequest, res: Response) => {
      res.json(examRepo.findPlanTasksByUser(req.authUser!.id));
    },

    generatePlan: (req: AuthenticatedRequest, res: Response) => {
      const userId = req.authUser!.id;
      const { dailyAvailableHours, preferredWakeTime } = req.body ?? {};
      const wake = isValidTimeStr(preferredWakeTime) ? preferredWakeTime : undefined;
      const hours = dailyAvailableHours !== undefined ? Number(dailyAvailableHours) : undefined;
      res.json(plannerService.generatePlan(userId, hours, wake));
    },

    rescheduleMissed: (req: AuthenticatedRequest, res: Response) => {
      const userId = req.authUser!.id;
      const { missedTaskIds, dailyAvailableHours, preferredWakeTime } = req.body ?? {};
      const ids = Array.isArray(missedTaskIds)
        ? missedTaskIds.map(Number).filter((n) => Number.isInteger(n) && n > 0)
        : undefined;
      const wake = isValidTimeStr(preferredWakeTime) ? preferredWakeTime : undefined;
      const hours = dailyAvailableHours !== undefined ? Number(dailyAvailableHours) : undefined;
      res.json(plannerService.rescheduleMissed(userId, ids, hours, wake));
    },

    getFeasibility: (req: AuthenticatedRequest, res: Response) => {
      res.json(plannerService.getFeasibility(req.authUser!.id));
    },

    updatePlanTask: (req: AuthenticatedRequest, res: Response) => {
      const userId = req.authUser!.id;
      const id = parsePositiveIntId(req.params.id);
      if (id === null) {
        sendValidationError(res, req, 400, 'Invalid timetable task ID.');
        return;
      }
      const existing = examRepo.findPlanTaskByIdForUser(id, userId);
      if (!existing) {
        res.status(404).json({ error: 'Timetable task not found.' });
        return;
      }
      const {
        completed = existing.completed,
        title = existing.title,
        startTime = existing.startTime,
        endTime = existing.endTime,
      } = req.body ?? {};

      if (typeof title !== 'string' || !title.trim() || title.trim().length > 160) {
        sendValidationError(
          res,
          req,
          400,
          'Task title must be a non-empty string up to 160 characters.',
        );
        return;
      }
      if (!isValidTimeStr(startTime) || !isValidTimeStr(endTime)) {
        sendValidationError(res, req, 400, 'Valid startTime and endTime (HH:mm) are required.');
        return;
      }

      const updated = examRepo.updatePlanTaskForUser(id, userId, {
        completed: Boolean(completed),
        title: title.trim(),
        startTime,
        endTime,
      });
      res.json(updated);
    },

    listExamResults: (req: AuthenticatedRequest, res: Response) => {
      res.json(examRepo.findExamResultsByUser(req.authUser!.id));
    },

    createExamResult: (req: AuthenticatedRequest, res: Response) => {
      const userId = req.authUser!.id;
      const { subject, examDate, scorePercent, notes = '' } = req.body ?? {};
      if (typeof subject !== 'string' || !subject.trim()) {
        sendValidationError(res, req, 400, 'Exam subject is required.');
        return;
      }
      if (!isValidDateStr(examDate) || isFutureDate(examDate)) {
        sendValidationError(
          res,
          req,
          400,
          'Valid non-future exam date (YYYY-MM-DD) is required.',
        );
        return;
      }
      const score = Number(scorePercent);
      if (Number.isNaN(score) || score < 0 || score > 100) {
        sendValidationError(res, req, 400, 'Exam score must be between 0 and 100.');
        return;
      }

      const created = examRepo.createExamResultForUser(userId, {
        subject: subject.trim(),
        examDate,
        scorePercent: Math.round(score * 10) / 10,
        notes: String(notes ?? '').trim(),
      });
      res.status(201).json(created);
    },

    updateExamResult: (req: AuthenticatedRequest, res: Response) => {
      const userId = req.authUser!.id;
      const id = parsePositiveIntId(req.params.id);
      if (id === null) {
        sendValidationError(res, req, 400, 'Invalid exam result ID.');
        return;
      }
      if (!examRepo.findExamResultByIdForUser(id, userId)) {
        res.status(404).json({ error: 'Exam result not found.' });
        return;
      }
      const { subject, examDate, scorePercent, notes = '' } = req.body ?? {};
      if (
        typeof subject !== 'string' ||
        !subject.trim() ||
        !isValidDateStr(examDate) ||
        isFutureDate(examDate)
      ) {
        sendValidationError(
          res,
          req,
          400,
          'Valid subject and non-future exam date are required.',
        );
        return;
      }
      const score = Number(scorePercent);
      if (Number.isNaN(score) || score < 0 || score > 100) {
        sendValidationError(res, req, 400, 'Exam score must be between 0 and 100.');
        return;
      }
      const updated = examRepo.updateExamResultForUser(id, userId, {
        subject: subject.trim(),
        examDate,
        scorePercent: Math.round(score * 10) / 10,
        notes: String(notes ?? '').trim(),
      });
      res.json(updated);
    },

    deleteExamResult: (req: AuthenticatedRequest, res: Response) => {
      const userId = req.authUser!.id;
      const id = parsePositiveIntId(req.params.id);
      if (id === null) {
        sendValidationError(res, req, 400, 'Invalid exam result ID.');
        return;
      }
      if (!examRepo.deleteExamResultForUser(id, userId)) {
        res.status(404).json({ error: 'Exam result not found.' });
        return;
      }
      res.json({ deleted: true, id });
    },
  };
}
