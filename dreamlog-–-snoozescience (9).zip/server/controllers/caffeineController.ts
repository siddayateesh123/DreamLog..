import type { Response } from 'express';
import type { SqliteDatabase } from '../config/database.ts';
import type { AuthenticatedRequest } from '../middleware/requestLogger.ts';
import { CaffeineRepository } from '../repositories/caffeineRepository.ts';
import {
  isFutureDate,
  isValidDateStr,
  isValidTimeStr,
  parsePositiveIntId,
  sendValidationError,
} from './validation.ts';

export function createCaffeineController(db: SqliteDatabase) {
  const caffeineRepo = new CaffeineRepository(db);

  return {
    list: (req: AuthenticatedRequest, res: Response) => {
      res.json(caffeineRepo.findAllByUser(req.authUser!.id));
    },

    create: (req: AuthenticatedRequest, res: Response) => {
      const userId = req.authUser!.id;
      const { date, beverageType, consumptionTime, caffeineAmount, notes = '' } = req.body ?? {};
      if (!isValidDateStr(date) || isFutureDate(date)) {
        sendValidationError(res, req, 400, 'Valid non-future date (YYYY-MM-DD) is required.');
        return;
      }
      if (!['Coffee', 'Tea', 'Other'].includes(beverageType)) {
        sendValidationError(res, req, 400, 'Beverage type must be Coffee, Tea, or Other.');
        return;
      }
      if (!isValidTimeStr(consumptionTime)) {
        sendValidationError(res, req, 400, 'Valid consumption time (HH:mm) is required.');
        return;
      }
      const mg = Number(caffeineAmount);
      if (Number.isNaN(mg) || mg <= 0 || mg > 1000) {
        sendValidationError(res, req, 400, 'Caffeine amount must be between 1 and 1000 mg.');
        return;
      }

      const created = caffeineRepo.createForUser(userId, {
        date,
        beverageType,
        consumptionTime,
        caffeineAmount: Math.round(mg),
        notes: String(notes ?? '').trim(),
      });
      res.status(201).json(created);
    },

    remove: (req: AuthenticatedRequest, res: Response) => {
      const userId = req.authUser!.id;
      const id = parsePositiveIntId(req.params.id);
      if (id === null) {
        sendValidationError(res, req, 400, 'Invalid caffeine log ID.');
        return;
      }
      if (!caffeineRepo.deleteForUser(id, userId)) {
        res.status(404).json({ error: 'Caffeine log not found.' });
        return;
      }
      res.json({ deleted: true, id });
    },
  };
}
