import type { Response } from 'express';
import type { SqliteDatabase } from '../config/database.ts';
import type { AuthenticatedRequest } from '../middleware/requestLogger.ts';
import { StudyRepository } from '../repositories/studyRepository.ts';
import { rebuildDailyMetricsForUser } from '../services/analyticsService.ts';
import {
  parsePositiveIntId,
  sendValidationError,
  validateStudyPayload,
} from './validation.ts';

export function createStudyController(db: SqliteDatabase) {
  const studyRepo = new StudyRepository(db);

  return {
    list: (req: AuthenticatedRequest, res: Response) => {
      res.json(studyRepo.findAllByUser(req.authUser!.id));
    },

    create: (req: AuthenticatedRequest, res: Response) => {
      const userId = req.authUser!.id;
      const parsed = validateStudyPayload(req.body);
      if (!parsed.ok) {
        sendValidationError(res, req, parsed.status, parsed.message);
        return;
      }
      const existingDayHours = studyRepo.sumHoursByDateForUser(parsed.data.date, userId);
      if (existingDayHours + parsed.data.studyHours > 24) {
        sendValidationError(
          res,
          req,
          400,
          'Total study duration on a single date cannot exceed 24 hours.',
        );
        return;
      }

      const created = db.transaction(() => {
        const row = studyRepo.createForUser(userId, parsed.data);
        rebuildDailyMetricsForUser(db, userId);
        return row;
      })();
      res.status(201).json(created);
    },

    update: (req: AuthenticatedRequest, res: Response) => {
      const userId = req.authUser!.id;
      const id = parsePositiveIntId(req.params.id);
      if (id === null) {
        sendValidationError(res, req, 400, 'Invalid study session ID.');
        return;
      }
      if (!studyRepo.findByIdForUser(id, userId)) {
        res.status(404).json({ error: 'Study session not found.' });
        return;
      }

      const parsed = validateStudyPayload(req.body);
      if (!parsed.ok) {
        sendValidationError(res, req, parsed.status, parsed.message);
        return;
      }
      const existingOtherDayHours = studyRepo.sumHoursByDateForUser(parsed.data.date, userId, id);
      if (existingOtherDayHours + parsed.data.studyHours > 24) {
        sendValidationError(
          res,
          req,
          400,
          'Total study duration on a single date cannot exceed 24 hours.',
        );
        return;
      }

      const updated = db.transaction(() => {
        const row = studyRepo.updateForUser(id, userId, parsed.data);
        rebuildDailyMetricsForUser(db, userId);
        return row;
      })();
      res.json(updated);
    },

    remove: (req: AuthenticatedRequest, res: Response) => {
      const userId = req.authUser!.id;
      const id = parsePositiveIntId(req.params.id);
      if (id === null) {
        sendValidationError(res, req, 400, 'Invalid study session ID.');
        return;
      }
      const deleted = db.transaction(() => {
        const ok = studyRepo.deleteForUser(id, userId);
        if (ok) rebuildDailyMetricsForUser(db, userId);
        return ok;
      })();
      if (!deleted) {
        res.status(404).json({ error: 'Study session not found.' });
        return;
      }
      res.json({ deleted: true, id });
    },
  };
}
