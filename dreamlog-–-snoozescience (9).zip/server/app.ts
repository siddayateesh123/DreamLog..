import cookieParser from 'cookie-parser';
import express from 'express';
import rateLimit from 'express-rate-limit';
import helmet from 'helmet';
import type { SqliteDatabase } from './config/database.ts';
import { validateEnvironment } from './config/env.ts';
import { logger } from './config/logger.ts';
import { createAnalyticsController } from './controllers/analyticsController.ts';
import { createAuthController } from './controllers/authController.ts';
import { createCaffeineController } from './controllers/caffeineController.ts';
import { createExamController } from './controllers/examController.ts';
import { createSettingsController } from './controllers/settingsController.ts';
import { createSleepController } from './controllers/sleepController.ts';
import { createStudyController } from './controllers/studyController.ts';
import { getAppliedMigrations, runMigrations } from './db/migrations.ts';
import { createAuthMiddleware } from './middleware/authMiddleware.ts';
import { requestLoggerMiddleware } from './middleware/requestLogger.ts';
import { ensureDefaultWorkspaceSeeded } from './services/demoSeedService.ts';

export interface CreateAppOptions {
  seedDefaultDemo?: boolean;
  enableRateLimit?: boolean;
  apiRateLimitMax?: number;
  authRateLimitMax?: number;
}

export function createApp(db: SqliteDatabase, options: CreateAppOptions = {}) {
  const env = validateEnvironment();
  runMigrations(db);
  if (options.seedDefaultDemo !== false) {
    ensureDefaultWorkspaceSeeded(db);
  }

  const app = express();
  app.set('trust proxy', 1);
  app.disable('x-powered-by');

  // Security headers (xFrameOptions & COEP disabled so preview iframe & local canvas snapshots work seamlessly)
  app.use(
    helmet({
      contentSecurityPolicy: false,
      crossOriginEmbedderPolicy: false,
      xFrameOptions: false,
    }),
  );

  // Strict request body limits to protect against payload exhaustion
  app.use(express.json({ limit: '256kb' }));
  app.use(express.urlencoded({ extended: false, limit: '256kb' }));
  app.use(cookieParser());
  app.use(requestLoggerMiddleware);

  const shouldRateLimit = options.enableRateLimit !== false;
  if (shouldRateLimit) {
    const apiLimiter = rateLimit({
      windowMs: 15 * 60 * 1000,
      max: options.apiRateLimitMax ?? env.apiRateLimitMax,
      standardHeaders: 'draft-7',
      legacyHeaders: false,
      skip: (req) => req.path === '/health',
      message: { error: 'Too many API requests. Please wait a moment and try again.' },
    });

    const authLimiter = rateLimit({
      windowMs: 15 * 60 * 1000,
      max: options.authRateLimitMax ?? env.authRateLimitMax,
      standardHeaders: 'draft-7',
      legacyHeaders: false,
      message: { error: 'Too many authentication attempts. Please wait before trying again.' },
    });

    app.use('/api', apiLimiter);
    app.use('/api/auth/login', authLimiter);
    app.use('/api/auth/register', authLimiter);
  }

  const { attachOptionalUser, requireAuth } = createAuthMiddleware(db);
  const authCtrl = createAuthController(db);
  const sleepCtrl = createSleepController(db);
  const studyCtrl = createStudyController(db);
  const analyticsCtrl = createAnalyticsController(db);
  const caffeineCtrl = createCaffeineController(db);
  const examCtrl = createExamController(db);
  const settingsCtrl = createSettingsController(db);

  // Public health & migration status check
  app.get('/api/health', (_req, res) => {
    const migrations = getAppliedMigrations(db);
    res.json({
      status: 'ok',
      migrationsCount: migrations.length,
      latestMigrationVersion: migrations[migrations.length - 1]?.version ?? 0,
    });
  });

  // Authentication Routes
  app.post('/api/auth/register', authCtrl.register);
  app.post('/api/auth/login', authCtrl.login);
  app.post('/api/auth/demo-session', authCtrl.demoSession);
  app.post('/api/auth/logout', authCtrl.logout);
  app.get('/api/auth/me', attachOptionalUser, authCtrl.me);

  // Protected Sleep Routes
  app.get('/api/sleep', requireAuth, sleepCtrl.list);
  app.post('/api/sleep', requireAuth, sleepCtrl.create);
  app.put('/api/sleep/:id', requireAuth, sleepCtrl.update);
  app.delete('/api/sleep/:id', requireAuth, sleepCtrl.remove);

  // Protected Study Routes
  app.get('/api/study', requireAuth, studyCtrl.list);
  app.post('/api/study', requireAuth, studyCtrl.create);
  app.put('/api/study/:id', requireAuth, studyCtrl.update);
  app.delete('/api/study/:id', requireAuth, studyCtrl.remove);

  // Protected Analytics & Simulation Routes
  app.get('/api/analytics/dashboard', requireAuth, analyticsCtrl.dashboard);
  app.get('/api/analytics/correlation', requireAuth, analyticsCtrl.correlation);
  app.get('/api/analytics/sleep-debt', requireAuth, analyticsCtrl.sleepDebt);
  app.get('/api/analytics/weekly-insights', requireAuth, analyticsCtrl.weeklyInsights);
  app.post('/api/analytics/simulate', requireAuth, analyticsCtrl.simulate);

  // Protected Caffeine Routes
  app.get('/api/caffeine', requireAuth, caffeineCtrl.list);
  app.post('/api/caffeine', requireAuth, caffeineCtrl.create);
  app.delete('/api/caffeine/:id', requireAuth, caffeineCtrl.remove);

  // Protected Exams & Sleep Preserver Routes
  app.get('/api/exams', requireAuth, examCtrl.listExams);
  app.post('/api/exams', requireAuth, examCtrl.createExam);
  app.put('/api/exams/:id', requireAuth, examCtrl.updateExam);
  app.delete('/api/exams/:id', requireAuth, examCtrl.deleteExam);

  app.get('/api/exams/plan', requireAuth, examCtrl.listPlanTasks);
  app.post('/api/exams/generate', requireAuth, examCtrl.generatePlan);
  app.post('/api/exams/reschedule', requireAuth, examCtrl.rescheduleMissed);
  app.get('/api/exams/feasibility', requireAuth, examCtrl.getFeasibility);
  app.put('/api/exams/plan/:id', requireAuth, examCtrl.updatePlanTask);

  // Protected Exam Results (Sleep vs Exam Performance) Routes
  app.get('/api/exam-results', requireAuth, examCtrl.listExamResults);
  app.post('/api/exam-results', requireAuth, examCtrl.createExamResult);
  app.put('/api/exam-results/:id', requireAuth, examCtrl.updateExamResult);
  app.delete('/api/exam-results/:id', requireAuth, examCtrl.deleteExamResult);

  // Protected Settings & Demo Data Management Routes
  app.get('/api/settings', requireAuth, settingsCtrl.getSettings);
  app.put('/api/settings', requireAuth, settingsCtrl.updateSettings);
  app.post('/api/demo/clear', requireAuth, settingsCtrl.clearDemo);
  app.post('/api/demo/reset', requireAuth, settingsCtrl.resetDemo);
  app.post('/api/demo/run-scenario', requireAuth, settingsCtrl.runDemoScenario);
  app.post('/api/demo/reset-scenario', requireAuth, settingsCtrl.resetDemoScenario);

  // Centralized & Production-Safe API Error Middleware
  app.use('/api', (err: unknown, req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (res.headersSent) {
      next(err);
      return;
    }
    if (err && typeof err === 'object' && 'type' in err && (err as { type?: string }).type === 'entity.too.large') {
      logger.warn('Oversized payload rejected', { method: req.method, path: req.path });
      res.status(413).json({ error: 'Request payload exceeds 256 KB limit.' });
      return;
    }
    if (err instanceof SyntaxError && 'status' in err) {
      logger.warn('Malformed JSON payload rejected', { method: req.method, path: req.path });
      res.status(400).json({ error: 'Malformed JSON request body.' });
      return;
    }
    const rawMessage = err instanceof Error ? err.message : 'Internal server error.';
    logger.error('Unhandled API exception', {
      method: req.method,
      path: req.path,
      error: rawMessage,
    });
    const isProd = process.env.NODE_ENV === 'production';
    res.status(500).json({
      error: isProd ? 'Internal server error.' : rawMessage,
    });
  });

  return app;
}
