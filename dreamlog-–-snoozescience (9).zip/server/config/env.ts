import crypto from 'crypto';
import { logger } from './logger.ts';

export interface ValidatedEnv {
  nodeEnv: string;
  isProduction: boolean;
  port: number;
  logLevel: string;
  sessionSecret: string;
  apiRateLimitMax: number;
  authRateLimitMax: number;
}

const RUNTIME_EPHEMERAL_SECRET = crypto.randomBytes(32).toString('hex');

const VALID_LOG_LEVELS = new Set(['error', 'warn', 'info', 'http', 'verbose', 'debug', 'silly']);
const WEAK_PLACEHOLDER_SECRETS = new Set([
  'secret',
  'changeme',
  'change-me',
  'change_me',
  'default_secret',
  'my_session_secret',
  'session_secret',
  'password',
]);

export function validateEnvironment(env: NodeJS.ProcessEnv = process.env): ValidatedEnv {
  const nodeEnv = (env.NODE_ENV || 'development').trim();
  const isProduction = nodeEnv === 'production';

  const rawPort = env.PORT ?? '3000';
  const port = Number(rawPort);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error(
      `Invalid PORT environment variable "${rawPort}". Must be an integer between 1 and 65535.`,
    );
  }

  const logLevel = (env.LOG_LEVEL || 'info').trim().toLowerCase();
  if (!VALID_LOG_LEVELS.has(logLevel)) {
    throw new Error(
      `Invalid LOG_LEVEL "${logLevel}". Allowed values: ${Array.from(VALID_LOG_LEVELS).join(', ')}.`,
    );
  }

  let sessionSecret = (env.SESSION_SECRET || '').trim();
  if (sessionSecret.length > 0) {
    if (sessionSecret.length < 16) {
      throw new Error('SESSION_SECRET must be at least 16 characters long when configured.');
    }
    if (WEAK_PLACEHOLDER_SECRETS.has(sessionSecret.toLowerCase())) {
      throw new Error('SESSION_SECRET cannot use a weak placeholder value.');
    }
  }
  if (!sessionSecret) {
    if (isProduction && env.REQUIRE_SESSION_SECRET === 'true') {
      throw new Error('SESSION_SECRET is required when REQUIRE_SESSION_SECRET=true in production.');
    }
    if (isProduction) {
      logger.warn(
        'SESSION_SECRET is not set; using ephemeral runtime CSPRNG secret (set SESSION_SECRET and REQUIRE_SESSION_SECRET=true in production).',
      );
    }
    sessionSecret = RUNTIME_EPHEMERAL_SECRET;
  }

  const parseLimit = (raw: string | undefined, fallback: number, name: string): number => {
    if (!raw || raw.trim() === '') return fallback;
    const n = Number(raw);
    if (!Number.isInteger(n) || n < 1) {
      throw new Error(`Invalid ${name}="${raw}". Must be a positive integer.`);
    }
    return n;
  };

  return {
    nodeEnv,
    isProduction,
    port,
    logLevel,
    sessionSecret,
    apiRateLimitMax: parseLimit(env.RATE_LIMIT_MAX, 600, 'RATE_LIMIT_MAX'),
    authRateLimitMax: parseLimit(env.AUTH_RATE_LIMIT_MAX, 25, 'AUTH_RATE_LIMIT_MAX'),
  };
}
