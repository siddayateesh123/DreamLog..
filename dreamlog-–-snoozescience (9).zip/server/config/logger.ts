import winston from 'winston';

const REDACTED_KEYS = new Set([
  'password',
  'passwordhash',
  'token',
  'tokenhash',
  'authorization',
  'cookie',
  'set-cookie',
  'secret',
  'sessionsecret',
]);

export function redactSensitiveMetadata(value: unknown): unknown {
  if (Array.isArray(value)) {
    return value.map((item) => redactSensitiveMetadata(item));
  }
  if (value !== null && typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      if (REDACTED_KEYS.has(k.toLowerCase())) {
        out[k] = '[REDACTED]';
      } else {
        out[k] = redactSensitiveMetadata(v);
      }
    }
    return out;
  }
  return value;
}

const redactFormat = winston.format((info) => {
  const cleaned = redactSensitiveMetadata(info) as winston.Logform.TransformableInfo;
  return cleaned;
});

const isProd = process.env.NODE_ENV === 'production';
const isTest = process.env.NODE_ENV === 'test' || process.env.VITEST === 'true';

const devFormat = winston.format.combine(
  redactFormat(),
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss.SSS' }),
  winston.format.errors({ stack: true }),
  winston.format.printf(({ timestamp, level, message, ...meta }) => {
    const metaKeys = Object.keys(meta).filter((k) => k !== 'service');
    const metaText = metaKeys.length > 0 ? ` ${JSON.stringify(meta)}` : '';
    return `[${timestamp}] ${level.toUpperCase()}: ${String(message)}${metaText}`;
  }),
);

const prodFormat = winston.format.combine(
  redactFormat(),
  winston.format.timestamp(),
  winston.format.errors({ stack: true }),
  winston.format.json(),
);

export const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || (isTest ? 'error' : isProd ? 'info' : 'debug'),
  defaultMeta: { service: 'dreamlog-snoozescience' },
  format: isProd ? prodFormat : devFormat,
  transports: [
    new winston.transports.Console({
      silent: isTest && process.env.LOG_IN_TESTS !== 'true',
    }),
  ],
});
