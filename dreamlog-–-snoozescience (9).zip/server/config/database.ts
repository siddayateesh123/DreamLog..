import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';
import { logger } from './logger.ts';

export type SqliteDatabase = Database.Database;

export function getDefaultDbPath(): string {
  if (process.env.DREAMLOG_DB_PATH) {
    return process.env.DREAMLOG_DB_PATH;
  }
  const dataDir = path.resolve(process.cwd(), 'data');
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  return path.join(dataDir, 'dreamlog.db');
}

export function createDatabaseConnection(dbPath: string = getDefaultDbPath()): SqliteDatabase {
  try {
    const db = new Database(dbPath);
    if (dbPath !== ':memory:') {
      try {
        db.pragma('wal_checkpoint(TRUNCATE)');
      } catch {
        // Ignore if database was not previously in WAL mode
      }
    }
    db.pragma('journal_mode = DELETE');
    db.pragma('busy_timeout = 5000');
    db.pragma('foreign_keys = ON');
    logger.info('SQLite database connection initialized', {
      dbPath: dbPath === ':memory:' ? ':memory:' : path.basename(dbPath),
      journalMode: 'DELETE',
    });
    return db;
  } catch (err) {
    logger.error('Failed to initialize SQLite database connection', {
      dbPath,
      error: err instanceof Error ? err.message : String(err),
    });
    throw err;
  }
}
