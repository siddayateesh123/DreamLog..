import type { NextFunction, Response } from 'express';
import type { SqliteDatabase } from '../config/database.ts';
import { logger } from '../config/logger.ts';
import { AuthService } from '../services/authService.ts';
import type { AuthenticatedRequest } from './requestLogger.ts';

export const SESSION_COOKIE_NAME = 'dreamlog_session';

export function extractSessionToken(req: AuthenticatedRequest): string | null {
  const authHeader = req.headers.authorization;
  if (typeof authHeader === 'string' && authHeader.startsWith('Bearer ')) {
    const bearer = authHeader.slice(7).trim();
    if (bearer) return bearer;
  }
  const cookies = (req as unknown as { cookies?: Record<string, string> }).cookies;
  if (cookies && typeof cookies[SESSION_COOKIE_NAME] === 'string' && cookies[SESSION_COOKIE_NAME]) {
    return cookies[SESSION_COOKIE_NAME];
  }
  return null;
}

export function createAuthMiddleware(db: SqliteDatabase) {
  const authService = new AuthService(db);

  const attachOptionalUser = (req: AuthenticatedRequest, _res: Response, next: NextFunction): void => {
    const token = extractSessionToken(req);
    if (token) {
      req.authUser = authService.authenticateToken(token) ?? undefined;
    }
    next();
  };

  const requireAuth = (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    const token = extractSessionToken(req);
    if (!token) {
      logger.warn('Unauthenticated API request blocked', {
        method: req.method,
        path: req.path,
      });
      res.status(401).json({
        error: 'Authentication required. Please sign in or launch the Demo Student workspace.',
      });
      return;
    }

    const user = authService.authenticateToken(token);
    if (!user) {
      logger.warn('Expired or invalid session token rejected', {
        method: req.method,
        path: req.path,
      });
      res.status(401).json({ error: 'Session expired or invalid. Please sign in again.' });
      return;
    }

    req.authUser = user;
    next();
  };

  return { attachOptionalUser, requireAuth };
}
