import type { NextFunction, Request, Response } from 'express';
import { logger } from '../config/logger.ts';
import type { AuthUser } from '../../src/shared/types.ts';

export interface AuthenticatedRequest extends Request {
  authUser?: AuthUser;
}

export function requestLoggerMiddleware(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  if (!req.path.startsWith('/api')) {
    next();
    return;
  }

  const start = Date.now();
  res.on('finish', () => {
    const durationMs = Date.now() - start;
    const meta = {
      method: req.method,
      path: req.path,
      statusCode: res.statusCode,
      durationMs,
      userId: req.authUser?.id ?? null,
    };

    if (res.statusCode >= 500) {
      logger.error('API request failed with server error', meta);
    } else if (res.statusCode >= 400) {
      logger.warn('API request rejected', meta);
    } else {
      logger.info('API request completed', meta);
    }
  });

  next();
}
