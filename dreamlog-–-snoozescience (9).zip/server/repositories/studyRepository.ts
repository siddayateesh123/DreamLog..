import type { SqliteDatabase } from '../config/database.ts';
import type { StudyLog } from '../../src/shared/types.ts';

type RawStudyRow = Omit<StudyLog, 'isDemo'> & { isDemo: number; userId: number };

function mapStudyRow(row: RawStudyRow): StudyLog {
  return {
    id: row.id,
    date: row.date,
    subject: row.subject,
    studyHours: row.studyHours,
    focusRating: row.focusRating,
    startTime: row.startTime,
    endTime: row.endTime,
    notes: row.notes,
    isDemo: Boolean(row.isDemo),
    createdAt: row.createdAt,
  };
}

export class StudyRepository {
  constructor(private readonly db: SqliteDatabase) {}

  findAllByUser(userId: number): StudyLog[] {
    const rows = this.db
      .prepare('SELECT * FROM study_logs WHERE userId = ? ORDER BY date DESC, id DESC')
      .all(userId) as RawStudyRow[];
    return rows.map(mapStudyRow);
  }

  findByIdForUser(id: number, userId: number): StudyLog | null {
    const row = this.db
      .prepare('SELECT * FROM study_logs WHERE id = ? AND userId = ?')
      .get(id, userId) as RawStudyRow | undefined;
    return row ? mapStudyRow(row) : null;
  }

  sumHoursByDateForUser(date: string, userId: number, excludeId?: number): number {
    const row = (
      excludeId !== undefined
        ? this.db
            .prepare(
              'SELECT COALESCE(SUM(studyHours), 0) as total FROM study_logs WHERE date = ? AND userId = ? AND id != ?',
            )
            .get(date, userId, excludeId)
        : this.db
            .prepare('SELECT COALESCE(SUM(studyHours), 0) as total FROM study_logs WHERE date = ? AND userId = ?')
            .get(date, userId)
    ) as { total: number };
    return row.total;
  }

  createForUser(
    userId: number,
    data: {
      date: string;
      subject: string;
      studyHours: number;
      focusRating: number;
      startTime: string;
      endTime: string;
      notes: string;
      isDemo?: boolean;
      createdAt?: string;
    },
  ): StudyLog {
    const nowIso = data.createdAt ?? new Date().toISOString();
    const res = this.db
      .prepare(
        `INSERT INTO study_logs (userId, date, subject, studyHours, focusRating, startTime, endTime, notes, isDemo, createdAt)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        userId,
        data.date,
        data.subject,
        data.studyHours,
        data.focusRating,
        data.startTime,
        data.endTime,
        data.notes,
        data.isDemo ? 1 : 0,
        nowIso,
      );
    return this.findByIdForUser(Number(res.lastInsertRowid), userId)!;
  }

  updateForUser(
    id: number,
    userId: number,
    data: {
      date: string;
      subject: string;
      studyHours: number;
      focusRating: number;
      startTime: string;
      endTime: string;
      notes: string;
    },
  ): StudyLog | null {
    const info = this.db
      .prepare(
        `UPDATE study_logs
         SET date = ?, subject = ?, studyHours = ?, focusRating = ?, startTime = ?, endTime = ?, notes = ?, isDemo = 0
         WHERE id = ? AND userId = ?`,
      )
      .run(
        data.date,
        data.subject,
        data.studyHours,
        data.focusRating,
        data.startTime,
        data.endTime,
        data.notes,
        id,
        userId,
      );
    if (info.changes === 0) return null;
    return this.findByIdForUser(id, userId);
  }

  deleteForUser(id: number, userId: number): boolean {
    const info = this.db
      .prepare('DELETE FROM study_logs WHERE id = ? AND userId = ?')
      .run(id, userId);
    return info.changes > 0;
  }
}
