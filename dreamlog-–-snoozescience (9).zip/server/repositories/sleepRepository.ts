import type { SqliteDatabase } from '../config/database.ts';
import type { SleepLog } from '../../src/shared/types.ts';

type RawSleepRow = Omit<SleepLog, 'isDemo'> & { isDemo: number; userId: number };

function mapSleepRow(row: RawSleepRow): SleepLog {
  return {
    id: row.id,
    date: row.date,
    bedtime: row.bedtime,
    wakeTime: row.wakeTime,
    duration: row.duration,
    sleepQuality: row.sleepQuality,
    notes: row.notes,
    isDemo: Boolean(row.isDemo),
    createdAt: row.createdAt,
  };
}

export class SleepRepository {
  constructor(private readonly db: SqliteDatabase) {}

  findAllByUser(userId: number): SleepLog[] {
    const rows = this.db
      .prepare('SELECT * FROM sleep_logs WHERE userId = ? ORDER BY date DESC, id DESC')
      .all(userId) as RawSleepRow[];
    return rows.map(mapSleepRow);
  }

  findByIdForUser(id: number, userId: number): SleepLog | null {
    const row = this.db
      .prepare('SELECT * FROM sleep_logs WHERE id = ? AND userId = ?')
      .get(id, userId) as RawSleepRow | undefined;
    return row ? mapSleepRow(row) : null;
  }

  findByDateForUser(date: string, userId: number, excludeId?: number): SleepLog | null {
    const row = (
      excludeId !== undefined
        ? this.db
            .prepare('SELECT * FROM sleep_logs WHERE date = ? AND userId = ? AND id != ?')
            .get(date, userId, excludeId)
        : this.db.prepare('SELECT * FROM sleep_logs WHERE date = ? AND userId = ?').get(date, userId)
    ) as RawSleepRow | undefined;
    return row ? mapSleepRow(row) : null;
  }

  createForUser(
    userId: number,
    data: {
      date: string;
      bedtime: string;
      wakeTime: string;
      duration: number;
      sleepQuality: number;
      notes: string;
      isDemo?: boolean;
      createdAt?: string;
    },
  ): SleepLog {
    const nowIso = data.createdAt ?? new Date().toISOString();
    const res = this.db
      .prepare(
        `INSERT INTO sleep_logs (userId, date, bedtime, wakeTime, duration, sleepQuality, notes, isDemo, createdAt)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        userId,
        data.date,
        data.bedtime,
        data.wakeTime,
        data.duration,
        data.sleepQuality,
        data.notes,
        data.isDemo ? 1 : 0,
        nowIso,
      );
    return this.findByIdForUser(Number(res.lastInsertRowid), userId)!;
  }

  updateForUser(
    id: number,
    userId: number,
    data: {
      date: string;
      bedtime: string;
      wakeTime: string;
      duration: number;
      sleepQuality: number;
      notes: string;
    },
  ): SleepLog | null {
    const info = this.db
      .prepare(
        `UPDATE sleep_logs
         SET date = ?, bedtime = ?, wakeTime = ?, duration = ?, sleepQuality = ?, notes = ?, isDemo = 0
         WHERE id = ? AND userId = ?`,
      )
      .run(
        data.date,
        data.bedtime,
        data.wakeTime,
        data.duration,
        data.sleepQuality,
        data.notes,
        id,
        userId,
      );
    if (info.changes === 0) return null;
    return this.findByIdForUser(id, userId);
  }

  deleteForUser(id: number, userId: number): boolean {
    const info = this.db
      .prepare('DELETE FROM sleep_logs WHERE id = ? AND userId = ?')
      .run(id, userId);
    return info.changes > 0;
  }

  countDemoForUser(userId: number): number {
    return (
      this.db
        .prepare('SELECT COUNT(*) as cnt FROM sleep_logs WHERE userId = ? AND isDemo = 1')
        .get(userId) as { cnt: number }
    ).cnt;
  }
}
