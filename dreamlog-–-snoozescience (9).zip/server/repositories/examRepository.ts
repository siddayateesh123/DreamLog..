import type { SqliteDatabase } from '../config/database.ts';
import type { ExamPlanTask, ExamPriority, ExamResult, ExamSchedule } from '../../src/shared/types.ts';

type RawTaskRow = Omit<ExamPlanTask, 'completed'> & { completed: number; userId: number };
type RawResultRow = Omit<ExamResult, 'isDemo'> & { isDemo: number; userId: number };

function mapTaskRow(row: RawTaskRow): ExamPlanTask {
  return {
    id: row.id,
    date: row.date,
    startTime: row.startTime,
    endTime: row.endTime,
    title: row.title,
    subject: row.subject,
    type: row.type,
    completed: Boolean(row.completed),
    schedulingReason: row.schedulingReason || '',
  };
}

function mapResultRow(row: RawResultRow): ExamResult {
  return {
    id: row.id,
    subject: row.subject,
    examDate: row.examDate,
    scorePercent: row.scorePercent,
    notes: row.notes,
    isDemo: Boolean(row.isDemo),
    createdAt: row.createdAt,
  };
}

export class ExamRepository {
  constructor(private readonly db: SqliteDatabase) {}

  findExamsByUser(userId: number): ExamSchedule[] {
    return this.db
      .prepare(
        'SELECT id, examDate, subject, topics, priority, estimatedHours, COALESCE(topicDifficulty, 3) as topicDifficulty, createdAt FROM exam_schedules WHERE userId = ? ORDER BY examDate ASC, id ASC',
      )
      .all(userId) as ExamSchedule[];
  }

  findExamByIdForUser(id: number, userId: number): ExamSchedule | null {
    const row = this.db
      .prepare(
        'SELECT id, examDate, subject, topics, priority, estimatedHours, COALESCE(topicDifficulty, 3) as topicDifficulty, createdAt FROM exam_schedules WHERE id = ? AND userId = ?',
      )
      .get(id, userId) as ExamSchedule | undefined;
    return row ?? null;
  }

  createExamForUser(
    userId: number,
    data: {
      examDate: string;
      subject: string;
      topics: string;
      priority: ExamPriority;
      estimatedHours: number;
      topicDifficulty?: number;
    },
  ): ExamSchedule {
    const nowIso = new Date().toISOString();
    const diff = Math.max(1, Math.min(5, Math.round(data.topicDifficulty ?? 3)));
    const res = this.db
      .prepare(
        `INSERT INTO exam_schedules (userId, examDate, subject, topics, priority, estimatedHours, topicDifficulty, createdAt)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        userId,
        data.examDate,
        data.subject,
        data.topics,
        data.priority,
        data.estimatedHours,
        diff,
        nowIso,
      );
    return this.findExamByIdForUser(Number(res.lastInsertRowid), userId)!;
  }

  updateExamForUser(
    id: number,
    userId: number,
    data: {
      examDate: string;
      subject: string;
      topics: string;
      priority: ExamPriority;
      estimatedHours: number;
      topicDifficulty?: number;
    },
  ): ExamSchedule | null {
    const diff = Math.max(1, Math.min(5, Math.round(data.topicDifficulty ?? 3)));
    const info = this.db
      .prepare(
        `UPDATE exam_schedules
         SET examDate = ?, subject = ?, topics = ?, priority = ?, estimatedHours = ?, topicDifficulty = ?
         WHERE id = ? AND userId = ?`,
      )
      .run(
        data.examDate,
        data.subject,
        data.topics,
        data.priority,
        data.estimatedHours,
        diff,
        id,
        userId,
      );
    if (info.changes === 0) return null;
    return this.findExamByIdForUser(id, userId);
  }

  deleteExamForUser(id: number, userId: number): boolean {
    const info = this.db
      .prepare('DELETE FROM exam_schedules WHERE id = ? AND userId = ?')
      .run(id, userId);
    return info.changes > 0;
  }

  findPlanTasksByUser(userId: number): ExamPlanTask[] {
    const rows = this.db
      .prepare('SELECT * FROM exam_plan_tasks WHERE userId = ? ORDER BY date ASC, id ASC')
      .all(userId) as RawTaskRow[];
    return rows.map(mapTaskRow);
  }

  findPlanTaskByIdForUser(id: number, userId: number): ExamPlanTask | null {
    const row = this.db
      .prepare('SELECT * FROM exam_plan_tasks WHERE id = ? AND userId = ?')
      .get(id, userId) as RawTaskRow | undefined;
    return row ? mapTaskRow(row) : null;
  }

  replacePlanTasksForUser(userId: number, tasks: Array<Omit<ExamPlanTask, 'id'>>): ExamPlanTask[] {
    this.db.transaction(() => {
      this.db.prepare('DELETE FROM exam_plan_tasks WHERE userId = ?').run(userId);
      const insertTask = this.db.prepare(
        `INSERT INTO exam_plan_tasks (userId, date, startTime, endTime, title, subject, type, completed, schedulingReason)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      );
      for (const t of tasks) {
        insertTask.run(
          userId,
          t.date,
          t.startTime,
          t.endTime,
          t.title,
          t.subject,
          t.type,
          t.completed ? 1 : 0,
          t.schedulingReason ?? '',
        );
      }
    })();
    return this.findPlanTasksByUser(userId);
  }

  updatePlanTaskForUser(
    id: number,
    userId: number,
    data: { completed: boolean; title: string; startTime: string; endTime: string },
  ): ExamPlanTask | null {
    const info = this.db
      .prepare(
        `UPDATE exam_plan_tasks SET completed = ?, title = ?, startTime = ?, endTime = ?
         WHERE id = ? AND userId = ?`,
      )
      .run(data.completed ? 1 : 0, data.title, data.startTime, data.endTime, id, userId);
    if (info.changes === 0) return null;
    return this.findPlanTaskByIdForUser(id, userId);
  }

  findExamResultsByUser(userId: number): ExamResult[] {
    const rows = this.db
      .prepare('SELECT * FROM exam_results WHERE userId = ? ORDER BY examDate DESC, id DESC')
      .all(userId) as RawResultRow[];
    return rows.map(mapResultRow);
  }

  findExamResultByIdForUser(id: number, userId: number): ExamResult | null {
    const row = this.db
      .prepare('SELECT * FROM exam_results WHERE id = ? AND userId = ?')
      .get(id, userId) as RawResultRow | undefined;
    return row ? mapResultRow(row) : null;
  }

  createExamResultForUser(
    userId: number,
    data: {
      subject: string;
      examDate: string;
      scorePercent: number;
      notes: string;
      isDemo?: boolean;
    },
  ): ExamResult {
    const nowIso = new Date().toISOString();
    const res = this.db
      .prepare(
        `INSERT INTO exam_results (userId, subject, examDate, scorePercent, notes, isDemo, createdAt)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(userId, data.subject, data.examDate, data.scorePercent, data.notes, data.isDemo ? 1 : 0, nowIso);
    return this.findExamResultByIdForUser(Number(res.lastInsertRowid), userId)!;
  }

  updateExamResultForUser(
    id: number,
    userId: number,
    data: { subject: string; examDate: string; scorePercent: number; notes: string },
  ): ExamResult | null {
    const info = this.db
      .prepare(
        `UPDATE exam_results SET subject = ?, examDate = ?, scorePercent = ?, notes = ?, isDemo = 0
         WHERE id = ? AND userId = ?`,
      )
      .run(data.subject, data.examDate, data.scorePercent, data.notes, id, userId);
    if (info.changes === 0) return null;
    return this.findExamResultByIdForUser(id, userId);
  }

  deleteExamResultForUser(id: number, userId: number): boolean {
    const info = this.db
      .prepare('DELETE FROM exam_results WHERE id = ? AND userId = ?')
      .run(id, userId);
    return info.changes > 0;
  }
}
