import type { SqliteDatabase } from '../config/database.ts';
import type { AuthUser, UserSettings } from '../../src/shared/types.ts';

export interface StoredUserRecord extends AuthUser {
  passwordHash: string;
}

export interface SessionRecord {
  id: number;
  tokenHash: string;
  userId: number;
  expiresAt: string;
  createdAt: string;
}

export class UserRepository {
  constructor(private readonly db: SqliteDatabase) {}

  findByEmail(email: string): StoredUserRecord | null {
    const row = this.db
      .prepare('SELECT id, name, email, passwordHash, role, createdAt FROM users WHERE lower(email) = lower(?)')
      .get(email.trim()) as StoredUserRecord | undefined;
    return row ?? null;
  }

  findById(id: number): AuthUser | null {
    const row = this.db
      .prepare('SELECT id, name, email, role, createdAt FROM users WHERE id = ?')
      .get(id) as AuthUser | undefined;
    return row ?? null;
  }

  createUser(params: {
    name: string;
    email: string;
    passwordHash: string;
    role?: 'student' | 'demo';
  }): AuthUser {
    const nowIso = new Date().toISOString();
    const role = params.role ?? 'student';
    const userId = this.db.transaction(() => {
      const result = this.db
        .prepare(
          `INSERT INTO users (name, email, passwordHash, role, createdAt)
           VALUES (?, ?, ?, ?, ?)`,
        )
        .run(
          params.name.trim(),
          params.email.trim().toLowerCase(),
          params.passwordHash,
          role,
          nowIso,
        );
      const id = Number(result.lastInsertRowid);
      this.ensureSettingsForUser(id, params.name.trim());
      return id;
    })();
    return this.findById(userId)!;
  }

  createSession(params: { tokenHash: string; userId: number; expiresAt: string }): void {
    this.db
      .prepare(
        `INSERT INTO user_sessions (tokenHash, userId, expiresAt, createdAt)
         VALUES (?, ?, ?, ?)`,
      )
      .run(params.tokenHash, params.userId, params.expiresAt, new Date().toISOString());
  }

  findSessionByTokenHash(tokenHash: string): SessionRecord | null {
    const row = this.db
      .prepare('SELECT id, tokenHash, userId, expiresAt, createdAt FROM user_sessions WHERE tokenHash = ?')
      .get(tokenHash) as SessionRecord | undefined;
    return row ?? null;
  }

  deleteSessionByTokenHash(tokenHash: string): void {
    this.db.prepare('DELETE FROM user_sessions WHERE tokenHash = ?').run(tokenHash);
  }

  deleteExpiredSessions(nowIso: string): void {
    this.db.prepare('DELETE FROM user_sessions WHERE expiresAt <= ?').run(nowIso);
  }

  ensureSettingsForUser(userId: number, defaultName = 'Student'): UserSettings {
    const existing = this.db
      .prepare('SELECT * FROM user_settings WHERE userId = ?')
      .get(userId) as
      | {
          studentName: string;
          sleepBaselineHours: number;
          caffeineHalfLifeHours: number;
          preferredWakeTime: string;
          dailyAvailableHours: number;
          onboardingDismissed: number;
          demoCleared: number;
        }
      | undefined;

    if (!existing) {
      const user = this.findById(userId);
      const name = user?.name || defaultName;
      this.db
        .prepare(
          `INSERT INTO user_settings (
            userId, studentName, sleepBaselineHours, caffeineHalfLifeHours,
            preferredWakeTime, dailyAvailableHours, onboardingDismissed, demoCleared, seedVersion
          ) VALUES (?, ?, 8, 5, '07:30', 7, 0, 0, 2)`,
        )
        .run(userId, name);
      return {
        studentName: name,
        sleepBaselineHours: 8,
        caffeineHalfLifeHours: 5,
        preferredWakeTime: '07:30',
        dailyAvailableHours: 7,
        onboardingDismissed: false,
        demoCleared: false,
      };
    }

    return {
      studentName: existing.studentName,
      sleepBaselineHours: existing.sleepBaselineHours,
      caffeineHalfLifeHours: existing.caffeineHalfLifeHours,
      preferredWakeTime: existing.preferredWakeTime,
      dailyAvailableHours: existing.dailyAvailableHours,
      onboardingDismissed: Boolean(existing.onboardingDismissed),
      demoCleared: Boolean(existing.demoCleared),
    };
  }

  getSettings(userId: number): UserSettings {
    return this.ensureSettingsForUser(userId);
  }

  updateSettings(userId: number, settings: {
    studentName: string;
    sleepBaselineHours: number;
    caffeineHalfLifeHours: number;
    preferredWakeTime: string;
    dailyAvailableHours: number;
    onboardingDismissed: boolean;
  }): UserSettings {
    this.ensureSettingsForUser(userId, settings.studentName);
    this.db
      .prepare(
        `UPDATE user_settings
         SET studentName = ?, sleepBaselineHours = ?, caffeineHalfLifeHours = ?,
             preferredWakeTime = ?, dailyAvailableHours = ?, onboardingDismissed = ?
         WHERE userId = ?`,
      )
      .run(
        settings.studentName,
        settings.sleepBaselineHours,
        settings.caffeineHalfLifeHours,
        settings.preferredWakeTime,
        settings.dailyAvailableHours,
        settings.onboardingDismissed ? 1 : 0,
        userId,
      );
    return this.getSettings(userId);
  }

  setDemoCleared(userId: number, cleared: boolean): void {
    this.ensureSettingsForUser(userId);
    this.db
      .prepare('UPDATE user_settings SET demoCleared = ? WHERE userId = ?')
      .run(cleared ? 1 : 0, userId);
  }
}
