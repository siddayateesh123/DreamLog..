import type { SqliteDatabase } from '../config/database.ts';
import type { CaffeineLog } from '../../src/shared/types.ts';

type RawCaffeineRow = Omit<CaffeineLog, 'isDemo'> & { isDemo: number; userId: number };

function mapCaffeineRow(row: RawCaffeineRow): CaffeineLog {
  return {
    id: row.id,
    date: row.date,
    beverageType: row.beverageType,
    consumptionTime: row.consumptionTime,
    caffeineAmount: row.caffeineAmount,
    notes: row.notes,
    isDemo: Boolean(row.isDemo),
    createdAt: row.createdAt,
  };
}

export class CaffeineRepository {
  constructor(private readonly db: SqliteDatabase) {}

  findAllByUser(userId: number): CaffeineLog[] {
    const rows = this.db
      .prepare(
        'SELECT * FROM caffeine_logs WHERE userId = ? ORDER BY date DESC, consumptionTime DESC, id DESC',
      )
      .all(userId) as RawCaffeineRow[];
    return rows.map(mapCaffeineRow);
  }

  findByIdForUser(id: number, userId: number): CaffeineLog | null {
    const row = this.db
      .prepare('SELECT * FROM caffeine_logs WHERE id = ? AND userId = ?')
      .get(id, userId) as RawCaffeineRow | undefined;
    return row ? mapCaffeineRow(row) : null;
  }

  createForUser(
    userId: number,
    data: {
      date: string;
      beverageType: 'Coffee' | 'Tea' | 'Other';
      consumptionTime: string;
      caffeineAmount: number;
      notes: string;
      isDemo?: boolean;
      createdAt?: string;
    },
  ): CaffeineLog {
    const nowIso = data.createdAt ?? new Date().toISOString();
    const res = this.db
      .prepare(
        `INSERT INTO caffeine_logs (userId, date, beverageType, consumptionTime, caffeineAmount, notes, isDemo, createdAt)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        userId,
        data.date,
        data.beverageType,
        data.consumptionTime,
        data.caffeineAmount,
        data.notes,
        data.isDemo ? 1 : 0,
        nowIso,
      );
    return this.findByIdForUser(Number(res.lastInsertRowid), userId)!;
  }

  deleteForUser(id: number, userId: number): boolean {
    const info = this.db
      .prepare('DELETE FROM caffeine_logs WHERE id = ? AND userId = ?')
      .run(id, userId);
    return info.changes > 0;
  }
}
