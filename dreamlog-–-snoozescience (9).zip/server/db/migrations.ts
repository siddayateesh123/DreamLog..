import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import type { SqliteDatabase } from '../config/database.ts';
import { logger } from '../config/logger.ts';

export interface MigrationDefinition {
  version: number;
  name: string;
  up: (db: SqliteDatabase) => void;
  down: (db: SqliteDatabase) => void;
}

export interface AppliedMigration {
  version: number;
  name: string;
  appliedAt: string;
}

function tableExists(db: SqliteDatabase, tableName: string): boolean {
  const row = db
    .prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = ?")
    .get(tableName) as { name: string } | undefined;
  return Boolean(row);
}

function hasColumn(db: SqliteDatabase, tableName: string, columnName: string): boolean {
  if (!tableExists(db, tableName)) return false;
  const cols = db.prepare(`PRAGMA table_info(${tableName})`).all() as Array<{ name: string }>;
  return cols.some((c) => c.name === columnName);
}

export const MIGRATIONS: MigrationDefinition[] = [
  {
    version: 1,
    name: '001_initial_core_tables',
    up: (db) => {
      db.exec(`
        CREATE TABLE IF NOT EXISTS sleep_logs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          date TEXT NOT NULL,
          bedtime TEXT NOT NULL,
          wakeTime TEXT NOT NULL,
          duration REAL NOT NULL,
          sleepQuality INTEGER NOT NULL,
          notes TEXT DEFAULT '',
          isDemo INTEGER DEFAULT 0,
          createdAt TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS study_logs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          date TEXT NOT NULL,
          subject TEXT NOT NULL,
          studyHours REAL NOT NULL,
          focusRating INTEGER NOT NULL,
          startTime TEXT DEFAULT '',
          endTime TEXT DEFAULT '',
          notes TEXT DEFAULT '',
          isDemo INTEGER DEFAULT 0,
          createdAt TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS daily_metrics (
          date TEXT PRIMARY KEY,
          totalSleep REAL DEFAULT 0,
          totalStudyHours REAL DEFAULT 0,
          averageFocus REAL,
          sleepDebt REAL DEFAULT 0,
          correlationMetrics TEXT DEFAULT '{}'
        );

        CREATE TABLE IF NOT EXISTS caffeine_logs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          date TEXT NOT NULL,
          beverageType TEXT NOT NULL,
          consumptionTime TEXT NOT NULL,
          caffeineAmount REAL NOT NULL,
          notes TEXT DEFAULT '',
          isDemo INTEGER DEFAULT 0,
          createdAt TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS exam_schedules (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          examDate TEXT NOT NULL,
          subject TEXT NOT NULL,
          topics TEXT NOT NULL,
          priority TEXT NOT NULL,
          estimatedHours REAL DEFAULT 4,
          createdAt TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS exam_plan_tasks (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          date TEXT NOT NULL,
          startTime TEXT NOT NULL,
          endTime TEXT NOT NULL,
          title TEXT NOT NULL,
          subject TEXT NOT NULL,
          type TEXT NOT NULL,
          completed INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS exam_results (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          subject TEXT NOT NULL,
          examDate TEXT NOT NULL,
          scorePercent REAL NOT NULL,
          notes TEXT DEFAULT '',
          isDemo INTEGER DEFAULT 0,
          createdAt TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS user_settings (
          id INTEGER PRIMARY KEY CHECK (id = 1),
          studentName TEXT NOT NULL,
          sleepBaselineHours REAL NOT NULL DEFAULT 8,
          caffeineHalfLifeHours REAL NOT NULL DEFAULT 5,
          preferredWakeTime TEXT NOT NULL DEFAULT '07:30',
          dailyAvailableHours REAL NOT NULL DEFAULT 7,
          onboardingDismissed INTEGER NOT NULL DEFAULT 0,
          demoCleared INTEGER NOT NULL DEFAULT 0,
          seedVersion INTEGER NOT NULL DEFAULT 1
        );
      `);

      if (!hasColumn(db, 'user_settings', 'seedVersion')) {
        db.exec('ALTER TABLE user_settings ADD COLUMN seedVersion INTEGER NOT NULL DEFAULT 1');
      }
    },
    down: (db) => {
      db.exec(`
        DROP TABLE IF EXISTS sleep_logs;
        DROP TABLE IF EXISTS study_logs;
        DROP TABLE IF EXISTS daily_metrics;
        DROP TABLE IF EXISTS caffeine_logs;
        DROP TABLE IF EXISTS exam_schedules;
        DROP TABLE IF EXISTS exam_plan_tasks;
        DROP TABLE IF EXISTS exam_results;
        DROP TABLE IF EXISTS user_settings;
      `);
    },
  },
  {
    version: 2,
    name: '002_auth_users_and_sessions',
    up: (db) => {
      db.exec(`
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          email TEXT NOT NULL UNIQUE,
          passwordHash TEXT NOT NULL,
          role TEXT NOT NULL DEFAULT 'student',
          createdAt TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS user_sessions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          tokenHash TEXT NOT NULL UNIQUE,
          userId INTEGER NOT NULL,
          expiresAt TEXT NOT NULL,
          createdAt TEXT NOT NULL,
          FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_user_sessions_tokenHash ON user_sessions(tokenHash);
        CREATE INDEX IF NOT EXISTS idx_user_sessions_userId ON user_sessions(userId);
      `);

      const existingDemo = db.prepare('SELECT id FROM users WHERE id = 1').get() as
        | { id: number }
        | undefined;
      if (!existingDemo) {
        // Random high-entropy password hash for the isolated Demo Student workspace (no hardcoded credential)
        const ephemeralDemoSecret = crypto.randomBytes(32).toString('hex');
        const passwordHash = bcrypt.hashSync(ephemeralDemoSecret, 10);
        db.prepare(
          `INSERT INTO users (id, name, email, passwordHash, role, createdAt)
           VALUES (1, ?, ?, ?, 'demo', ?)`,
        ).run('Maya Lin', 'demo@dreamlog.local', passwordHash, new Date().toISOString());
      }
    },
    down: (db) => {
      db.exec(`
        DROP TABLE IF EXISTS user_sessions;
        DROP TABLE IF EXISTS users;
      `);
    },
  },
  {
    version: 3,
    name: '003_multi_tenant_user_scoping',
    up: (db) => {
      const scopedTables = [
        'sleep_logs',
        'study_logs',
        'caffeine_logs',
        'exam_schedules',
        'exam_plan_tasks',
        'exam_results',
      ];
      for (const tbl of scopedTables) {
        if (!hasColumn(db, tbl, 'userId')) {
          db.exec(`ALTER TABLE ${tbl} ADD COLUMN userId INTEGER NOT NULL DEFAULT 1`);
        }
      }

      if (!hasColumn(db, 'exam_plan_tasks', 'schedulingReason')) {
        db.exec("ALTER TABLE exam_plan_tasks ADD COLUMN schedulingReason TEXT DEFAULT ''");
      }

      // Upgrade user_settings from single-row id=1 CHECK constraint to per-userId settings preserving existing row
      if (!hasColumn(db, 'user_settings', 'userId')) {
        db.exec(`
          CREATE TABLE user_settings_v3 (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            userId INTEGER NOT NULL UNIQUE,
            studentName TEXT NOT NULL,
            sleepBaselineHours REAL NOT NULL DEFAULT 8,
            caffeineHalfLifeHours REAL NOT NULL DEFAULT 5,
            preferredWakeTime TEXT NOT NULL DEFAULT '07:30',
            dailyAvailableHours REAL NOT NULL DEFAULT 7,
            onboardingDismissed INTEGER NOT NULL DEFAULT 0,
            demoCleared INTEGER NOT NULL DEFAULT 0,
            seedVersion INTEGER NOT NULL DEFAULT 2
          );
          INSERT INTO user_settings_v3 (
            userId, studentName, sleepBaselineHours, caffeineHalfLifeHours,
            preferredWakeTime, dailyAvailableHours, onboardingDismissed, demoCleared, seedVersion
          )
          SELECT
            1, studentName, sleepBaselineHours, caffeineHalfLifeHours,
            preferredWakeTime, dailyAvailableHours, onboardingDismissed, demoCleared, seedVersion
          FROM user_settings;
          DROP TABLE user_settings;
          ALTER TABLE user_settings_v3 RENAME TO user_settings;
        `);
      }

      // Upgrade daily_metrics to composite primary key (userId, date) preserving all existing rows
      if (!hasColumn(db, 'daily_metrics', 'userId')) {
        db.exec(`
          CREATE TABLE daily_metrics_v3 (
            userId INTEGER NOT NULL DEFAULT 1,
            date TEXT NOT NULL,
            totalSleep REAL DEFAULT 0,
            totalStudyHours REAL DEFAULT 0,
            averageFocus REAL,
            sleepDebt REAL DEFAULT 0,
            correlationMetrics TEXT DEFAULT '{}',
            PRIMARY KEY (userId, date)
          );
          INSERT INTO daily_metrics_v3 (userId, date, totalSleep, totalStudyHours, averageFocus, sleepDebt, correlationMetrics)
          SELECT 1, date, totalSleep, totalStudyHours, averageFocus, sleepDebt, correlationMetrics
          FROM daily_metrics;
          DROP TABLE daily_metrics;
          ALTER TABLE daily_metrics_v3 RENAME TO daily_metrics;
        `);
      }

      db.exec(`
        CREATE INDEX IF NOT EXISTS idx_sleep_logs_user_date ON sleep_logs(userId, date);
        CREATE INDEX IF NOT EXISTS idx_study_logs_user_date ON study_logs(userId, date);
        CREATE INDEX IF NOT EXISTS idx_caffeine_logs_user_date ON caffeine_logs(userId, date);
        CREATE INDEX IF NOT EXISTS idx_exam_schedules_user_date ON exam_schedules(userId, examDate);
        CREATE INDEX IF NOT EXISTS idx_exam_plan_tasks_user_date ON exam_plan_tasks(userId, date);
        CREATE INDEX IF NOT EXISTS idx_exam_results_user_date ON exam_results(userId, examDate);
      `);
    },
    down: (db) => {
      // Safe SQLite table-rebuild downgrade preserving userId=1 rows
      db.exec(`
        DROP INDEX IF EXISTS idx_sleep_logs_user_date;
        DROP INDEX IF EXISTS idx_study_logs_user_date;
        DROP INDEX IF EXISTS idx_caffeine_logs_user_date;
        DROP INDEX IF EXISTS idx_exam_schedules_user_date;
        DROP INDEX IF EXISTS idx_exam_plan_tasks_user_date;
        DROP INDEX IF EXISTS idx_exam_results_user_date;
      `);

      if (hasColumn(db, 'daily_metrics', 'userId')) {
        db.exec(`
          CREATE TABLE daily_metrics_v1 (
            date TEXT PRIMARY KEY,
            totalSleep REAL DEFAULT 0,
            totalStudyHours REAL DEFAULT 0,
            averageFocus REAL,
            sleepDebt REAL DEFAULT 0,
            correlationMetrics TEXT DEFAULT '{}'
          );
          INSERT OR REPLACE INTO daily_metrics_v1 (date, totalSleep, totalStudyHours, averageFocus, sleepDebt, correlationMetrics)
          SELECT date, totalSleep, totalStudyHours, averageFocus, sleepDebt, correlationMetrics
          FROM daily_metrics WHERE userId = 1;
          DROP TABLE daily_metrics;
          ALTER TABLE daily_metrics_v1 RENAME TO daily_metrics;
        `);
      }

      if (hasColumn(db, 'user_settings', 'userId')) {
        db.exec(`
          CREATE TABLE user_settings_v1 (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            studentName TEXT NOT NULL,
            sleepBaselineHours REAL NOT NULL DEFAULT 8,
            caffeineHalfLifeHours REAL NOT NULL DEFAULT 5,
            preferredWakeTime TEXT NOT NULL DEFAULT '07:30',
            dailyAvailableHours REAL NOT NULL DEFAULT 7,
            onboardingDismissed INTEGER NOT NULL DEFAULT 0,
            demoCleared INTEGER NOT NULL DEFAULT 0,
            seedVersion INTEGER NOT NULL DEFAULT 2
          );
          INSERT OR REPLACE INTO user_settings_v1 (
            id, studentName, sleepBaselineHours, caffeineHalfLifeHours,
            preferredWakeTime, dailyAvailableHours, onboardingDismissed, demoCleared, seedVersion
          )
          SELECT
            1, studentName, sleepBaselineHours, caffeineHalfLifeHours,
            preferredWakeTime, dailyAvailableHours, onboardingDismissed, demoCleared, seedVersion
          FROM user_settings WHERE userId = 1;
        DROP TABLE IF EXISTS user_settings;
          ALTER TABLE user_settings_v1 RENAME TO user_settings;
        `);
      }
    },
  },
  {
    version: 4,
    name: '004_exam_topic_difficulty_and_session_expiry_index',
    up: (db) => {
      if (!hasColumn(db, 'exam_schedules', 'topicDifficulty')) {
        db.exec('ALTER TABLE exam_schedules ADD COLUMN topicDifficulty INTEGER NOT NULL DEFAULT 3');
      }
      db.exec(
        'CREATE INDEX IF NOT EXISTS idx_user_sessions_expiresAt ON user_sessions(expiresAt)',
      );
    },
    down: (db) => {
      db.exec('DROP INDEX IF EXISTS idx_user_sessions_expiresAt');
      if (hasColumn(db, 'exam_schedules', 'topicDifficulty')) {
        db.exec(`
          CREATE TABLE exam_schedules_v3 (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            userId INTEGER NOT NULL DEFAULT 1,
            examDate TEXT NOT NULL,
            subject TEXT NOT NULL,
            topics TEXT NOT NULL,
            priority TEXT NOT NULL,
            estimatedHours REAL DEFAULT 4,
            createdAt TEXT NOT NULL
          );
          INSERT INTO exam_schedules_v3 (id, userId, examDate, subject, topics, priority, estimatedHours, createdAt)
          SELECT id, userId, examDate, subject, topics, priority, estimatedHours, createdAt
          FROM exam_schedules;
          DROP TABLE exam_schedules;
          ALTER TABLE exam_schedules_v3 RENAME TO exam_schedules;
          CREATE INDEX IF NOT EXISTS idx_exam_schedules_user_date ON exam_schedules(userId, examDate);
        `);
      }
    },
  },
];

export function ensureMigrationsTable(db: SqliteDatabase): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      appliedAt TEXT NOT NULL
    );
  `);
}

export function getAppliedMigrations(db: SqliteDatabase): AppliedMigration[] {
  ensureMigrationsTable(db);
  return db
    .prepare('SELECT version, name, appliedAt FROM schema_migrations ORDER BY version ASC')
    .all() as AppliedMigration[];
}

export function runMigrations(db: SqliteDatabase): AppliedMigration[] {
  ensureMigrationsTable(db);
  const appliedVersions = new Set(
    getAppliedMigrations(db).map((m) => m.version),
  );
  const newlyApplied: AppliedMigration[] = [];

  for (const migration of MIGRATIONS) {
    if (appliedVersions.has(migration.version)) continue;
    const nowIso = new Date().toISOString();
    try {
      db.transaction(() => {
        migration.up(db);
        db.prepare(
          'INSERT INTO schema_migrations (version, name, appliedAt) VALUES (?, ?, ?)',
        ).run(migration.version, migration.name, nowIso);
      })();
      newlyApplied.push({ version: migration.version, name: migration.name, appliedAt: nowIso });
      logger.info('Applied database migration', {
        version: migration.version,
        name: migration.name,
      });
    } catch (err) {
      logger.error('Database migration failed and rolled back cleanly', {
        version: migration.version,
        name: migration.name,
        error: err instanceof Error ? err.message : String(err),
      });
      throw err;
    }
  }

  return newlyApplied;
}

export function rollbackLastMigration(db: SqliteDatabase): AppliedMigration | null {
  ensureMigrationsTable(db);
  const applied = getAppliedMigrations(db);
  if (applied.length === 0) return null;

  const latest = applied[applied.length - 1];
  const migration = MIGRATIONS.find((m) => m.version === latest.version);
  if (!migration) {
    throw new Error(`Migration definition v${latest.version} not found for rollback.`);
  }

  try {
    db.transaction(() => {
      migration.down(db);
      db.prepare('DELETE FROM schema_migrations WHERE version = ?').run(latest.version);
    })();
    logger.info('Rolled back database migration', {
      version: latest.version,
      name: latest.name,
    });
    return latest;
  } catch (err) {
    logger.error('Migration rollback failed', {
      version: latest.version,
      error: err instanceof Error ? err.message : String(err),
    });
    throw err;
  }
}
