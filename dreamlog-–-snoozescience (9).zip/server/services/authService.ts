import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import type { SqliteDatabase } from '../config/database.ts';
import { validateEnvironment } from '../config/env.ts';
import { logger } from '../config/logger.ts';
import { UserRepository } from '../repositories/userRepository.ts';
import type { AuthUser } from '../../src/shared/types.ts';

function getSessionSecret(): string {
  return validateEnvironment().sessionSecret;
}

export class AuthError extends Error {
  constructor(
    public readonly statusCode: number,
    message: string,
  ) {
    super(message);
  }
}

export class AuthService {
  private readonly users: UserRepository;

  constructor(private readonly db: SqliteDatabase) {
    this.users = new UserRepository(db);
  }

  private hashToken(rawToken: string): string {
    return crypto.createHmac('sha256', getSessionSecret()).update(rawToken).digest('hex');
  }

  private issueSession(userId: number): string {
    this.users.deleteExpiredSessions(new Date().toISOString());
    const rawToken = crypto.randomBytes(32).toString('hex');
    const tokenHash = this.hashToken(rawToken);
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
    this.users.createSession({ tokenHash, userId, expiresAt });
    return rawToken;
  }

  async register(input: {
    name: string;
    email: string;
    password: string;
  }): Promise<{ user: AuthUser; token: string }> {
    const cleanName = input.name.trim();
    const cleanEmail = input.email.trim().toLowerCase();
    if (!cleanName || cleanName.length > 80) {
      throw new AuthError(400, 'Full name (1–80 characters) is required.');
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      throw new AuthError(400, 'A valid email address is required.');
    }
    if (typeof input.password !== 'string' || input.password.length < 6 || input.password.length > 128) {
      throw new AuthError(400, 'Password must be between 6 and 128 characters.');
    }

    const existing = this.users.findByEmail(cleanEmail);
    if (existing) {
      throw new AuthError(409, 'An account with this email already exists.');
    }

    const passwordHash = await bcrypt.hash(input.password, 10);
    const user = this.users.createUser({
      name: cleanName,
      email: cleanEmail,
      passwordHash,
      role: 'student',
    });
    const token = this.issueSession(user.id);
    logger.info('New student account registered', { userId: user.id, role: user.role });
    return { user, token };
  }

  async login(input: {
    email: string;
    password: string;
  }): Promise<{ user: AuthUser; token: string }> {
    const cleanEmail = (input.email || '').trim().toLowerCase();
    if (!cleanEmail || typeof input.password !== 'string' || !input.password) {
      throw new AuthError(400, 'Email and password are required.');
    }

    const stored = this.users.findByEmail(cleanEmail);
    if (!stored) {
      logger.warn('Failed login attempt: unknown email');
      throw new AuthError(401, 'Invalid email or password.');
    }

    const valid = await bcrypt.compare(input.password, stored.passwordHash);
    if (!valid) {
      logger.warn('Failed login attempt: password mismatch', { userId: stored.id });
      throw new AuthError(401, 'Invalid email or password.');
    }

    const token = this.issueSession(stored.id);
    const user: AuthUser = {
      id: stored.id,
      name: stored.name,
      email: stored.email,
      role: stored.role,
      createdAt: stored.createdAt,
    };
    logger.info('User authenticated', { userId: user.id, role: user.role });
    return { user, token };
  }

  createDemoSession(): { user: AuthUser; token: string } {
    const demoUser = this.users.findById(1);
    if (!demoUser) {
      throw new AuthError(500, 'Demo workspace user is not initialized.');
    }
    this.users.ensureSettingsForUser(demoUser.id, demoUser.name);
    const token = this.issueSession(demoUser.id);
    logger.info('Issued Demo Student workspace session', { userId: demoUser.id });
    return { user: demoUser, token };
  }

  authenticateToken(rawToken: string): AuthUser | null {
    if (!rawToken || typeof rawToken !== 'string') return null;
    const tokenHash = this.hashToken(rawToken);
    const session = this.users.findSessionByTokenHash(tokenHash);
    if (!session) return null;
    if (session.expiresAt <= new Date().toISOString()) {
      this.users.deleteSessionByTokenHash(tokenHash);
      return null;
    }
    return this.users.findById(session.userId);
  }

  logout(rawToken: string | undefined): void {
    if (!rawToken) return;
    const tokenHash = this.hashToken(rawToken);
    this.users.deleteSessionByTokenHash(tokenHash);
    logger.info('User session terminated');
  }
}
