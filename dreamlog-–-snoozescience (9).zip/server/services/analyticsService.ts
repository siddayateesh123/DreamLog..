import type { SqliteDatabase } from '../config/database.ts';
import {
  addDaysToDateStr,
  computeCorrelationAnalysis,
  computePearsonAndOLSFromPoints,
  computeSleepDebtMetrics,
  computeWeightedFocus,
  estimateBedtimeCaffeine,
  EXAM_CONFIDENCE_WARNING_TEXT,
  getLocalDateStr,
  getWeekdayName,
} from '../../src/shared/math.ts';
import type {
  ActivityItem,
  DailyMetricPoint,
  DashboardAnalytics,
  ExamPerformanceAnalysis,
  ExamPerformancePoint,
  ExamResult,
  SleepDebtSummary,
  SleepLog,
  SubjectStat,
  UserSettings,
  WeeklyInsights,
} from '../../src/shared/types.ts';
import { CaffeineRepository } from '../repositories/caffeineRepository.ts';
import { ExamRepository } from '../repositories/examRepository.ts';
import { SleepRepository } from '../repositories/sleepRepository.ts';
import { StudyRepository } from '../repositories/studyRepository.ts';
import { UserRepository } from '../repositories/userRepository.ts';

export function rebuildDailyMetricsForUser(db: SqliteDatabase, userId = 1): void {
  const userRepo = new UserRepository(db);
  const settings = userRepo.getSettings(userId);
  const baseline = settings.sleepBaselineHours || 8;

  const sleepRows = db
    .prepare('SELECT date, duration FROM sleep_logs WHERE userId = ?')
    .all(userId) as Array<{ date: string; duration: number }>;
  const studyRows = db
    .prepare('SELECT date, studyHours, focusRating FROM study_logs WHERE userId = ?')
    .all(userId) as Array<{ date: string; studyHours: number; focusRating: number }>;

  const dateMap = new Map<
    string,
    {
      totalSleep: number;
      totalStudyHours: number;
      sessions: Array<{ studyHours: number; focusRating: number }>;
    }
  >();

  for (const s of sleepRows) {
    const entry = dateMap.get(s.date) ?? { totalSleep: 0, totalStudyHours: 0, sessions: [] };
    entry.totalSleep += s.duration;
    dateMap.set(s.date, entry);
  }

  for (const st of studyRows) {
    const entry = dateMap.get(st.date) ?? { totalSleep: 0, totalStudyHours: 0, sessions: [] };
    entry.totalStudyHours += st.studyHours;
    entry.sessions.push({ studyHours: st.studyHours, focusRating: st.focusRating });
    dateMap.set(st.date, entry);
  }

  db.transaction(() => {
    db.prepare('DELETE FROM daily_metrics WHERE userId = ?').run(userId);
    const insertMetric = db.prepare(
      `INSERT INTO daily_metrics (userId, date, totalSleep, totalStudyHours, averageFocus, sleepDebt, correlationMetrics)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
    );

    for (const [date, agg] of dateMap.entries()) {
      const totalSleep = Math.round(agg.totalSleep * 100) / 100;
      const totalStudyHours = Math.round(agg.totalStudyHours * 100) / 100;
      const averageFocus = computeWeightedFocus(agg.sessions);
      const sleepDebt =
        totalSleep > 0 ? Math.max(0, Math.round((baseline - totalSleep) * 100) / 100) : 0;

      insertMetric.run(
        userId,
        date,
        totalSleep,
        totalStudyHours,
        averageFocus,
        sleepDebt,
        JSON.stringify({ paired: totalSleep > 0 && averageFocus !== null }),
      );
    }
  })();
}

export function computeExamPerformanceAnalysis(
  examResults: ExamResult[],
  sleepLogs: SleepLog[],
): ExamPerformanceAnalysis {
  const sleepByDate = new Map<string, number>();
  for (const s of sleepLogs) {
    sleepByDate.set(s.date, (sleepByDate.get(s.date) ?? 0) + s.duration);
  }

  const points: ExamPerformancePoint[] = examResults.map((ex) => {
    const prior3Dates = [
      addDaysToDateStr(ex.examDate, -3),
      addDaysToDateStr(ex.examDate, -2),
      addDaysToDateStr(ex.examDate, -1),
    ];
    const nights = prior3Dates
      .map((d) => sleepByDate.get(d))
      .filter((v): v is number => typeof v === 'number' && v > 0);

    const preExamAvgSleep =
      nights.length > 0
        ? Math.round((nights.reduce((a, b) => a + b, 0) / nights.length) * 100) / 100
        : null;

    return {
      examId: ex.id,
      subject: ex.subject,
      examDate: ex.examDate,
      scorePercent: ex.scorePercent,
      preExamAvgSleep,
      sleepNightsCount: nights.length,
      notes: ex.notes,
    };
  });

  const validPairs = points
    .filter((p) => p.preExamAvgSleep !== null)
    .map((p) => ({ x: p.preExamAvgSleep as number, y: p.scorePercent }));

  const raw = computePearsonAndOLSFromPoints(
    validPairs,
    5,
    EXAM_CONFIDENCE_WARNING_TEXT,
    [0, 100],
  );

  return {
    results: examResults,
    points,
    r: raw.r,
    category: raw.category,
    observationCount: raw.observationCount,
    requiredCount: 5,
    hasConfidence: raw.hasConfidence,
    confidenceWarning: raw.confidenceWarning,
  };
}

export function computeWeeklyInsightsFromSeries(
  series: DailyMetricPoint[],
  allSeries: DailyMetricPoint[],
  sleepDebt: SleepDebtSummary,
  settings: UserSettings,
): WeeklyInsights {
  const positiveInsights: string[] = [];
  const improvementAreas: string[] = [];
  const sleepRecommendations: string[] = [];
  const studyRecommendations: string[] = [];

  const todayStr = getLocalDateStr(0);
  const thisWeekCutoff = getLocalDateStr(-6);
  const prevWeekStart = getLocalDateStr(-13);
  const prevWeekEnd = getLocalDateStr(-7);

  const thisWeek = allSeries.filter((d) => d.date >= thisWeekCutoff && d.date <= todayStr);
  const prevWeek = allSeries.filter((d) => d.date >= prevWeekStart && d.date <= prevWeekEnd);

  const pairedAll = series.filter((d) => d.hasPairedData);
  const wellRested = pairedAll.filter((d) => d.totalSleep >= 7.5);
  const underRested = pairedAll.filter((d) => d.totalSleep < 7.5);

  if (wellRested.length > 0 && underRested.length > 0) {
    const highFocus =
      wellRested.reduce((a, d) => a + (d.averageFocus as number), 0) / wellRested.length;
    const lowFocus =
      underRested.reduce((a, d) => a + (d.averageFocus as number), 0) / underRested.length;

    if (highFocus > lowFocus) {
      const pct = Math.round(((highFocus - lowFocus) / lowFocus) * 100);
      positiveInsights.push(
        `Days following 7.5+ hours of sleep saw ${pct}% higher study focus (${highFocus.toFixed(2)}/5 vs ${lowFocus.toFixed(2)}/5).`,
      );
    } else {
      positiveInsights.push(
        `Average study focus was ${highFocus.toFixed(2)}/5 on 7.5+ hour nights compared with ${lowFocus.toFixed(2)}/5 on shorter nights.`,
      );
    }
  }

  const thisWeekStudied = thisWeek.filter((d) => d.averageFocus !== null && d.totalStudyHours > 0);
  let peakEfficiencyDay: string | null = null;
  if (thisWeekStudied.length > 0) {
    const bestDay = [...thisWeekStudied].sort((a, b) => {
      const diff = (b.averageFocus ?? 0) - (a.averageFocus ?? 0);
      if (Math.abs(diff) > 0.01) return diff;
      return b.totalStudyHours - a.totalStudyHours;
    })[0];
    peakEfficiencyDay = getWeekdayName(bestDay.date);
    positiveInsights.push(
      `You studied the most efficiently on ${peakEfficiencyDay} (${bestDay.averageFocus?.toFixed(2)}/5 weighted focus across ${bestDay.totalStudyHours}h).`,
    );
  }

  const thisWeekFocusDays = thisWeek.filter((d) => d.averageFocus !== null);
  const prevWeekFocusDays = prevWeek.filter((d) => d.averageFocus !== null);
  let focusDeltaPercent: number | null = null;
  if (thisWeekFocusDays.length > 0 && prevWeekFocusDays.length > 0) {
    const curAvg =
      thisWeekFocusDays.reduce((a, d) => a + (d.averageFocus as number), 0) /
      thisWeekFocusDays.length;
    const prevAvg =
      prevWeekFocusDays.reduce((a, d) => a + (d.averageFocus as number), 0) /
      prevWeekFocusDays.length;
    if (prevAvg > 0) {
      focusDeltaPercent = Math.round(((curAvg - prevAvg) / prevAvg) * 100);
      if (focusDeltaPercent > 0) {
        positiveInsights.push(
          `Your average focus rating improved by ${focusDeltaPercent}% compared with last week (${curAvg.toFixed(2)}/5 vs ${prevAvg.toFixed(2)}/5).`,
        );
      } else if (focusDeltaPercent < 0) {
        improvementAreas.push(
          `Your average focus rating dipped by ${Math.abs(focusDeltaPercent)}% compared with last week (${curAvg.toFixed(2)}/5 vs ${prevAvg.toFixed(2)}/5).`,
        );
      }
    }
  }

  const thisWeekSleeps = thisWeek.filter((d) => d.totalSleep > 0);
  const baseline = settings.sleepBaselineHours || 8;
  if (thisWeekSleeps.length > 0) {
    const weekSleepAvg =
      thisWeekSleeps.reduce((a, d) => a + d.totalSleep, 0) / thisWeekSleeps.length;
    const diff = Math.round((baseline - weekSleepAvg) * 100) / 100;
    if (diff > 0.25) {
      improvementAreas.push(
        `Your average sleep duration this week (${weekSleepAvg.toFixed(2)}h) was ${diff.toFixed(2)}h below your ${baseline}-hour tracking baseline.`,
      );
      sleepRecommendations.push(
        `Shift lights-out 30 minutes earlier to close the ${diff.toFixed(1)}h nightly gap toward your ${baseline}h baseline.`,
      );
    } else {
      positiveInsights.push(
        `Your weekly sleep averaged ${weekSleepAvg.toFixed(2)}h, tracking right alongside your ${baseline}-hour baseline.`,
      );
      sleepRecommendations.push(
        `Keep protecting your current wind-down window to maintain ${weekSleepAvg.toFixed(1)}h nightly rest.`,
      );
    }
  }

  if (sleepDebt.consistencyStatus === 'Inconsistent') {
    improvementAreas.push(
      `Your sleep schedule has been inconsistent this week (±${sleepDebt.sleepStdDevHours.toFixed(2)}h standard deviation).`,
    );
    sleepRecommendations.push(
      'Set a fixed morning wake-up alarm within a 30-minute window across weekdays and weekends.',
    );
  } else if (sleepDebt.consistencyStatus === 'Consistent') {
    positiveInsights.push(
      `Your sleep duration remained highly consistent (±${sleepDebt.sleepStdDevHours.toFixed(2)}h variance).`,
    );
  }

  const highCafDays = series.filter((d) => d.caffeineAtBedtimeMg >= 40 && d.totalSleep > 0);
  const lowCafDays = series.filter((d) => d.caffeineAtBedtimeMg < 40 && d.totalSleep > 0);
  if (highCafDays.length > 0 && lowCafDays.length > 0) {
    const avgHigh = highCafDays.reduce((a, d) => a + d.totalSleep, 0) / highCafDays.length;
    const avgLow = lowCafDays.reduce((a, d) => a + d.totalSleep, 0) / lowCafDays.length;
    if (avgLow > avgHigh + 0.25) {
      improvementAreas.push(
        `Nights with >= 40mg estimated caffeine remaining at bedtime averaged ${avgHigh.toFixed(2)}h sleep vs ${avgLow.toFixed(2)}h on lower-caffeine nights.`,
      );
      sleepRecommendations.push(
        'Move your last caffeinated drink at least 8–10 hours before bedtime to reduce estimated residual caffeine.',
      );
    }
  }

  const heavyStudyDays = pairedAll.filter((d) => d.totalStudyHours >= 6);
  const moderateStudyDays = pairedAll.filter((d) => d.totalStudyHours >= 3 && d.totalStudyHours < 6);
  if (heavyStudyDays.length > 0 && moderateStudyDays.length > 0) {
    const heavyFocus =
      heavyStudyDays.reduce((a, d) => a + (d.averageFocus as number), 0) / heavyStudyDays.length;
    const modFocus =
      moderateStudyDays.reduce((a, d) => a + (d.averageFocus as number), 0) /
      moderateStudyDays.length;
    if (modFocus > heavyFocus) {
      studyRecommendations.push(
        `Balanced 3–6 hour study days yielded higher focus (${modFocus.toFixed(2)}/5) than 6+ hour marathon days (${heavyFocus.toFixed(2)}/5). Break intense topics into focused 90-minute blocks.`,
      );
    } else {
      studyRecommendations.push(
        'Schedule your hardest analytical subjects in the first 4 hours after waking when focus ratings peak.',
      );
    }
  }

  if (studyRecommendations.length === 0) {
    studyRecommendations.push(
      'Log study subjects alongside start/end times to pinpoint which time of day produces your highest Deep Focus ratings.',
    );
  }
  if (sleepRecommendations.length === 0) {
    sleepRecommendations.push(
      'Log nightly bedtimes and wake-up times consistently so DreamLog can identify your optimal sleep duration.',
    );
  }

  if (positiveInsights.length === 0) {
    positiveInsights.push(
      'Start logging both nightly sleep and daily study sessions to unlock personalized positive trend discoveries.',
    );
  }
  if (improvementAreas.length === 0 && series.length > 0) {
    improvementAreas.push(
      'No major Sleep Debt or focus drop alerts detected in your active tracking window.',
    );
  }

  const totalWeekStudy = thisWeek.reduce((a, d) => a + d.totalStudyHours, 0);
  const avgWeekSleep =
    thisWeekSleeps.length > 0
      ? thisWeekSleeps.reduce((a, d) => a + d.totalSleep, 0) / thisWeekSleeps.length
      : 0;
  const avgWeekFocus =
    thisWeekFocusDays.length > 0
      ? thisWeekFocusDays.reduce((a, d) => a + (d.averageFocus as number), 0) /
        thisWeekFocusDays.length
      : 0;

  const weeklySummary =
    thisWeekSleeps.length === 0 && thisWeekStudied.length === 0
      ? 'No records logged in the current 7-day window yet. Add your sleep and study logs to generate a weekly performance summary.'
      : `Over the last 7 days, you averaged ${avgWeekSleep.toFixed(2)}h of sleep across ${thisWeekSleeps.length} logged night${thisWeekSleeps.length === 1 ? '' : 's'}, logged ${totalWeekStudy.toFixed(1)}h of study with a ${avgWeekFocus.toFixed(2)}/5 weighted focus rating, and accumulated ${sleepDebt.weeklyCumulativeDebt.toFixed(1)}h of Sleep Debt against your ${baseline}h tracking baseline.`;

  return {
    positiveInsights,
    improvementAreas,
    weeklySummary,
    sleepRecommendations,
    studyRecommendations,
    peakEfficiencyDay,
    focusDeltaPercent,
  };
}

export function getDashboardAnalyticsForUser(
  db: SqliteDatabase,
  userId: number,
  daysWindow = 21,
): DashboardAnalytics {
  const validWindow = [7, 14, 21, 30].includes(daysWindow) ? daysWindow : 21;
  const userRepo = new UserRepository(db);
  const sleepRepo = new SleepRepository(db);
  const studyRepo = new StudyRepository(db);
  const caffeineRepo = new CaffeineRepository(db);
  const examRepo = new ExamRepository(db);

  const settings = userRepo.getSettings(userId);
  const baseline = settings.sleepBaselineHours || 8;
  const halfLife = settings.caffeineHalfLifeHours || 5;

  const sleepLogs = sleepRepo.findAllByUser(userId);
  const studyLogs = studyRepo.findAllByUser(userId);
  const caffeineLogs = caffeineRepo.findAllByUser(userId);
  const examResults = examRepo.findExamResultsByUser(userId);

  const allDates = new Set<string>();
  for (const s of sleepLogs) allDates.add(s.date);
  for (const st of studyLogs) allDates.add(st.date);
  for (const c of caffeineLogs) allDates.add(c.date);

  const sortedAllDates = Array.from(allDates).sort();

  let latestEntryDate: string | null = null;
  const nonDemoSleep = sleepLogs.filter((s) => !s.isDemo);
  const nonDemoStudy = studyLogs.filter((s) => !s.isDemo);
  if (nonDemoSleep.length > 0 || nonDemoStudy.length > 0) {
    const combined = [...nonDemoSleep, ...nonDemoStudy].sort((a, b) =>
      b.createdAt.localeCompare(a.createdAt),
    );
    latestEntryDate = combined[0]?.date ?? null;
  }

  const allSeries: DailyMetricPoint[] = sortedAllDates.map((date) => {
    const daySleeps = sleepLogs.filter((s) => s.date === date);
    const dayStudies = studyLogs.filter((s) => s.date === date);
    const dayCaffeines = caffeineLogs.filter((c) => c.date === date);

    const totalSleep = Math.round(daySleeps.reduce((sum, s) => sum + s.duration, 0) * 100) / 100;
    const primarySleep = daySleeps[0] ?? null;
    const sleepQuality =
      daySleeps.length > 0
        ? Math.round(
            (daySleeps.reduce((sum, s) => sum + s.sleepQuality, 0) / daySleeps.length) * 10,
          ) / 10
        : null;

    const totalStudyHours =
      Math.round(dayStudies.reduce((sum, s) => sum + s.studyHours, 0) * 100) / 100;
    const averageFocus = computeWeightedFocus(dayStudies);
    const subjects = Array.from(new Set(dayStudies.map((s) => s.subject)));
    const sleepDebt =
      totalSleep > 0 ? Math.max(0, Math.round((baseline - totalSleep) * 100) / 100) : 0;

    const caffeineTotalMg = Math.round(dayCaffeines.reduce((sum, c) => sum + c.caffeineAmount, 0));
    const targetBedtime = primarySleep?.bedtime ?? '23:30';
    const caffeineAtBedtimeMg = estimateBedtimeCaffeine(dayCaffeines, targetBedtime, halfLife);

    const isDemo =
      (daySleeps.length > 0 && daySleeps.every((s) => s.isDemo)) ||
      (dayStudies.length > 0 && dayStudies.every((s) => s.isDemo) && daySleeps.length === 0);

    return {
      date,
      totalSleep,
      sleepQuality,
      bedtime: primarySleep?.bedtime ?? null,
      wakeTime: primarySleep?.wakeTime ?? null,
      totalStudyHours,
      averageFocus,
      studySessionsCount: dayStudies.length,
      subjects,
      sleepDebt,
      caffeineTotalMg,
      caffeineAtBedtimeMg,
      isDemo,
      hasPairedData: totalSleep > 0 && averageFocus !== null && dayStudies.length > 0,
      latestUpdated: latestEntryDate !== null && date === latestEntryDate,
    };
  });

  const todayStr = getLocalDateStr(0);
  const cutoffStr = getLocalDateStr(-validWindow);
  const series = allSeries.filter((p) => p.date >= cutoffStr && p.date <= todayStr);

  const weekCutoff = getLocalDateStr(-6);
  const lastNight = sleepLogs[0] ?? null;

  const weekSleepLogs = allSeries.filter(
    (d) => d.date >= weekCutoff && d.date <= todayStr && d.totalSleep > 0,
  );
  const averageWeeklySleep =
    weekSleepLogs.length > 0
      ? Math.round(
          (weekSleepLogs.reduce((a, d) => a + d.totalSleep, 0) / weekSleepLogs.length) * 100,
        ) / 100
      : 0;

  const totalStudyHoursThisWeek =
    Math.round(
      allSeries
        .filter((d) => d.date >= weekCutoff && d.date <= todayStr)
        .reduce((a, d) => a + d.totalStudyHours, 0) * 100,
    ) / 100;

  const windowedStudyLogs = studyLogs.filter((s) => s.date >= cutoffStr && s.date <= todayStr);
  const averageFocusRating = computeWeightedFocus(windowedStudyLogs) ?? 0;

  const sleepDays = series.filter((d) => d.totalSleep > 0);
  const sleepDebt = computeSleepDebtMetrics(sleepDays, weekSleepLogs, baseline);
  const correlation = computeCorrelationAnalysis(series, latestEntryDate);
  const insights = computeWeeklyInsightsFromSeries(series, allSeries, sleepDebt, settings);
  const examPerformance = computeExamPerformanceAnalysis(examResults, sleepLogs);

  const subjectMap = new Map<
    string,
    { hours: number; sessions: Array<{ studyHours: number; focusRating: number }> }
  >();
  for (const s of windowedStudyLogs) {
    const cur = subjectMap.get(s.subject) ?? { hours: 0, sessions: [] };
    cur.hours += s.studyHours;
    cur.sessions.push({ studyHours: s.studyHours, focusRating: s.focusRating });
    subjectMap.set(s.subject, cur);
  }

  const subjectStats: SubjectStat[] = Array.from(subjectMap.entries())
    .map(([subject, val]) => ({
      subject,
      totalHours: Math.round(val.hours * 100) / 100,
      sessionsCount: val.sessions.length,
      averageFocus: computeWeightedFocus(val.sessions) ?? 0,
    }))
    .sort((a, b) => b.totalHours - a.totalHours);

  const recentActivity: ActivityItem[] = [
    ...sleepLogs.slice(0, 8).map((s) => ({
      id: `sleep-${s.id}`,
      type: 'sleep' as const,
      date: s.date,
      title: `Sleep Log (${s.sleepQuality}/5 quality)`,
      detail: `${s.bedtime} -> ${s.wakeTime}${s.notes ? ` · ${s.notes}` : ''}`,
      metric: `${s.duration.toFixed(2)}h`,
      isDemo: s.isDemo,
      createdAt: s.createdAt,
    })),
    ...studyLogs.slice(0, 8).map((st) => ({
      id: `study-${st.id}`,
      type: 'study' as const,
      date: st.date,
      title: st.subject,
      detail: `Focus ${st.focusRating}/5${st.notes ? ` · ${st.notes}` : ''}`,
      metric: `${st.studyHours.toFixed(1)}h`,
      isDemo: st.isDemo,
      createdAt: st.createdAt,
    })),
    ...caffeineLogs.slice(0, 5).map((c) => ({
      id: `caf-${c.id}`,
      type: 'caffeine' as const,
      date: c.date,
      title: `${c.beverageType} Intake`,
      detail: `At ${c.consumptionTime}${c.notes ? ` · ${c.notes}` : ''}`,
      metric: `${c.caffeineAmount}mg`,
      isDemo: c.isDemo,
      createdAt: c.createdAt,
    })),
  ]
    .sort((a, b) => {
      if (a.date !== b.date) return b.date.localeCompare(a.date);
      return b.createdAt.localeCompare(a.createdAt);
    })
    .slice(0, 10);

  const demoCount =
    sleepLogs.filter((s) => s.isDemo).length +
    studyLogs.filter((s) => s.isDemo).length +
    caffeineLogs.filter((c) => c.isDemo).length;

  const demoScenarioApplied =
    sleepLogs.some((s) => s.date === todayStr && s.bedtime === '23:30' && s.wakeTime === '07:30') &&
    studyLogs.some(
      (st) => st.date === todayStr && st.subject === 'Algorithms' && st.focusRating === 5,
    );

  return {
    daysWindow: validWindow,
    hasDemoData: demoCount > 0,
    demoCount,
    demoScenarioApplied,
    totalSleepLogs: sleepLogs.length,
    totalStudyLogs: studyLogs.length,
    lastNightSleep: lastNight
      ? {
          duration: lastNight.duration,
          date: lastNight.date,
          bedtime: lastNight.bedtime,
          wakeTime: lastNight.wakeTime,
          quality: lastNight.sleepQuality,
        }
      : {
          duration: null,
          date: null,
          bedtime: null,
          wakeTime: null,
          quality: null,
        },
    averageWeeklySleep,
    totalStudyHoursThisWeek,
    averageFocusRating,
    weeklySleepDebt: sleepDebt.weeklyCumulativeDebt,
    consistencyStatus: sleepDebt.consistencyStatus,
    dailySeries: series,
    subjectStats,
    recentActivity,
    correlation,
    sleepDebt,
    insights,
    examPerformance,
    latestEntryDate,
  };
}
