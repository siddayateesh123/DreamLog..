import type { SqliteDatabase } from '../config/database.ts';
import { logger } from '../config/logger.ts';
import {
  calculateSleepDuration,
  generateProtectiveExamTimetable,
  getLocalDateStr,
} from '../../src/shared/math.ts';
import type { ExamSchedule } from '../../src/shared/types.ts';
import { UserRepository } from '../repositories/userRepository.ts';
import { rebuildDailyMetricsForUser } from './analyticsService.ts';

interface DemoDayTemplate {
  bedtime: string;
  wakeTime: string;
  quality: number;
  sleepNotes: string;
  sessions: Array<{
    subject: string;
    hours: number;
    focus: number;
    startTime: string;
    endTime: string;
    notes: string;
  }>;
  caffeine?: Array<{
    type: 'Coffee' | 'Tea' | 'Other';
    time: string;
    mg: number;
    notes: string;
  }>;
}

/**
 * 21-day sample dataset tuned so:
 * - Sleep spans 5.0h to 9.0h
 * - Daily study totals span 2.0h to 8.0h
 * - Focus spans 1 to 5 with realistic variation and outliers
 * - Pearson r over the 21 seeded days = +0.78 (0.7781)
 * - Adding today's Demo Scenario (8.0h sleep, 4.5h Algorithms, 5/5 focus) yields r = +0.78 (0.7793)
 */
const DEMO_21_DAYS: DemoDayTemplate[] = [
  {
    bedtime: '23:15',
    wakeTime: '07:00',
    quality: 4,
    sleepNotes: 'Steady wind-down before midnight',
    sessions: [
      { subject: 'Algorithms', hours: 3.5, focus: 4, startTime: '09:30', endTime: '13:00', notes: 'Graph traversal problem set' },
      { subject: 'Linear Algebra', hours: 2.0, focus: 4, startTime: '15:00', endTime: '17:00', notes: 'Eigenvalue proofs' },
    ],
    caffeine: [{ type: 'Coffee', time: '08:30', mg: 95, notes: 'Morning filter coffee' }],
  },
  {
    bedtime: '00:45',
    wakeTime: '06:45',
    quality: 3,
    sleepNotes: 'Stayed up finishing lab writeup',
    sessions: [
      { subject: 'Operating Systems', hours: 4.0, focus: 3, startTime: '10:00', endTime: '14:00', notes: 'Virtual memory paging' },
    ],
    caffeine: [
      { type: 'Coffee', time: '09:00', mg: 110, notes: 'Drip coffee' },
      { type: 'Tea', time: '16:30', mg: 45, notes: 'Afternoon green tea' },
    ],
  },
  {
    bedtime: '01:45',
    wakeTime: '06:45',
    quality: 1,
    sleepNotes: 'Short 5h night; struggled with morning recall',
    sessions: [
      { subject: 'Organic Chemistry', hours: 2.0, focus: 1, startTime: '13:00', endTime: '15:00', notes: 'Very low focus after short sleep' },
    ],
    caffeine: [
      { type: 'Coffee', time: '08:00', mg: 140, notes: 'Double espresso' },
      { type: 'Other', time: '18:00', mg: 120, notes: 'Energy drink before library' },
    ],
  },
  {
    bedtime: '22:30',
    wakeTime: '07:30',
    quality: 5,
    sleepNotes: 'Deep 9h restorative recovery sleep',
    sessions: [
      { subject: 'Algorithms', hours: 4.5, focus: 5, startTime: '09:00', endTime: '13:30', notes: 'Dynamic programming mastery' },
      { subject: 'Data Structures', hours: 2.0, focus: 4, startTime: '15:30', endTime: '17:30', notes: 'Balanced BST implementation' },
    ],
    caffeine: [{ type: 'Tea', time: '09:00', mg: 40, notes: 'Morning matcha' }],
  },
  {
    bedtime: '23:45',
    wakeTime: '07:00',
    quality: 4,
    sleepNotes: 'Good sleep continuity',
    sessions: [
      { subject: 'Macroeconomics', hours: 3.5, focus: 4, startTime: '10:30', endTime: '14:00', notes: 'Monetary policy models' },
    ],
  },
  {
    bedtime: '01:00',
    wakeTime: '07:00',
    quality: 3,
    sleepNotes: 'Short sleep but calm morning routine',
    sessions: [
      { subject: 'Linear Algebra', hours: 4.5, focus: 4, startTime: '11:00', endTime: '15:30', notes: 'SVD practice problems' },
    ],
    caffeine: [{ type: 'Coffee', time: '14:30', mg: 95, notes: 'Afternoon iced coffee' }],
  },
  {
    bedtime: '22:45',
    wakeTime: '07:15',
    quality: 5,
    sleepNotes: 'Weekend deep recovery before heavy study day',
    sessions: [
      { subject: 'Operating Systems', hours: 4.0, focus: 5, startTime: '09:00', endTime: '13:00', notes: 'Thread synchronization lab' },
      { subject: 'Algorithms', hours: 4.0, focus: 4, startTime: '14:30', endTime: '18:30', notes: 'Full 8h peak exam prep day' },
    ],
  },
  {
    bedtime: '23:45',
    wakeTime: '07:00',
    quality: 3,
    sleepNotes: 'Woke up feeling mentally fatigued despite 7.25h',
    sessions: [
      { subject: 'Algorithms', hours: 5.0, focus: 2, startTime: '09:30', endTime: '14:30', notes: 'Frequent distractions during proofs' },
    ],
    caffeine: [{ type: 'Coffee', time: '08:45', mg: 95, notes: 'Morning pour-over' }],
  },
  {
    bedtime: '01:30',
    wakeTime: '06:45',
    quality: 2,
    sleepNotes: 'Quiz prep ran too late',
    sessions: [
      { subject: 'Organic Chemistry', hours: 2.5, focus: 2, startTime: '13:30', endTime: '16:00', notes: 'Hard to sustain focus' },
    ],
    caffeine: [
      { type: 'Coffee', time: '09:15', mg: 120, notes: 'Cold brew' },
      { type: 'Coffee', time: '17:30', mg: 95, notes: 'Evening coffee' },
    ],
  },
  {
    bedtime: '23:30',
    wakeTime: '07:00',
    quality: 3,
    sleepNotes: 'Moderate 7h 30m rest',
    sessions: [
      { subject: 'Data Structures', hours: 4.0, focus: 3, startTime: '09:30', endTime: '13:30', notes: 'Heaps & priority queues' },
    ],
  },
  {
    bedtime: '22:45',
    wakeTime: '07:00',
    quality: 4,
    sleepNotes: 'Zero caffeine after noon helped',
    sessions: [
      { subject: 'Linear Algebra', hours: 4.0, focus: 4, startTime: '09:00', endTime: '13:00', notes: 'Orthogonal projections' },
      { subject: 'Algorithms', hours: 2.0, focus: 4, startTime: '15:00', endTime: '17:00', notes: 'Shortest path review' },
    ],
    caffeine: [{ type: 'Tea', time: '09:30', mg: 45, notes: 'Earl grey' }],
  },
  {
    bedtime: '00:30',
    wakeTime: '06:45',
    quality: 3,
    sleepNotes: 'Slightly short night',
    sessions: [
      { subject: 'Macroeconomics', hours: 5.5, focus: 3, startTime: '10:00', endTime: '15:30', notes: 'Reading-heavy day' },
    ],
  },
  {
    bedtime: '23:45',
    wakeTime: '06:30',
    quality: 4,
    sleepNotes: 'Early morning seminar',
    sessions: [
      { subject: 'Operating Systems', hours: 3.5, focus: 4, startTime: '11:00', endTime: '14:30', notes: 'File system design' },
    ],
  },
  {
    bedtime: '23:00',
    wakeTime: '07:30',
    quality: 4,
    sleepNotes: 'Long uninterrupted sleep',
    sessions: [
      { subject: 'Algorithms', hours: 2.5, focus: 4, startTime: '09:30', endTime: '12:00', notes: 'Flow networks' },
      { subject: 'Macroeconomics', hours: 2.0, focus: 3, startTime: '14:00', endTime: '16:00', notes: 'Policy case review' },
    ],
    caffeine: [{ type: 'Coffee', time: '09:00', mg: 95, notes: 'Morning coffee' }],
  },
  {
    bedtime: '01:15',
    wakeTime: '06:45',
    quality: 2,
    sleepNotes: 'Restless sleep after late study',
    sessions: [
      { subject: 'Organic Chemistry', hours: 3.0, focus: 2, startTime: '13:00', endTime: '16:00', notes: 'Frequent distractions' },
    ],
    caffeine: [{ type: 'Coffee', time: '16:15', mg: 115, notes: 'Late afternoon latte' }],
  },
  {
    bedtime: '23:15',
    wakeTime: '07:00',
    quality: 3,
    sleepNotes: 'Moderate sleep quality despite 7.75h',
    sessions: [
      { subject: 'Data Structures', hours: 4.0, focus: 3, startTime: '09:30', endTime: '13:30', notes: 'Trie & suffix trees' },
      { subject: 'Macroeconomics', hours: 2.0, focus: 3, startTime: '15:00', endTime: '17:00', notes: 'Case study notes' },
    ],
    caffeine: [{ type: 'Tea', time: '10:00', mg: 40, notes: 'Green tea' }],
  },
  {
    bedtime: '00:15',
    wakeTime: '06:45',
    quality: 3,
    sleepNotes: 'Moderate sleep duration',
    sessions: [
      { subject: 'Linear Algebra', hours: 4.0, focus: 3, startTime: '10:00', endTime: '14:00', notes: 'Matrix decompositions' },
    ],
    caffeine: [{ type: 'Coffee', time: '11:30', mg: 95, notes: 'Mid-morning coffee' }],
  },
  {
    bedtime: '22:45',
    wakeTime: '07:30',
    quality: 5,
    sleepNotes: 'Best focus morning of the week',
    sessions: [
      { subject: 'Algorithms', hours: 5.0, focus: 5, startTime: '09:00', endTime: '14:00', notes: 'NP-completeness reductions' },
    ],
    caffeine: [{ type: 'Tea', time: '08:45', mg: 45, notes: 'Matcha latte' }],
  },
  {
    bedtime: '01:15',
    wakeTime: '07:00',
    quality: 2,
    sleepNotes: 'Group project deadline',
    sessions: [
      { subject: 'Operating Systems', hours: 6.5, focus: 2, startTime: '10:00', endTime: '16:30', notes: 'Long grind, diminishing returns' },
    ],
    caffeine: [
      { type: 'Coffee', time: '08:30', mg: 130, notes: 'Strong cold brew' },
      { type: 'Other', time: '17:00', mg: 85, notes: 'Yerba mate' },
    ],
  },
  {
    bedtime: '23:30',
    wakeTime: '07:00',
    quality: 4,
    sleepNotes: 'Recovered rhythm cleanly',
    sessions: [
      { subject: 'Data Structures', hours: 4.0, focus: 4, startTime: '09:30', endTime: '13:30', notes: 'AVL rotations practice' },
    ],
    caffeine: [{ type: 'Coffee', time: '09:15', mg: 95, notes: 'Morning coffee' }],
  },
  {
    bedtime: '00:00',
    wakeTime: '07:00',
    quality: 3,
    sleepNotes: 'Steady 7h night before demo day',
    sessions: [
      { subject: 'Linear Algebra', hours: 3.5, focus: 3, startTime: '10:00', endTime: '13:30', notes: 'Practice exam walkthrough' },
    ],
    caffeine: [{ type: 'Tea', time: '10:30', mg: 40, notes: 'Black tea' }],
  },
];

function seedDemoExamResultsForUser(db: SqliteDatabase, userId: number) {
  const existingCount = (
    db
      .prepare('SELECT COUNT(*) as cnt FROM exam_results WHERE userId = ? AND isDemo = 1')
      .get(userId) as { cnt: number }
  ).cnt;
  if (existingCount > 0) return;

  const nowIso = new Date().toISOString();
  const insertResult = db.prepare(
    `INSERT INTO exam_results (userId, subject, examDate, scorePercent, notes, isDemo, createdAt)
     VALUES (?, ?, ?, ?, ?, 1, ?)`,
  );
  insertResult.run(
    userId,
    'Organic Chemistry',
    getLocalDateStr(-15),
    72,
    'Midterm 1 — following shorter pre-exam sleep nights',
    nowIso,
  );
  insertResult.run(
    userId,
    'Linear Algebra',
    getLocalDateStr(-9),
    84,
    'Midterm 2 — moderate pre-exam rest window',
    nowIso,
  );
  insertResult.run(
    userId,
    'Algorithms',
    getLocalDateStr(-3),
    93,
    'Quiz 3 — strong 3-night pre-exam sleep consistency',
    nowIso,
  );
}

export function seedDemoDataForUser(db: SqliteDatabase, userId = 1): void {
  const nowIso = new Date().toISOString();
  const userRepo = new UserRepository(db);
  const settings = userRepo.ensureSettingsForUser(userId, 'Maya Lin');

  const insertSleep = db.prepare(
    `INSERT INTO sleep_logs (userId, date, bedtime, wakeTime, duration, sleepQuality, notes, isDemo, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)`,
  );
  const insertStudy = db.prepare(
    `INSERT INTO study_logs (userId, date, subject, studyHours, focusRating, startTime, endTime, notes, isDemo, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`,
  );
  const insertCaffeine = db.prepare(
    `INSERT INTO caffeine_logs (userId, date, beverageType, consumptionTime, caffeineAmount, notes, isDemo, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, 1, ?)`,
  );

  const tx = db.transaction(() => {
    for (let i = 0; i < DEMO_21_DAYS.length; i++) {
      const offset = i - 21; // -21 ... -1
      const dateStr = getLocalDateStr(offset);
      const day = DEMO_21_DAYS[i];
      const duration = calculateSleepDuration(day.bedtime, day.wakeTime);

      const existingSleep = db
        .prepare('SELECT id FROM sleep_logs WHERE userId = ? AND date = ?')
        .get(userId, dateStr);
      if (!existingSleep) {
        insertSleep.run(
          userId,
          dateStr,
          day.bedtime,
          day.wakeTime,
          duration,
          day.quality,
          day.sleepNotes,
          nowIso,
        );
      }

      for (const s of day.sessions) {
        insertStudy.run(
          userId,
          dateStr,
          s.subject,
          s.hours,
          s.focus,
          s.startTime,
          s.endTime,
          s.notes,
          nowIso,
        );
      }

      if (day.caffeine) {
        for (const c of day.caffeine) {
          insertCaffeine.run(userId, dateStr, c.type, c.time, c.mg, c.notes, nowIso);
        }
      }
    }

    seedDemoExamResultsForUser(db, userId);

    const existingExams = (
      db.prepare('SELECT COUNT(*) as cnt FROM exam_schedules WHERE userId = ?').get(userId) as {
        cnt: number;
      }
    ).cnt;
    if (existingExams === 0) {
      const insertExam = db.prepare(
        `INSERT INTO exam_schedules (userId, examDate, subject, topics, priority, estimatedHours, createdAt)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
      );
      insertExam.run(
        userId,
        getLocalDateStr(4),
        'Algorithms',
        'Dynamic Programming, Graph Traversal, Network Flow, NP-Completeness',
        'High',
        10,
        nowIso,
      );
      insertExam.run(
        userId,
        getLocalDateStr(7),
        'Linear Algebra',
        'Eigenvalues, SVD, Orthogonal Projections',
        'Medium',
        7,
        nowIso,
      );
      insertExam.run(
        userId,
        getLocalDateStr(10),
        'Operating Systems',
        'Virtual Memory, Thread Synchronization, File Systems',
        'Medium',
        6,
        nowIso,
      );

      const exams = db
        .prepare('SELECT * FROM exam_schedules WHERE userId = ?')
        .all(userId) as ExamSchedule[];
      const generated = generateProtectiveExamTimetable(
        exams,
        settings.dailyAvailableHours,
        settings.preferredWakeTime,
        getLocalDateStr(0),
      );
      const insertTask = db.prepare(
        `INSERT INTO exam_plan_tasks (userId, date, startTime, endTime, title, subject, type, completed, schedulingReason)
         VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)`,
      );
      for (const t of generated.tasks) {
        insertTask.run(
          userId,
          t.date,
          t.startTime,
          t.endTime,
          t.title,
          t.subject,
          t.type,
          t.schedulingReason ?? '',
        );
      }
    }

    userRepo.setDemoCleared(userId, false);
  });

  tx();
  rebuildDailyMetricsForUser(db, userId);
  logger.info('Seeded 21-day demo dataset for workspace', { userId });
}

export function clearDemoDataForUser(db: SqliteDatabase, userId = 1): void {
  const userRepo = new UserRepository(db);
  db.transaction(() => {
    db.prepare('DELETE FROM sleep_logs WHERE userId = ? AND isDemo = 1').run(userId);
    db.prepare('DELETE FROM study_logs WHERE userId = ? AND isDemo = 1').run(userId);
    db.prepare('DELETE FROM caffeine_logs WHERE userId = ? AND isDemo = 1').run(userId);
    db.prepare('DELETE FROM exam_results WHERE userId = ? AND isDemo = 1').run(userId);
    userRepo.setDemoCleared(userId, true);
  })();
  rebuildDailyMetricsForUser(db, userId);
  logger.info('Cleared demo dataset entries for workspace', { userId });
}

export function resetDemoDataForUser(db: SqliteDatabase, userId = 1): void {
  db.transaction(() => {
    db.prepare('DELETE FROM sleep_logs WHERE userId = ? AND isDemo = 1').run(userId);
    db.prepare('DELETE FROM study_logs WHERE userId = ? AND isDemo = 1').run(userId);
    db.prepare('DELETE FROM caffeine_logs WHERE userId = ? AND isDemo = 1').run(userId);
    db.prepare('DELETE FROM exam_results WHERE userId = ? AND isDemo = 1').run(userId);
  })();
  seedDemoDataForUser(db, userId);
}

export function runDemoScenarioTodayForUser(db: SqliteDatabase, userId = 1): void {
  const today = getLocalDateStr(0);
  const nowIso = new Date().toISOString();
  const bedtime = '23:30';
  const wakeTime = '07:30';
  const duration = calculateSleepDuration(bedtime, wakeTime); // 8.0

  db.transaction(() => {
    db.prepare('DELETE FROM sleep_logs WHERE userId = ? AND date = ?').run(userId, today);
    db.prepare(
      `INSERT INTO sleep_logs (userId, date, bedtime, wakeTime, duration, sleepQuality, notes, isDemo, createdAt)
       VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)`,
    ).run(
      userId,
      today,
      bedtime,
      wakeTime,
      duration,
      4,
      'Demo Scenario: 11:30 PM -> 7:30 AM (8.0h)',
      nowIso,
    );

    db.prepare('DELETE FROM study_logs WHERE userId = ? AND date = ? AND subject = ?').run(
      userId,
      today,
      'Algorithms',
    );
    db.prepare(
      `INSERT INTO study_logs (userId, date, subject, studyHours, focusRating, startTime, endTime, notes, isDemo, createdAt)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?)`,
    ).run(
      userId,
      today,
      'Algorithms',
      4.5,
      5,
      '09:00',
      '13:30',
      '5/5 - Deep Focus (Demo Scenario)',
      nowIso,
    );
  })();

  rebuildDailyMetricsForUser(db, userId);
  logger.info('Executed Demo Scenario log for today', { userId });
}

export function resetDemoScenarioTodayForUser(db: SqliteDatabase, userId = 1): void {
  const today = getLocalDateStr(0);
  db.transaction(() => {
    db.prepare('DELETE FROM sleep_logs WHERE userId = ? AND date = ? AND notes LIKE ?').run(
      userId,
      today,
      '%Demo Scenario%',
    );
    db.prepare('DELETE FROM study_logs WHERE userId = ? AND date = ? AND notes LIKE ?').run(
      userId,
      today,
      '%Demo Scenario%',
    );
  })();
  rebuildDailyMetricsForUser(db, userId);
}

export function ensureDefaultWorkspaceSeeded(db: SqliteDatabase): void {
  const userRepo = new UserRepository(db);
  const demoUser = userRepo.findById(1);
  if (!demoUser) return;
  const settings = userRepo.ensureSettingsForUser(1, demoUser.name);
  const existingSleepCount = (
    db.prepare('SELECT COUNT(*) as cnt FROM sleep_logs WHERE userId = 1').get() as { cnt: number }
  ).cnt;
  if (existingSleepCount === 0 && !settings.demoCleared) {
    seedDemoDataForUser(db, 1);
  }
}
