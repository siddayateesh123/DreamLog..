import type { SqliteDatabase } from '../config/database.ts';
import { logger } from '../config/logger.ts';
import {
  generateProtectiveExamTimetable,
  getLocalDateStr,
  rescheduleMissedExamTasks,
  validateScheduleFeasibility,
} from '../../src/shared/math.ts';
import { ExamRepository } from '../repositories/examRepository.ts';
import { UserRepository } from '../repositories/userRepository.ts';

export class ExamPlannerService {
  private readonly examsRepo: ExamRepository;
  private readonly userRepo: UserRepository;

  constructor(private readonly db: SqliteDatabase) {
    this.examsRepo = new ExamRepository(db);
    this.userRepo = new UserRepository(db);
  }

  generatePlan(
    userId: number,
    dailyAvailableHours?: number,
    preferredWakeTime?: string,
  ) {
    const settings = this.userRepo.getSettings(userId);
    const safeHours = Math.max(
      1,
      Math.min(8, Number(dailyAvailableHours) || settings.dailyAvailableHours),
    );
    const wakeTime = preferredWakeTime || settings.preferredWakeTime;

    this.userRepo.updateSettings(userId, {
      ...settings,
      dailyAvailableHours: safeHours,
      preferredWakeTime: wakeTime,
    });

    const exams = this.examsRepo.findExamsByUser(userId);
    const generated = generateProtectiveExamTimetable(
      exams,
      safeHours,
      wakeTime,
      getLocalDateStr(0),
    );
    const savedTasks = this.examsRepo.replacePlanTasksForUser(userId, generated.tasks);

    logger.info('Generated sleep-protected exam timetable', {
      userId,
      examsCount: exams.length,
      tasksCount: savedTasks.length,
      feasible: generated.feasibility.feasible,
    });

    return {
      ...generated,
      tasks: savedTasks,
    };
  }

  rescheduleMissed(
    userId: number,
    missedTaskIds?: number[],
    dailyAvailableHours?: number,
    preferredWakeTime?: string,
  ) {
    const settings = this.userRepo.getSettings(userId);
    const safeHours = Math.max(
      1,
      Math.min(8, Number(dailyAvailableHours) || settings.dailyAvailableHours),
    );
    const wakeTime = preferredWakeTime || settings.preferredWakeTime;

    const existingTasks = this.examsRepo.findPlanTasksByUser(userId);
    const exams = this.examsRepo.findExamsByUser(userId);

    const rescheduled = rescheduleMissedExamTasks(
      existingTasks,
      exams,
      safeHours,
      wakeTime,
      getLocalDateStr(0),
      missedTaskIds,
    );

    const savedTasks = this.examsRepo.replacePlanTasksForUser(userId, rescheduled.tasks);
    logger.info('Rescheduled missed exam tasks with sleep protection', {
      userId,
      rescheduledCount: rescheduled.rescheduledCount,
      rescheduledHours: rescheduled.rescheduledHours,
      feasible: rescheduled.feasibility.feasible,
    });

    return {
      ...rescheduled,
      tasks: savedTasks,
    };
  }

  getFeasibility(userId: number) {
    const settings = this.userRepo.getSettings(userId);
    const exams = this.examsRepo.findExamsByUser(userId);
    const tasks = this.examsRepo.findPlanTasksByUser(userId);
    return validateScheduleFeasibility(
      tasks,
      exams,
      settings.dailyAvailableHours,
      settings.preferredWakeTime,
      getLocalDateStr(0),
    );
  }
}
