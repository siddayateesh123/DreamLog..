import { db } from './db.ts';
import {
  computeExamPerformanceAnalysis,
  getDashboardAnalyticsForUser,
} from './services/analyticsService.ts';

export { computeExamPerformanceAnalysis };

export function getDashboardAnalytics(daysWindow = 21, userId = 1) {
  return getDashboardAnalyticsForUser(db, userId, daysWindow);
}
