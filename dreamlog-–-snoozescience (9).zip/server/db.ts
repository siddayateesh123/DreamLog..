import { createDatabaseConnection } from './config/database.ts';
import { runMigrations } from './db/migrations.ts';
import { UserRepository } from './repositories/userRepository.ts';
import { rebuildDailyMetricsForUser } from './services/analyticsService.ts';
import {
  clearDemoDataForUser,
  ensureDefaultWorkspaceSeeded,
  resetDemoDataForUser,
  resetDemoScenarioTodayForUser,
  runDemoScenarioTodayForUser,
  seedDemoDataForUser,
} from './services/demoSeedService.ts';

export const db = createDatabaseConnection();

export function initDatabase() {
  runMigrations(db);
  ensureDefaultWorkspaceSeeded(db);
}

export function seedDemoData() {
  seedDemoDataForUser(db, 1);
}

export function clearDemoData() {
  clearDemoDataForUser(db, 1);
}

export function resetDemoData() {
  resetDemoDataForUser(db, 1);
}

export function runDemoScenarioToday() {
  runDemoScenarioTodayForUser(db, 1);
}

export function resetDemoScenarioToday() {
  resetDemoScenarioTodayForUser(db, 1);
}

export function getUserSettings(userId = 1) {
  return new UserRepository(db).getSettings(userId);
}

export function rebuildDailyMetrics(userId = 1) {
  rebuildDailyMetricsForUser(db, userId);
}
