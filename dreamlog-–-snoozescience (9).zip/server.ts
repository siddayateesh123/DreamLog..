import express from 'express';
import fs from 'fs';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { createApp } from './server/app.ts';
import { validateEnvironment } from './server/config/env.ts';
import { logger } from './server/config/logger.ts';
import { db } from './server/db.ts';

async function startServer() {
  const env = validateEnvironment();
  const port = env.port;
  const distDir = path.resolve(process.cwd(), 'dist');
  const app = createApp(db, { seedDefaultDemo: true });

  if (env.isProduction && fs.existsSync(distDir)) {
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  const server = app.listen(port, '0.0.0.0', () => {
    logger.info('DreamLog – SnoozeScience server started', {
      port,
      host: '0.0.0.0',
      mode: env.nodeEnv,
    });
  });

  const shutdown = (signal: string) => {
    logger.info('Received shutdown signal, closing HTTP server and SQLite connection', { signal });
    server.close(() => {
      try {
        db.close();
        logger.info('SQLite database connection closed cleanly');
      } catch (err) {
        logger.error('Error closing SQLite database connection', {
          error: err instanceof Error ? err.message : String(err),
        });
      }
      process.exit(0);
    });
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

startServer().catch((err) => {
  logger.error('Fatal server startup failure', {
    error: err instanceof Error ? err.message : String(err),
  });
  process.exit(1);
});
