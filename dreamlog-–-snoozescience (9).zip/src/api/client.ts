import type {
  AuthUser,
  CaffeineLog,
  CorrelationAnalysis,
  DashboardAnalytics,
  ExamPlanTask,
  ExamResult,
  ExamSchedule,
  ScheduleFeasibilityReport,
  SimulationResult,
  SleepDebtSummary,
  SleepLog,
  StudyLog,
  UserSettings,
  WeeklyInsights,
} from '../shared/types.ts';

async function request<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error((data as { error?: string }).error || `Request failed (${res.status})`);
  }
  return data as T;
}

export interface GeneratedPlanResponse {
  tasks: ExamPlanTask[];
  capacityWarning: string | null;
  totalRequestedHours: number;
  totalScheduledHours: number;
  unscheduledHours: number;
  daysPlanned: number;
  decisions: string[];
  feasibility: ScheduleFeasibilityReport;
}

export interface RescheduledPlanResponse extends GeneratedPlanResponse {
  rescheduledCount: number;
  rescheduledHours: number;
}

export const api = {
  getHealth: () =>
    request<{ status: string; migrationsCount: number; latestMigrationVersion: number }>(
      '/api/health',
    ),

  authMe: () => request<{ authenticated: boolean; user: AuthUser | null }>('/api/auth/me'),
  register: (payload: { name: string; email: string; password: string }) =>
    request<{ user: AuthUser; token: string }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  login: (payload: { email: string; password: string }) =>
    request<{ user: AuthUser; token: string }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  demoSession: () =>
    request<{ user: AuthUser; token: string }>('/api/auth/demo-session', {
      method: 'POST',
    }),
  logout: () => request<{ loggedOut: boolean }>('/api/auth/logout', { method: 'POST' }),

  getDashboard: (days = 21) => request<DashboardAnalytics>(`/api/analytics/dashboard?days=${days}`),
  getCorrelation: (days = 21) => request<CorrelationAnalysis>(`/api/analytics/correlation?days=${days}`),
  getSleepDebt: (days = 21) => request<SleepDebtSummary>(`/api/analytics/sleep-debt?days=${days}`),
  getWeeklyInsights: (days = 21) => request<WeeklyInsights>(`/api/analytics/weekly-insights?days=${days}`),
  simulateSleepShift: (payload: { sleepHours: number; nights: number; daysWindow: number }) =>
    request<SimulationResult>('/api/analytics/simulate', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  getSleepLogs: () => request<SleepLog[]>('/api/sleep'),
  createSleepLog: (payload: {
    date: string;
    bedtime: string;
    wakeTime: string;
    sleepQuality: number;
    notes?: string;
  }) => request<SleepLog>('/api/sleep', { method: 'POST', body: JSON.stringify(payload) }),
  updateSleepLog: (
    id: number,
    payload: {
      date: string;
      bedtime: string;
      wakeTime: string;
      sleepQuality: number;
      notes?: string;
    },
  ) => request<SleepLog>(`/api/sleep/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),
  deleteSleepLog: (id: number) => request<{ deleted: boolean }>(`/api/sleep/${id}`, { method: 'DELETE' }),

  getStudyLogs: () => request<StudyLog[]>('/api/study'),
  createStudyLog: (payload: {
    date: string;
    subject: string;
    studyHours: number;
    focusRating: number;
    startTime?: string;
    endTime?: string;
    notes?: string;
  }) => request<StudyLog>('/api/study', { method: 'POST', body: JSON.stringify(payload) }),
  updateStudyLog: (
    id: number,
    payload: {
      date: string;
      subject: string;
      studyHours: number;
      focusRating: number;
      startTime?: string;
      endTime?: string;
      notes?: string;
    },
  ) => request<StudyLog>(`/api/study/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),
  deleteStudyLog: (id: number) => request<{ deleted: boolean }>(`/api/study/${id}`, { method: 'DELETE' }),

  getCaffeineLogs: () => request<CaffeineLog[]>('/api/caffeine'),
  createCaffeineLog: (payload: {
    date: string;
    beverageType: 'Coffee' | 'Tea' | 'Other';
    consumptionTime: string;
    caffeineAmount: number;
    notes?: string;
  }) => request<CaffeineLog>('/api/caffeine', { method: 'POST', body: JSON.stringify(payload) }),
  deleteCaffeineLog: (id: number) =>
    request<{ deleted: boolean }>(`/api/caffeine/${id}`, { method: 'DELETE' }),

  getExams: () => request<ExamSchedule[]>('/api/exams'),
  createExam: (payload: {
    examDate: string;
    subject: string;
    topics: string;
    priority: 'High' | 'Medium' | 'Low';
    estimatedHours: number;
    topicDifficulty?: number;
  }) => request<ExamSchedule>('/api/exams', { method: 'POST', body: JSON.stringify(payload) }),
  updateExam: (
    id: number,
    payload: {
      examDate: string;
      subject: string;
      topics: string;
      priority: 'High' | 'Medium' | 'Low';
      estimatedHours: number;
      topicDifficulty?: number;
    },
  ) => request<ExamSchedule>(`/api/exams/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),
  deleteExam: (id: number) => request<{ deleted: boolean }>(`/api/exams/${id}`, { method: 'DELETE' }),

  getExamPlan: () => request<ExamPlanTask[]>('/api/exams/plan'),
  getExamFeasibility: () => request<ScheduleFeasibilityReport>('/api/exams/feasibility'),
  generateExamPlan: (payload: { dailyAvailableHours: number; preferredWakeTime: string }) =>
    request<GeneratedPlanResponse>('/api/exams/generate', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  rescheduleExamPlan: (payload: {
    missedTaskIds?: number[];
    dailyAvailableHours?: number;
    preferredWakeTime?: string;
  }) =>
    request<RescheduledPlanResponse>('/api/exams/reschedule', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  updateExamPlanTask: (
    id: number,
    payload: Partial<Pick<ExamPlanTask, 'completed' | 'title' | 'startTime' | 'endTime'>>,
  ) => request<ExamPlanTask>(`/api/exams/plan/${id}`, { method: 'PUT', body: JSON.stringify(payload) }),

  getExamResults: () => request<ExamResult[]>('/api/exam-results'),
  createExamResult: (payload: {
    subject: string;
    examDate: string;
    scorePercent: number;
    notes?: string;
  }) => request<ExamResult>('/api/exam-results', { method: 'POST', body: JSON.stringify(payload) }),
  deleteExamResult: (id: number) =>
    request<{ deleted: boolean }>(`/api/exam-results/${id}`, { method: 'DELETE' }),

  getSettings: () => request<UserSettings>('/api/settings'),
  updateSettings: (payload: Partial<UserSettings>) =>
    request<UserSettings>('/api/settings', { method: 'PUT', body: JSON.stringify(payload) }),

  clearDemoData: () => request<{ cleared: boolean }>('/api/demo/clear', { method: 'POST' }),
  resetDemoData: () => request<{ reset: boolean }>('/api/demo/reset', { method: 'POST' }),
  runDemoScenario: () => request<DashboardAnalytics>('/api/demo/run-scenario', { method: 'POST' }),
  resetDemoScenario: () =>
    request<DashboardAnalytics>('/api/demo/reset-scenario', { method: 'POST' }),
};
