import type { jsPDF as JsPdfType } from 'jspdf';
import { EXAM_CONFIDENCE_WARNING_TEXT, formatShortDate } from './math.ts';
import type { DashboardAnalytics, UserSettings } from './types.ts';

export function sanitizePdfText(input: string): string {
  return input
    .replace(/\u2192/g, '->')
    .replace(/\u2265/g, '>=')
    .replace(/\u2264/g, '<=')
    .replace(/\u00d7/g, 'x')
    .replace(/\u00b1/g, '+/-')
    .replace(/[\u2013\u2014]/g, '-')
    .replace(/\u2022/g, '-')
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201c\u201d]/g, '"')
    .replace(/[^\x20-\x7E]/g, ' ');
}

export interface WellnessPdfParams {
  JsPDFCtor: typeof JsPdfType;
  analytics: DashboardAnalytics;
  settings: UserSettings;
  daysWindow: number;
  generatedDate?: string;
  chartImages?: string[];
}

export interface WellnessPdfResult {
  doc: JsPdfType;
  filename: string;
  sections: string[];
  pageCount: number;
}

export function buildWellnessReportPdf({
  JsPDFCtor,
  analytics,
  settings,
  daysWindow,
  generatedDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  }),
  chartImages = [],
}: WellnessPdfParams): WellnessPdfResult {
  const doc = new JsPDFCtor({ orientation: 'portrait', unit: 'pt', format: 'a4' });
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 42;
  const contentWidth = pageWidth - margin * 2;
  const sections: string[] = [];
  let y = 44;

  const sleepDays = analytics.dailySeries.filter((d) => d.totalSleep > 0);
  const totalSleepHours = Math.round(sleepDays.reduce((a, d) => a + d.totalSleep, 0) * 100) / 100;
  const avgNightlySleep =
    sleepDays.length > 0 ? Math.round((totalSleepHours / sleepDays.length) * 100) / 100 : 0;
  const totalStudyHours =
    Math.round(analytics.dailySeries.reduce((a, d) => a + d.totalStudyHours, 0) * 100) / 100;

  const periodLabel =
    analytics.dailySeries.length > 0
      ? `${formatShortDate(analytics.dailySeries[0].date)} - ${formatShortDate(analytics.dailySeries[analytics.dailySeries.length - 1].date)} (Last ${daysWindow} days)`
      : `Last ${daysWindow} days`;

  const examPerf = analytics.examPerformance;

  const pdfText = (
    text: string | string[],
    x: number,
    posY: number,
    options?: { align?: 'left' | 'center' | 'right' },
  ) => {
    const clean = Array.isArray(text) ? text.map(sanitizePdfText) : sanitizePdfText(text);
    doc.text(clean, x, posY, options);
  };

  const ensureSpace = (needed: number) => {
    if (y + needed > pageHeight - 54) {
      doc.addPage();
      y = 48;
    }
  };

  // Header Banner
  sections.push('Header');
  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, pageWidth, 88, 'F');
  doc.setTextColor(248, 250, 252);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  pdfText('DreamLog - SnoozeScience', margin, 36);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(11);
  doc.setTextColor(148, 163, 184);
  pdfText('Student Sleep & Academic Wellness Report', margin, 56);
  doc.setFontSize(9);
  pdfText(`Generated: ${generatedDate}`, pageWidth - margin, 36, { align: 'right' });
  pdfText(`Period: ${periodLabel}`, pageWidth - margin, 56, { align: 'right' });

  y = 110;
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  pdfText(`Student: ${settings.studentName || 'Student'}`, margin, y);
  if (analytics.hasDemoData) {
    doc.setFontSize(9);
    doc.setTextColor(180, 83, 9);
    pdfText('Includes DEMO DATA records', pageWidth - margin, y, { align: 'right' });
  }

  // KPI Summary Grid (Sleep + Study + Correlation)
  sections.push('KPI Summary');
  y += 20;
  const corrLabel =
    analytics.correlation.hasConfidence && analytics.correlation.r !== null
      ? `r = ${analytics.correlation.r >= 0 ? '+' : ''}${analytics.correlation.r.toFixed(2)} (n=${analytics.correlation.observationCount})`
      : `Needs >=7 paired days (n=${analytics.correlation.observationCount})`;
  const kpis = [
    ['Total Sleep Hours', `${totalSleepHours.toFixed(1)} hrs`],
    ['Avg Nightly Sleep', `${avgNightlySleep.toFixed(2)} hrs`],
    [
      'Weekly Sleep Debt (7d)',
      `${analytics.weeklySleepDebt.toFixed(2)} hrs (${analytics.sleepDebt.weeklyLoggedNights}/7 nights)`,
    ],
    ['Total Study Hours', `${totalStudyHours.toFixed(1)} hrs`],
    ['Average Focus Rating', `${analytics.averageFocusRating.toFixed(2)} / 5`],
    ['Pearson Correlation (r)', corrLabel],
  ];

  doc.setDrawColor(203, 213, 225);
  doc.setFillColor(248, 250, 252);
  const colW = contentWidth / 3;
  kpis.forEach((item, idx) => {
    const col = idx % 3;
    const row = Math.floor(idx / 3);
    const bx = margin + col * colW;
    const by = y + row * 44;
    doc.rect(bx, by, colW - 6, 38, 'FD');
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    pdfText(item[0], bx + 8, by + 14);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(15, 23, 42);
    pdfText(item[1], bx + 8, by + 29);
  });

  y += 106;

  // Correlation & Regression Details Box
  sections.push('Correlation & OLS Regression Analysis');
  ensureSpace(64);
  doc.setDrawColor(203, 213, 225);
  doc.setFillColor(248, 250, 252);
  doc.rect(margin, y, contentWidth, 52, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  pdfText('Correlation & OLS Regression Analysis', margin + 10, y + 16);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(51, 65, 85);
  const olsDetail = analytics.correlation.ols
    ? `Category: ${analytics.correlation.category} | OLS Fit: ${analytics.correlation.ols.equation} | Mean Sleep: ${analytics.correlation.meanSleep?.toFixed(2) ?? '-'}h | Mean Focus: ${analytics.correlation.meanFocus?.toFixed(2) ?? '-'}/5`
    : `${analytics.correlation.category} (n = ${analytics.correlation.observationCount}). ${analytics.correlation.confidenceWarning || analytics.correlation.explanation}`;
  const wrappedOls = doc.splitTextToSize(sanitizePdfText(olsDetail), contentWidth - 20);
  pdfText(wrappedOls, margin + 10, y + 32);
  y += 66;

  // Chart snapshots (when available from browser canvas elements)
  if (chartImages.length >= 2) {
    sections.push('Visual Analytics Snapshots');
    ensureSpace(175);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    pdfText('Visual Analytics Snapshots (Scatter + OLS Trendline & Weekly Trend)', margin, y);
    y += 12;

    const halfW = (contentWidth - 10) / 2;
    doc.addImage(chartImages[0], 'PNG', margin, y, halfW, 145);
    doc.addImage(chartImages[1], 'PNG', margin + halfW + 10, y, halfW, 145);
    y += 165;
  }

  // Sleep vs Exam Performance Section
  sections.push('Sleep vs Exam Performance');
  ensureSpace(90);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  pdfText('Sleep vs Exam Performance', margin, y);
  y += 14;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(51, 65, 85);
  const examCorrLine =
    examPerf.hasConfidence && examPerf.r !== null
      ? `Pre-exam 3-night sleep vs exam score correlation: r = ${examPerf.r >= 0 ? '+' : ''}${examPerf.r.toFixed(2)} (${examPerf.category}, n = ${examPerf.observationCount} exams).`
      : `${examPerf.confidenceWarning || EXAM_CONFIDENCE_WARNING_TEXT} (${examPerf.observationCount}/5 paired exams logged).`;
  const wrappedCorr = doc.splitTextToSize(sanitizePdfText(examCorrLine), contentWidth);
  pdfText(wrappedCorr, margin, y);
  y += wrappedCorr.length * 12 + 6;

  if (examPerf.points.length === 0) {
    pdfText('No completed exam results recorded yet. Log exam scores in Exam Planner.', margin, y);
    y += 18;
  } else {
    for (const pt of examPerf.points) {
      ensureSpace(22);
      const sleepText =
        pt.preExamAvgSleep !== null
          ? `${pt.preExamAvgSleep.toFixed(2)}h avg sleep (${pt.sleepNightsCount}/3 pre-exam nights)`
          : 'No pre-exam sleep logs';
      const rowLine = `- ${pt.examDate} | ${pt.subject}: ${pt.scorePercent.toFixed(1)}% - ${sleepText}`;
      const wrapped = doc.splitTextToSize(sanitizePdfText(rowLine), contentWidth);
      pdfText(wrapped, margin, y);
      y += wrapped.length * 12 + 3;
    }
    y += 6;
  }

  // Recent Daily Sleep & Study Log Table (last 10 logged days)
  const recentDays = [...analytics.dailySeries].slice(-10).reverse();
  if (recentDays.length > 0) {
    sections.push('Recent Daily Sleep & Study Summary');
    ensureSpace(70);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    pdfText('Recent Daily Sleep & Study Summary (Latest 10 Days)', margin, y);
    y += 14;

    doc.setFillColor(241, 245, 249);
    doc.rect(margin, y - 10, contentWidth, 16, 'F');
    doc.setFontSize(8.5);
    doc.setTextColor(51, 65, 85);
    pdfText('Date', margin + 6, y);
    pdfText('Sleep', margin + 100, y);
    pdfText('Study Hrs', margin + 175, y);
    pdfText('Focus', margin + 255, y);
    pdfText('Debt / Surplus', margin + 325, y);
    y += 14;

    doc.setFont('helvetica', 'normal');
    for (const day of recentDays) {
      ensureSpace(20);
      const surplus =
        day.totalSleep > 0
          ? Math.max(0, Math.round((day.totalSleep - settings.sleepBaselineHours) * 100) / 100)
          : 0;
      const debtCol =
        day.totalSleep <= 0
          ? 'Not logged'
          : day.sleepDebt > 0
            ? `${day.sleepDebt.toFixed(2)}h debt`
            : `+${surplus.toFixed(2)}h surplus`;
      pdfText(day.date, margin + 6, y);
      pdfText(day.totalSleep > 0 ? `${day.totalSleep.toFixed(2)}h` : '-', margin + 100, y);
      pdfText(`${day.totalStudyHours.toFixed(1)}h`, margin + 175, y);
      pdfText(day.averageFocus !== null ? `${day.averageFocus.toFixed(2)}/5` : '-', margin + 255, y);
      pdfText(debtCol, margin + 325, y);
      y += 14;
    }
    y += 8;
  }

  // Summary & Insights
  const writeSection = (title: string, lines: string[]) => {
    const cleanLines = lines.filter((l) => l && l.trim().length > 0);
    if (cleanLines.length === 0) return;
    sections.push(title);
    ensureSpace(40);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    pdfText(title, margin, y);
    y += 14;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9.5);
    doc.setTextColor(51, 65, 85);
    for (const line of cleanLines) {
      const wrapped = doc.splitTextToSize(sanitizePdfText(`- ${line}`), contentWidth);
      ensureSpace(wrapped.length * 12 + 6);
      pdfText(wrapped, margin, y);
      y += wrapped.length * 12 + 4;
    }
    y += 6;
  };

  writeSection('Summary of Findings', [analytics.insights.weeklySummary]);
  writeSection('Weekly Optimization Insights', [
    ...analytics.insights.positiveInsights,
    ...analytics.insights.improvementAreas,
  ]);
  writeSection('Sleep & Study Recommendations', [
    ...analytics.insights.sleepRecommendations,
    ...analytics.insights.studyRecommendations,
  ]);

  // Mandatory Methodological Disclaimer
  sections.push('Methodological Note');
  ensureSpace(56);
  doc.setDrawColor(226, 232, 240);
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, y, contentWidth, 44, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(30, 41, 59);
  pdfText('Methodological Note:', margin + 8, y + 14);
  doc.setFont('helvetica', 'normal');
  pdfText(
    doc.splitTextToSize(
      sanitizePdfText(
        'Statistical correlation measures observed linear association in self-reported logs and does not prove causation. The 8-hour sleep baseline is a tracking reference, not a medical prescription.',
      ),
      contentWidth - 16,
    ),
    margin + 8,
    y + 26,
  );

  // Stamp consistent Page X of Y footers across every page
  const totalPages = doc.getNumberOfPages();
  for (let p = 1; p <= totalPages; p++) {
    doc.setPage(p);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    pdfText('DreamLog - SnoozeScience | Student Wellness Report', margin, pageHeight - 24);
    pdfText(`Page ${p} of ${totalPages}`, pageWidth - margin, pageHeight - 24, {
      align: 'right',
    });
  }

  const filename = `DreamLog_Wellness_Report_${(settings.studentName || 'Student').replace(/\s+/g, '_')}.pdf`;
  return {
    doc,
    filename,
    sections,
    pageCount: totalPages,
  };
}
