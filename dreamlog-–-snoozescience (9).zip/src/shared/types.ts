export type FocusRating = 1 | 2 | 3 | 4 | 5;

export const FOCUS_DESCRIPTIONS: Record<number, string> = {
  1: 'Very Poor Focus',
  2: 'Low Focus',
  3: 'Moderate Focus',
  4: 'Good Focus',
  5: 'Deep Focus',
};

export interface SleepLog {
  id: number;
  date: string; // YYYY-MM-DD
  bedtime: string; // HH:mm
  wakeTime: string; // HH:mm
  duration: number; // decimal hours
  sleepQuality: number; // 1-5
  notes: string;
  isDemo: boolean;
  createdAt: string;
}

export interface StudyLog {
  id: number;
  date: string; // YYYY-MM-DD
  subject: string;
  studyHours: number;
  focusRating: number; // 1-5
  startTime: string;
  endTime: string;
  notes: string;
  isDemo: boolean;
  createdAt: string;
}

export interface CaffeineLog {
  id: number;
  date: string; // YYYY-MM-DD
  beverageType: 'Coffee' | 'Tea' | 'Other';
  consumptionTime: string; // HH:mm
  caffeineAmount: number; // mg
  notes: string;
  isDemo: boolean;
  createdAt: string;
}

export type ExamPriority = 'High' | 'Medium' | 'Low';

export interface ExamSchedule {
  id: number;
  examDate: string; // YYYY-MM-DD
  subject: string;
  topics: string;
  priority: ExamPriority;
  estimatedHours: number;
  topicDifficulty?: number; // 1 (Foundational) to 5 (Very Hard), defaults to 3
  createdAt: string;
}

export interface AuthUser {
  id: number;
  name: string;
  email: string;
  role: 'student' | 'demo';
  createdAt: string;
}

export interface ExamPlanTask {
  id: number;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  title: string;
  subject: string;
  type: 'study' | 'break' | 'meal' | 'sleep';
  completed: boolean;
  schedulingReason?: string;
}

export interface ScheduleFeasibilityReport {
  feasible: boolean;
  requiredHours: number;
  maxPossibleCapacityHours: number;
  maxDailyStudyHours: number;
  minSleepHours: number;
  overlapCount: number;
  midnightCrossingCount: number;
  deficitHours: number;
  summary: string;
  warnings: string[];
}

export interface ExamResult {
  id: number;
  subject: string;
  examDate: string; // YYYY-MM-DD
  scorePercent: number; // 0-100
  notes: string;
  isDemo: boolean;
  createdAt: string;
}

export interface ExamPerformancePoint {
  examId: number;
  subject: string;
  examDate: string;
  scorePercent: number;
  preExamAvgSleep: number | null;
  sleepNightsCount: number;
  notes: string;
}

export interface ExamPerformanceAnalysis {
  results: ExamResult[];
  points: ExamPerformancePoint[];
  r: number | null;
  category: string;
  observationCount: number;
  requiredCount: number;
  hasConfidence: boolean;
  confidenceWarning: string | null;
}

export interface UserSettings {
  studentName: string;
  sleepBaselineHours: number;
  caffeineHalfLifeHours: number;
  preferredWakeTime: string;
  dailyAvailableHours: number;
  onboardingDismissed: boolean;
  demoCleared: boolean;
}

export interface DailyMetricPoint {
  date: string;
  totalSleep: number;
  sleepQuality: number | null;
  bedtime: string | null;
  wakeTime: string | null;
  totalStudyHours: number;
  averageFocus: number | null; // Hour-weighted daily focus average
  studySessionsCount: number;
  subjects: string[];
  sleepDebt: number;
  caffeineTotalMg: number;
  caffeineAtBedtimeMg: number;
  isDemo: boolean;
  hasPairedData: boolean;
  latestUpdated: boolean;
}

export interface OLSRegression {
  slope: number;
  intercept: number;
  equation: string;
  linePoints: Array<{ x: number; y: number }>;
}

export interface CorrelationAnalysis {
  r: number | null;
  category: string;
  explanation: string;
  observationCount: number;
  requiredCount: number;
  hasConfidence: boolean;
  zeroVariance: boolean;
  confidenceWarning: string | null;
  meanSleep: number | null;
  meanFocus: number | null;
  ols: OLSRegression | null;
  points: Array<{
    date: string;
    x: number;
    y: number;
    studyHours: number;
    subjects: string[];
    isDemo: boolean;
    isLatest: boolean;
  }>;
}

export interface SimulationResult {
  sleepHours: number;
  nights: number;
  beforeR: number | null;
  afterR: number | null;
  beforeSlope: number | null;
  afterSlope: number | null;
  beforeOls: OLSRegression | null;
  afterOls: OLSRegression | null;
  projectedPoints: Array<{ x: number; y: number; nightIndex: number }>;
  summarySentence: string;
}

export interface SleepDebtSummary {
  baselineHours: number;
  baselineDisclaimer: string;
  weeklyCumulativeDebt: number;
  weeklyCumulativeSurplus: number;
  weeklyLoggedNights: number;
  weeklyMissingNights: number;
  periodTotalDebt: number;
  averageNightlySleep: number;
  goalCompletionPercent: number;
  consistencyStatus: 'Consistent' | 'Moderate Variance' | 'Inconsistent' | 'Building Baseline';
  sleepStdDevHours: number;
  dailyBreakdown: Array<{
    date: string;
    actualSleep: number;
    debt: number;
    surplus: number;
  }>;
  recommendations: string[];
}

export interface TimetableValidationResult {
  valid: boolean;
  errors: string[];
  maxDailyStudyHours: number;
  minSleepHours: number;
  midnightCrossingCount: number;
  overlapCount: number;
}

export interface WeeklyInsights {
  positiveInsights: string[];
  improvementAreas: string[];
  weeklySummary: string;
  sleepRecommendations: string[];
  studyRecommendations: string[];
  peakEfficiencyDay: string | null;
  focusDeltaPercent: number | null;
}

export interface SubjectStat {
  subject: string;
  totalHours: number;
  sessionsCount: number;
  averageFocus: number;
}

export interface ActivityItem {
  id: string;
  type: 'sleep' | 'study' | 'caffeine';
  date: string;
  title: string;
  detail: string;
  metric: string;
  isDemo: boolean;
  createdAt: string;
}

export interface DashboardAnalytics {
  daysWindow: number;
  hasDemoData: boolean;
  demoCount: number;
  demoScenarioApplied: boolean;
  totalSleepLogs: number;
  totalStudyLogs: number;
  lastNightSleep: {
    duration: number | null;
    date: string | null;
    bedtime: string | null;
    wakeTime: string | null;
    quality: number | null;
  };
  averageWeeklySleep: number;
  totalStudyHoursThisWeek: number;
  averageFocusRating: number;
  weeklySleepDebt: number;
  consistencyStatus: 'Consistent' | 'Moderate Variance' | 'Inconsistent' | 'Building Baseline';
  dailySeries: DailyMetricPoint[];
  subjectStats: SubjectStat[];
  recentActivity: ActivityItem[];
  correlation: CorrelationAnalysis;
  sleepDebt: SleepDebtSummary;
  insights: WeeklyInsights;
  examPerformance: ExamPerformanceAnalysis;
  latestEntryDate: string | null;
}
