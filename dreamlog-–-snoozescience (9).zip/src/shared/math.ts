import type {
  CorrelationAnalysis,
  DailyMetricPoint,
  ExamPlanTask,
  ExamSchedule,
  OLSRegression,
  ScheduleFeasibilityReport,
  SimulationResult,
  SleepDebtSummary,
  TimetableValidationResult,
} from './types.ts';

export const CONFIDENCE_WARNING_TEXT =
  'Needs at least 7 days of logs for statistical confidence';

export const EXAM_CONFIDENCE_WARNING_TEXT =
  'Needs at least 5 exams for confidence';

export function getLocalDateStr(offsetDays = 0): string {
  const now = new Date();
  const utc = Date.UTC(now.getFullYear(), now.getMonth(), now.getDate() + offsetDays);
  const d = new Date(utc);
  const year = d.getUTCFullYear();
  const month = String(d.getUTCMonth() + 1).padStart(2, '0');
  const day = String(d.getUTCDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * DST-safe calendar date arithmetic using UTC midnight so 23h/25h DST days never skip or repeat a date.
 */
export function addDaysToDateStr(dateStr: string, days: number): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  const utcMs = Date.UTC(y, m - 1, d + days);
  const dt = new Date(utcMs);
  return `${dt.getUTCFullYear()}-${String(dt.getUTCMonth() + 1).padStart(2, '0')}-${String(dt.getUTCDate()).padStart(2, '0')}`;
}

export function parseTimeToMinutes(timeStr: string): number {
  const parts = timeStr.split(':');
  if (parts.length !== 2) return NaN;
  const h = Number(parts[0]);
  const m = Number(parts[1]);
  if (!Number.isInteger(h) || !Number.isInteger(m) || h < 0 || h > 23 || m < 0 || m > 59) {
    return NaN;
  }
  return h * 60 + m;
}

export function minutesToTimeStr(totalMinutes: number): string {
  const normalized = ((Math.round(totalMinutes) % 1440) + 1440) % 1440;
  const h = Math.floor(normalized / 60);
  const m = normalized % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

/**
 * Calculates sleep duration in decimal hours between bedtime and wakeTime (HH:mm).
 * If wakeTime is numerically earlier than bedtime, treats wakeTime as the following day.
 * Equal times return 0 (rejected by validation).
 */
export function calculateSleepDuration(bedtime: string, wakeTime: string): number {
  const bedMin = parseTimeToMinutes(bedtime);
  const wakeMin = parseTimeToMinutes(wakeTime);
  if (Number.isNaN(bedMin) || Number.isNaN(wakeMin)) return 0;
  if (bedMin === wakeMin) return 0;

  let diff = wakeMin - bedMin;
  if (diff < 0) {
    diff += 24 * 60;
  }
  return Math.round((diff / 60) * 100) / 100;
}

export function calculateTimeRangeHours(startTime: string, endTime: string): number {
  const startMin = parseTimeToMinutes(startTime);
  const endMin = parseTimeToMinutes(endTime);
  if (Number.isNaN(startMin) || Number.isNaN(endMin) || startMin === endMin) return 0;
  let diff = endMin - startMin;
  if (diff < 0) diff += 24 * 60;
  return Math.round((diff / 60) * 100) / 100;
}

export function formatHoursMinutes(decimalHours: number | null | undefined): string {
  if (decimalHours === null || decimalHours === undefined || Number.isNaN(decimalHours)) {
    return '—';
  }
  const totalMinutes = Math.round(decimalHours * 60);
  const h = Math.floor(totalMinutes / 60);
  const m = totalMinutes % 60;
  return `${h}h ${m}m`;
}

export function formatTime12h(time24: string | null | undefined): string {
  if (!time24) return '—';
  const min = parseTimeToMinutes(time24);
  if (Number.isNaN(min)) return time24;
  const h24 = Math.floor(min / 60);
  const m = min % 60;
  const suffix = h24 >= 12 ? 'PM' : 'AM';
  const h12 = h24 % 12 === 0 ? 12 : h24 % 12;
  return `${h12}:${String(m).padStart(2, '0')} ${suffix}`;
}

export function formatShortDate(dateStr: string): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  if (!y || !m || !d) return dateStr;
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' });
}

export function getWeekdayName(dateStr: string): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  if (!y || !m || !d) return '';
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.toLocaleDateString('en-US', { weekday: 'long', timeZone: 'UTC' });
}

/**
 * Aggregates multiple study sessions on the same calendar date into one daily focus value
 * using an hour-weighted average: sum(studyHours_i * focusRating_i) / sum(studyHours_i).
 */
export function computeWeightedFocus(
  sessions: Array<{ studyHours: number; focusRating: number }>,
): number | null {
  if (sessions.length === 0) return null;
  let weightedSum = 0;
  let totalHours = 0;
  for (const s of sessions) {
    const h = s.studyHours > 0 ? s.studyHours : 0;
    weightedSum += h * s.focusRating;
    totalHours += h;
  }
  if (totalHours <= 0) {
    const simple = sessions.reduce((acc, s) => acc + s.focusRating, 0) / sessions.length;
    return Math.round(simple * 100) / 100;
  }
  return Math.round((weightedSum / totalHours) * 100) / 100;
}

export function interpretPearsonR(r: number): { category: string; explanation: string } {
  if (Math.abs(r) < 0.005) {
    return {
      category: 'No Linear Correlation',
      explanation:
        'No measurable linear relationship appears between sleep duration and focus rating in this window.',
    };
  }
  if (r >= 0.7) {
    return {
      category: 'Strong Positive Correlation',
      explanation:
        'Longer sleep durations are strongly associated with higher study focus ratings across your logged days.',
    };
  }
  if (r >= 0.3) {
    return {
      category: 'Moderate Positive Correlation',
      explanation:
        'Nights with longer sleep show a meaningful tendency toward stronger study focus the next day.',
    };
  }
  if (r > 0) {
    return {
      category: 'Weak Positive Correlation',
      explanation:
        'Longer sleep shows a slight positive link with focus ratings, though other factors also play a role.',
    };
  }
  if (r <= -0.7) {
    return {
      category: 'Strong Negative Correlation',
      explanation:
        'In this window, longer recorded sleep durations coincided with lower focus ratings.',
    };
  }
  if (r <= -0.3) {
    return {
      category: 'Moderate Negative Correlation',
      explanation:
        'Recorded focus ratings tended to dip slightly on days with longer logged sleep in this window.',
    };
  }
  return {
    category: 'Weak Negative Correlation',
    explanation:
      'A slight negative linear drift appears in this sample, likely reflecting small sample noise or timing shifts.',
  };
}

export interface RawCorrelationResult {
  r: number | null;
  category: string;
  explanation: string;
  observationCount: number;
  requiredCount: number;
  hasConfidence: boolean;
  zeroVariance: boolean;
  confidenceWarning: string | null;
  meanX: number | null;
  meanY: number | null;
  ols: OLSRegression | null;
}

export function computePearsonAndOLSFromPoints(
  points: Array<{ x: number; y: number }>,
  requiredCount = 7,
  warningText = CONFIDENCE_WARNING_TEXT,
  clampYRange: [number, number] = [1, 5],
): RawCorrelationResult {
  const n = points.length;
  if (n === 0) {
    return {
      r: null,
      category: 'Insufficient Data',
      explanation: 'Log paired observations on matching dates to begin correlation analysis.',
      observationCount: 0,
      requiredCount,
      hasConfidence: false,
      zeroVariance: false,
      confidenceWarning: warningText,
      meanX: null,
      meanY: null,
      ols: null,
    };
  }

  const meanX = points.reduce((acc, p) => acc + p.x, 0) / n;
  const meanY = points.reduce((acc, p) => acc + p.y, 0) / n;

  if (n < requiredCount) {
    return {
      r: null,
      category: 'Insufficient Observations',
      explanation: `Currently ${n} paired observation${n === 1 ? '' : 's'} logged. Add ${requiredCount - n} more to reach statistical confidence.`,
      observationCount: n,
      requiredCount,
      hasConfidence: false,
      zeroVariance: false,
      confidenceWarning: warningText,
      meanX: Math.round(meanX * 100) / 100,
      meanY: Math.round(meanY * 100) / 100,
      ols: null,
    };
  }

  let sumDX2 = 0;
  let sumDY2 = 0;
  let sumDXDY = 0;

  for (const p of points) {
    const dx = p.x - meanX;
    const dy = p.y - meanY;
    sumDX2 += dx * dx;
    sumDY2 += dy * dy;
    sumDXDY += dx * dy;
  }

  if (sumDX2 < 1e-9 || sumDY2 < 1e-9) {
    return {
      r: null,
      category: 'Undefined (Zero Variance)',
      explanation:
        sumDX2 < 1e-9
          ? 'All logged X values in this range are identical, so a linear slope cannot be calculated.'
          : 'All logged Y values in this range are identical, so Pearson correlation is undefined.',
      observationCount: n,
      requiredCount,
      hasConfidence: true,
      zeroVariance: true,
      confidenceWarning: null,
      meanX: Math.round(meanX * 100) / 100,
      meanY: Math.round(meanY * 100) / 100,
      ols: null,
    };
  }

  const normZero = (v: number) => (Object.is(v, -0) ? 0 : v);
  const rawR = sumDXDY / Math.sqrt(sumDX2 * sumDY2);
  const clampedR = Math.max(-1, Math.min(1, rawR));
  const roundedR = normZero(Math.round(clampedR * 100) / 100);

  const slope = normZero(sumDXDY / sumDX2);
  const intercept = normZero(meanY - slope * meanX);
  const minX = Math.min(...points.map((p) => p.x));
  const maxX = Math.max(...points.map((p) => p.x));
  let x1 = Math.floor((minX - 0.3) * 10) / 10;
  let x2 = Math.ceil((maxX + 0.3) * 10) / 10;

  const [minYBound, maxYBound] = clampYRange;
  const clipEndpointToYBounds = (x: number): { x: number; y: number } => {
    const rawY = slope * x + intercept;
    if (Math.abs(slope) > 1e-9) {
      if (rawY < minYBound) {
        const xClip = (minYBound - intercept) / slope;
        return { x: Math.round(xClip * 1000) / 1000, y: minYBound };
      }
      if (rawY > maxYBound) {
        const xClip = (maxYBound - intercept) / slope;
        return { x: Math.round(xClip * 1000) / 1000, y: maxYBound };
      }
    }
    return {
      x: Math.round(x * 1000) / 1000,
      y: Math.max(minYBound, Math.min(maxYBound, Math.round(rawY * 1000) / 1000)),
    };
  };

  if (x1 > x2) {
    const tmp = x1;
    x1 = x2;
    x2 = tmp;
  }
  const p1 = clipEndpointToYBounds(x1);
  const p2 = clipEndpointToYBounds(x2);

  const sign = intercept >= 0 ? '+' : '-';
  const equation = `y = ${slope.toFixed(2)}x ${sign} ${Math.abs(intercept).toFixed(2)}`;
  const { category, explanation } = interpretPearsonR(roundedR);

  return {
    r: roundedR,
    category,
    explanation,
    observationCount: n,
    requiredCount,
    hasConfidence: true,
    zeroVariance: false,
    confidenceWarning: null,
    meanX: normZero(Math.round(meanX * 100) / 100),
    meanY: normZero(Math.round(meanY * 100) / 100),
    ols: {
      slope: normZero(Math.round(slope * 1000) / 1000),
      intercept: normZero(Math.round(intercept * 1000) / 1000),
      equation,
      linePoints: [p1, p2],
    },
  };
}

export function computeCorrelationAnalysis(
  dailyPoints: DailyMetricPoint[],
  latestEntryDate: string | null = null,
): CorrelationAnalysis {
  const paired = dailyPoints.filter(
    (d) => d.totalSleep > 0 && d.averageFocus !== null && d.studySessionsCount > 0,
  );

  const points = paired.map((d) => ({
    date: d.date,
    x: Math.round(d.totalSleep * 100) / 100,
    y: Math.round((d.averageFocus as number) * 100) / 100,
    studyHours: Math.round(d.totalStudyHours * 100) / 100,
    subjects: d.subjects,
    isDemo: d.isDemo,
    isLatest: latestEntryDate !== null && d.date === latestEntryDate,
  }));

  const raw = computePearsonAndOLSFromPoints(
    points.map((p) => ({ x: p.x, y: p.y })),
    7,
    CONFIDENCE_WARNING_TEXT,
    [1, 5],
  );

  return {
    r: raw.r,
    category: raw.category,
    explanation: raw.explanation,
    observationCount: raw.observationCount,
    requiredCount: raw.requiredCount,
    hasConfidence: raw.hasConfidence,
    zeroVariance: raw.zeroVariance,
    confidenceWarning: raw.confidenceWarning,
    meanSleep: raw.meanX,
    meanFocus: raw.meanY,
    ols: raw.ols,
    points,
  };
}

/**
 * Pure simulation for Step 3 (Sleep Shift Simulator):
 * Projects `nights` upcoming nights at `sleepHours` using focus predicted from the current OLS
 * (clamped 1-5), then recomputes Pearson r and OLS regression without modifying stored records.
 */
export function simulateSleepShift(
  existingPoints: Array<{ x: number; y: number }>,
  sleepHours: number,
  nights: number,
): SimulationResult {
  const safeSleep = Math.max(4, Math.min(12, Math.round(sleepHours * 100) / 100));
  const safeNights = Math.max(1, Math.min(14, Math.round(nights)));

  const before = computePearsonAndOLSFromPoints(existingPoints, 7, CONFIDENCE_WARNING_TEXT, [1, 5]);
  const fallbackFocus =
    existingPoints.length > 0
      ? existingPoints.reduce((a, p) => a + p.y, 0) / existingPoints.length
      : 3.5;

  const rawPredictedFocus = before.ols
    ? before.ols.slope * safeSleep + before.ols.intercept
    : fallbackFocus;
  const predictedFocus = Math.max(1, Math.min(5, Math.round(rawPredictedFocus * 100) / 100));

  const projectedPoints = Array.from({ length: safeNights }, (_, idx) => ({
    x: safeSleep,
    y: predictedFocus,
    nightIndex: idx + 1,
  }));

  const combined = [
    ...existingPoints,
    ...projectedPoints.map((p) => ({ x: p.x, y: p.y })),
  ];
  const after = computePearsonAndOLSFromPoints(combined, 7, CONFIDENCE_WARNING_TEXT, [1, 5]);

  let summarySentence = `Simulating ${safeNights} night${safeNights === 1 ? '' : 's'} at ${safeSleep.toFixed(1)}h projects an average focus of ${predictedFocus.toFixed(2)}/5.`;
  if (before.r !== null && after.r !== null) {
    const delta = Math.round((after.r - before.r) * 100) / 100;
    const direction =
      delta > 0 ? 'strengthens' : delta < 0 ? 'softens' : 'holds steady';
    summarySentence = `Adding ${safeNights} night${safeNights === 1 ? '' : 's'} of ${safeSleep.toFixed(1)}h sleep (predicted ${predictedFocus.toFixed(2)}/5 focus) ${direction} your Sleep-Productivity Correlation from r = ${before.r >= 0 ? '+' : ''}${before.r.toFixed(2)} to r = ${after.r >= 0 ? '+' : ''}${after.r.toFixed(2)}.`;
  } else if (after.hasConfidence && after.r !== null) {
    summarySentence = `Logging ${safeNights} more ${safeSleep.toFixed(1)}h night${safeNights === 1 ? '' : 's'} reaches the 7-day threshold with projected r = ${after.r >= 0 ? '+' : ''}${after.r.toFixed(2)}.`;
  }

  return {
    sleepHours: safeSleep,
    nights: safeNights,
    beforeR: before.r,
    afterR: after.r,
    beforeSlope: before.ols?.slope ?? null,
    afterSlope: after.ols?.slope ?? null,
    beforeOls: before.ols,
    afterOls: after.ols,
    projectedPoints,
    summarySentence,
  };
}

/**
 * Shared Sleep Debt calculator (daily deficit = max(0, baseline - actualSleep), surplus = max(0, actualSleep - baseline)).
 * Missing sleep nights (totalSleep <= 0) are explicitly excluded rather than penalized as 0 hours.
 */
export function computeSleepDebtMetrics(
  sleepDays: Array<{ date: string; totalSleep: number }>,
  last7SleepDays: Array<{ date: string; totalSleep: number }>,
  baseline = 8,
): SleepDebtSummary {
  const baselineDisclaimer = `Calculated against your ${baseline}-hour personal tracking baseline (not a medical diagnosis or universal sleep prescription).`;

  const validSleepDays = sleepDays.filter((d) => d.totalSleep > 0);
  const validLast7 = last7SleepDays.filter((d) => d.totalSleep > 0);

  const weeklyCumulativeDebt =
    Math.round(
      validLast7.reduce((acc, d) => acc + Math.max(0, baseline - d.totalSleep), 0) * 100,
    ) / 100;
  const weeklyCumulativeSurplus =
    Math.round(
      validLast7.reduce((acc, d) => acc + Math.max(0, d.totalSleep - baseline), 0) * 100,
    ) / 100;
  const weeklyLoggedNights = validLast7.length;
  const weeklyMissingNights = Math.max(0, 7 - weeklyLoggedNights);

  const periodTotalDebt =
    Math.round(validSleepDays.reduce((acc, d) => acc + Math.max(0, baseline - d.totalSleep), 0) * 100) /
    100;

  const averageNightlySleep =
    validSleepDays.length > 0
      ? Math.round((validSleepDays.reduce((acc, d) => acc + d.totalSleep, 0) / validSleepDays.length) * 100) /
        100
      : 0;

  const goalCompletionPercent =
    validSleepDays.length > 0 ? Math.min(100, Math.round((averageNightlySleep / baseline) * 100)) : 0;

  let sleepStdDevHours = 0;
  let consistencyStatus: SleepDebtSummary['consistencyStatus'] = 'Building Baseline';

  if (validSleepDays.length >= 3) {
    const mean = validSleepDays.reduce((acc, d) => acc + d.totalSleep, 0) / validSleepDays.length;
    const variance =
      validSleepDays.reduce((acc, d) => acc + Math.pow(d.totalSleep - mean, 2), 0) / validSleepDays.length;
    sleepStdDevHours = Math.round(Math.sqrt(variance) * 100) / 100;

    if (sleepStdDevHours <= 0.65) consistencyStatus = 'Consistent';
    else if (sleepStdDevHours <= 1.25) consistencyStatus = 'Moderate Variance';
    else consistencyStatus = 'Inconsistent';
  }

  const dailyBreakdown = validSleepDays.map((d) => ({
    date: d.date,
    actualSleep: d.totalSleep,
    debt: Math.max(0, Math.round((baseline - d.totalSleep) * 100) / 100),
    surplus: Math.max(0, Math.round((d.totalSleep - baseline) * 100) / 100),
  }));

  const recommendations: string[] = [];
  if (validSleepDays.length === 0) {
    recommendations.push(
      'Log at least 3 nights of sleep to compute your weekly Sleep Debt and consistency.',
    );
  } else {
    if (weeklyCumulativeDebt >= 5) {
      recommendations.push(
        `You accumulated ${weeklyCumulativeDebt.toFixed(1)}h of Sleep Debt across ${weeklyLoggedNights} logged night${weeklyLoggedNights === 1 ? '' : 's'} in the past 7 calendar days. Aim to add 30–45 minutes to your bedtime over the next few nights rather than oversleeping on one day.`,
      );
    } else if (weeklyCumulativeDebt > 0) {
      recommendations.push(
        `Your 7-day Sleep Debt is modest at ${weeklyCumulativeDebt.toFixed(1)}h across ${weeklyLoggedNights} logged night${weeklyLoggedNights === 1 ? '' : 's'}. Holding a steady wake-up time will keep you close to your ${baseline}h baseline.`,
      );
    } else {
      recommendations.push(
        `You met or exceeded your ${baseline}-hour tracking baseline across all ${weeklyLoggedNights} logged nights in the past 7 calendar days.`,
      );
    }

    if (consistencyStatus === 'Inconsistent') {
      recommendations.push(
        `Your nightly sleep duration varied by ±${sleepStdDevHours.toFixed(2)}h. Anchoring a consistent wake-up time stabilizes focus more effectively than irregular catch-up sleep.`,
      );
    } else if (consistencyStatus === 'Consistent') {
      recommendations.push(
        `Your sleep duration variance is tight (±${sleepStdDevHours.toFixed(2)}h), supporting steady circadian alertness.`,
      );
    }
  }

  return {
    baselineHours: baseline,
    baselineDisclaimer,
    weeklyCumulativeDebt,
    weeklyCumulativeSurplus,
    weeklyLoggedNights,
    weeklyMissingNights,
    periodTotalDebt,
    averageNightlySleep,
    goalCompletionPercent,
    consistencyStatus,
    sleepStdDevHours,
    dailyBreakdown,
    recommendations,
  };
}

export interface BedtimeOption {
  cycles: number;
  sleepHours: number;
  getInBedTime: string;
  fallAsleepTime: string;
  label: string;
  recommended: boolean;
}

export function calculateBedtimeCycles(
  wakeTime: string,
  fallAsleepMinutes: number,
): BedtimeOption[] {
  const wakeMin = parseTimeToMinutes(wakeTime);
  if (Number.isNaN(wakeMin)) return [];
  const latency = Math.max(0, Math.min(120, fallAsleepMinutes));

  const cycleCounts = [6, 5, 4, 3];
  return cycleCounts.map((cycles) => {
    const sleepMinutes = cycles * 90;
    const sleepHours = sleepMinutes / 60;
    const fallAsleepMin = wakeMin - sleepMinutes;
    const getInBedMin = fallAsleepMin - latency;

    let label = 'Minimum Recovery';
    if (cycles === 6) label = 'Optimal Full Rest (9h)';
    else if (cycles === 5) label = 'Balanced Target (7.5h)';
    else if (cycles === 4) label = 'Short Night (6h)';

    return {
      cycles,
      sleepHours,
      getInBedTime: minutesToTimeStr(getInBedMin),
      fallAsleepTime: minutesToTimeStr(fallAsleepMin),
      label,
      recommended: cycles === 5 || cycles === 6,
    };
  });
}

export function calculateRemainingCaffeine(
  initialMg: number,
  elapsedHours: number,
  halfLifeHours = 5,
): number {
  if (elapsedHours < 0 || initialMg <= 0 || halfLifeHours <= 0) return 0;
  return Math.round(initialMg * Math.pow(0.5, elapsedHours / halfLifeHours) * 10) / 10;
}

export function estimateBedtimeCaffeine(
  logs: Array<{ consumptionTime: string; caffeineAmount: number }>,
  targetBedtime: string,
  halfLifeHours = 5,
): number {
  const bedMin = parseTimeToMinutes(targetBedtime);
  if (Number.isNaN(bedMin)) return 0;
  let total = 0;
  for (const log of logs) {
    const cMin = parseTimeToMinutes(log.consumptionTime);
    if (Number.isNaN(cMin)) continue;
    let diffMin = bedMin - cMin;
    if (diffMin < 0) diffMin += 24 * 60;
    const elapsedHours = diffMin / 60;
    total += calculateRemainingCaffeine(log.caffeineAmount, elapsedHours, halfLifeHours);
  }
  return Math.round(total * 10) / 10;
}

export interface GeneratedExamPlanResult {
  tasks: Omit<ExamPlanTask, 'id'>[];
  capacityWarning: string | null;
  totalRequestedHours: number;
  totalScheduledHours: number;
  unscheduledHours: number;
  daysPlanned: number;
  decisions: string[];
  feasibility: ScheduleFeasibilityReport;
}

function diffDaysStr(fromDateStr: string, toDateStr: string): number {
  const [fy, fm, fd] = fromDateStr.split('-').map(Number);
  const [ty, tm, td] = toDateStr.split('-').map(Number);
  if (!fy || !fm || !fd || !ty || !tm || !td) return 1;
  return Math.round((Date.UTC(ty, tm - 1, td) - Date.UTC(fy, fm - 1, fd)) / 86400000);
}

export function generateProtectiveExamTimetable(
  exams: ExamSchedule[],
  dailyAvailableHours: number,
  preferredWakeTime: string,
  startDateStr: string = getLocalDateStr(0),
): GeneratedExamPlanResult {
  if (exams.length === 0) {
    return {
      tasks: [],
      capacityWarning: null,
      totalRequestedHours: 0,
      totalScheduledHours: 0,
      unscheduledHours: 0,
      daysPlanned: 0,
      decisions: ['No exams scheduled yet. Add upcoming exam targets to generate a protective plan.'],
      feasibility: {
        feasible: true,
        requiredHours: 0,
        maxPossibleCapacityHours: 0,
        maxDailyStudyHours: 0,
        minSleepHours: 0,
        overlapCount: 0,
        midnightCrossingCount: 0,
        deficitHours: 0,
        summary: 'No exams configured.',
        warnings: [],
      },
    };
  }

  // Mandatory hard limits: max 8h study/day, min 7h sleep/night
  const maxStudyPerDay = Math.max(1, Math.min(8, dailyAvailableHours));
  const wakeMin = parseTimeToMinutes(preferredWakeTime);
  const safeWakeMin = Number.isNaN(wakeMin) ? 7 * 60 : wakeMin;
  const safeWakeStr = minutesToTimeStr(safeWakeMin);
  const reservedSleepHours = 7.5; // >= 7 hours mandatory

  const priorityRank = { High: 0, Medium: 1, Low: 2 };
  const sortedExams = [...exams]
    .filter((e) => e.examDate >= startDateStr)
    .sort((a, b) => {
      if (a.examDate !== b.examDate) return a.examDate.localeCompare(b.examDate);
      return priorityRank[a.priority] - priorityRank[b.priority];
    });

  const activeExams = sortedExams.length > 0 ? sortedExams : [...exams];
  const furthestDate = activeExams.reduce(
    (max, e) => (e.examDate > max ? e.examDate : max),
    startDateStr,
  );

  const dayDates: string[] = [];
  for (let i = 0; i < 14; i++) {
    const dt = addDaysToDateStr(startDateStr, i);
    dayDates.push(dt);
    if (dt >= furthestDate && i >= 6) break;
  }
  if (dayDates.length === 0) dayDates.push(startDateStr);

  const priorityMultiplier = { High: 3.0, Medium: 1.8, Low: 1.0 };
  const subjectPool = activeExams.map((e) => {
    const topics = e.topics
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);
    const requested = Math.max(1, e.estimatedHours || 4);
    const difficulty = Math.max(1, Math.min(5, Math.round(e.topicDifficulty ?? 3)));
    const difficultyMultiplier = 0.75 + 0.15 * difficulty; // 0.90x .. 1.50x
    return {
      subject: e.subject,
      examDate: e.examDate,
      priority: e.priority,
      difficulty,
      topics: topics.length > 0 ? topics : [`${e.subject} Core Review`],
      remainingHours: requested,
      requestedHours: requested,
      weight: priorityMultiplier[e.priority] * difficultyMultiplier,
      topicCursor: 0,
    };
  });

  const totalRequestedHours =
    Math.round(subjectPool.reduce((acc, s) => acc + s.requestedHours, 0) * 10) / 10;

  interface InternalTask {
    task: Omit<ExamPlanTask, 'id'>;
    offsetStart: number;
  }

  const allTasks: Omit<ExamPlanTask, 'id'>[] = [];
  let totalScheduledHours = 0;
  const decisions: string[] = [];

  if (dailyAvailableHours > 8) {
    decisions.push(
      `Requested ${dailyAvailableHours}h/day was automatically capped at 8.0h/day to protect cognitive recall and prevent burnout.`,
    );
  }
  decisions.push(
    `Reserved ${reservedSleepHours}h protected sleep per 24h cycle (exceeds 7.0h minimum) anchored to ${formatTime12h(safeWakeStr)} wake-up.`,
  );
  decisions.push(
    'Protected Breakfast, Lunch, Dinner, and 15-minute circadian recovery breaks around study sessions with automatic overlap avoidance.',
  );

  // Fixed wake-relative offsets (in minutes from wakeMin) ensure zero overlap across any wakeTime (including midnight crossings)
  const BREAKFAST_START = 30;
  const BREAKFAST_END = 75;
  const LUNCH_START = 330; // +5.5h
  const LUNCH_END = 375;
  const DINNER_START = 690; // +11.5h
  const DINNER_END = 735;
  const SLEEP_START = (24 - reservedSleepHours) * 60; // +16.5h (990)
  const LATEST_STUDY_END = SLEEP_START - 30; // 30m wind-down before sleep

  const overlapsRange = (aStart: number, aEnd: number, bStart: number, bEnd: number) =>
    aStart < bEnd && aEnd > bStart;

  const firstDayTopOrder = [...subjectPool]
    .sort((a, b) => {
      const aUrgency = (a.weight * a.remainingHours) / Math.max(1, diffDaysStr(startDateStr, a.examDate) + 1);
      const bUrgency = (b.weight * b.remainingHours) / Math.max(1, diffDaysStr(startDateStr, b.examDate) + 1);
      if (Math.abs(bUrgency - aUrgency) > 1e-6) return bUrgency - aUrgency;
      return priorityRank[a.priority] - priorityRank[b.priority];
    })
    .map((s) => `${s.subject} (${s.priority}, diff ${s.difficulty}/5, due ${formatShortDate(s.examDate)})`);
  if (firstDayTopOrder.length > 0) {
    decisions.push(`Deadline, difficulty & priority urgency queue: ${firstDayTopOrder.join(' -> ')}.`);
  }

  for (const dayDate of dayDates) {
    const dayItems: InternalTask[] = [
      {
        offsetStart: BREAKFAST_START,
        task: {
          date: dayDate,
          startTime: minutesToTimeStr(safeWakeMin + BREAKFAST_START),
          endTime: minutesToTimeStr(safeWakeMin + BREAKFAST_END),
          title: 'Breakfast & Morning Hydration',
          subject: 'Wellness',
          type: 'meal',
          completed: false,
          schedulingReason: 'Protected morning nutrition block (+30m post-wake).',
        },
      },
      {
        offsetStart: LUNCH_START,
        task: {
          date: dayDate,
          startTime: minutesToTimeStr(safeWakeMin + LUNCH_START),
          endTime: minutesToTimeStr(safeWakeMin + LUNCH_END),
          title: 'Lunch Break & Midday Walk',
          subject: 'Wellness',
          type: 'meal',
          completed: false,
          schedulingReason: 'Protected midday meal & sunlight reset.',
        },
      },
      {
        offsetStart: DINNER_START,
        task: {
          date: dayDate,
          startTime: minutesToTimeStr(safeWakeMin + DINNER_START),
          endTime: minutesToTimeStr(safeWakeMin + DINNER_END),
          title: 'Dinner & Screen-Free Rest',
          subject: 'Wellness',
          type: 'meal',
          completed: false,
          schedulingReason: 'Protected evening meal & cognitive decompression.',
        },
      },
      {
        offsetStart: SLEEP_START,
        task: {
          date: dayDate,
          startTime: minutesToTimeStr(safeWakeMin + SLEEP_START),
          endTime: minutesToTimeStr(safeWakeMin + 24 * 60),
          title: `Protected Sleep Window (${reservedSleepHours}h reserved)`,
          subject: 'Sleep',
          type: 'sleep',
          completed: false,
          schedulingReason: `Hard sleep floor enforced (${reservedSleepHours}h >= 7.0h minimum).`,
        },
      },
    ];

    let cursor = BREAKFAST_END + 15; // +90m
    let dayStudyUsed = 0;

    const eligibleSubjects = subjectPool.filter(
      (s) => s.remainingHours > 0.25 && s.examDate >= dayDate,
    );

    const dayAssignedCount = new Map<string, number>();

    while (
      dayStudyUsed < maxStudyPerDay - 0.25 &&
      eligibleSubjects.some((s) => s.remainingHours > 0.25)
    ) {
      const available = eligibleSubjects.filter((s) => s.remainingHours > 0.25);
      if (available.length === 0) break;

      // Priority + difficulty + deadline urgency score, gently rotating after blocks of same subject for cognitive interleaving
      available.sort((a, b) => {
        const aDays = Math.max(0.5, diffDaysStr(dayDate, a.examDate) + 0.5);
        const bDays = Math.max(0.5, diffDaysStr(dayDate, b.examDate) + 0.5);
        const aFatiguePenalty = 1 / (1 + (dayAssignedCount.get(a.subject) ?? 0) * 0.65);
        const bFatiguePenalty = 1 / (1 + (dayAssignedCount.get(b.subject) ?? 0) * 0.65);
        const aScore = ((a.weight * Math.min(8, a.remainingHours)) / aDays) * aFatiguePenalty;
        const bScore = ((b.weight * Math.min(8, b.remainingHours)) / bDays) * bFatiguePenalty;
        if (Math.abs(bScore - aScore) > 1e-6) return bScore - aScore;
        if (a.examDate !== b.examDate) return a.examDate.localeCompare(b.examDate);
        return priorityRank[a.priority] - priorityRank[b.priority];
      });

      const picked = available[0];
      const blockHours = Math.min(2, maxStudyPerDay - dayStudyUsed, picked.remainingHours);
      if (blockHours < 0.5) break;

      const blockMins = Math.round(blockHours * 60);

      // Jump cleanly past Lunch or Dinner if study block would touch either meal window
      if (overlapsRange(cursor, cursor + blockMins, LUNCH_START, LUNCH_END)) {
        cursor = Math.max(cursor, LUNCH_END + 15);
      }
      if (overlapsRange(cursor, cursor + blockMins, DINNER_START, DINNER_END)) {
        cursor = Math.max(cursor, DINNER_END + 15);
      }

      if (cursor + blockMins > LATEST_STUDY_END) {
        break;
      }

      const topicLabel = picked.topics[picked.topicCursor % picked.topics.length];
      picked.topicCursor++;
      dayAssignedCount.set(picked.subject, (dayAssignedCount.get(picked.subject) ?? 0) + 1);

      const daysLeft = Math.max(0, diffDaysStr(dayDate, picked.examDate));
      const reason = `${picked.priority} priority · diff ${picked.difficulty}/5 · exam in ${daysLeft}d (${picked.remainingHours.toFixed(1)}h left before block)`;

      dayItems.push({
        offsetStart: cursor,
        task: {
          date: dayDate,
          startTime: minutesToTimeStr(safeWakeMin + cursor),
          endTime: minutesToTimeStr(safeWakeMin + cursor + blockMins),
          title: `${picked.subject}: ${topicLabel}`,
          subject: picked.subject,
          type: 'study',
          completed: false,
          schedulingReason: reason,
        },
      });

      picked.remainingHours = Math.round((picked.remainingHours - blockHours) * 100) / 100;
      dayStudyUsed = Math.round((dayStudyUsed + blockHours) * 100) / 100;
      totalScheduledHours = Math.round((totalScheduledHours + blockHours) * 100) / 100;
      cursor += blockMins;

      // Only add 15-minute break if it does NOT overlap Lunch, Dinner, or Sleep/Wind-down
      const breakEnd = cursor + 15;
      const hitsMeal =
        overlapsRange(cursor, breakEnd, LUNCH_START, LUNCH_END) ||
        overlapsRange(cursor, breakEnd, DINNER_START, DINNER_END);
      if (dayStudyUsed < maxStudyPerDay - 0.25 && !hitsMeal && breakEnd <= LATEST_STUDY_END) {
        dayItems.push({
          offsetStart: cursor,
          task: {
            date: dayDate,
            startTime: minutesToTimeStr(safeWakeMin + cursor),
            endTime: minutesToTimeStr(safeWakeMin + breakEnd),
            title: 'Rest & Stretch Break',
            subject: 'Recovery',
            type: 'break',
            completed: false,
            schedulingReason: '15m ultradian recovery break to sustain Deep Focus.',
          },
        });
        cursor = breakEnd;
      } else if (overlapsRange(cursor, breakEnd, LUNCH_START, LUNCH_END)) {
        cursor = LUNCH_END + 15;
      } else if (overlapsRange(cursor, breakEnd, DINNER_START, DINNER_END)) {
        cursor = DINNER_END + 15;
      }
    }

    dayItems.sort((a, b) => a.offsetStart - b.offsetStart);
    for (const item of dayItems) {
      allTasks.push(item.task);
    }
  }

  const unscheduledHours = Math.max(
    0,
    Math.round((totalRequestedHours - totalScheduledHours) * 10) / 10,
  );
  const capacityWarning =
    unscheduledHours > 0.5
      ? `Safe schedule capacity reached: ${unscheduledHours}h of requested study could not fit before your exam dates without breaking the mandatory 8h/day study cap or 7h/night sleep minimum. Consider prioritizing high-impact topics.`
      : null;

  const feasibility = validateScheduleFeasibility(
    allTasks,
    exams,
    maxStudyPerDay,
    safeWakeStr,
    startDateStr,
  );

  if (capacityWarning) {
    decisions.push(capacityWarning);
  }
  for (const fw of feasibility.warnings) {
    if (!decisions.includes(fw)) {
      decisions.push(fw);
    }
  }

  return {
    tasks: allTasks,
    capacityWarning,
    totalRequestedHours,
    totalScheduledHours,
    unscheduledHours,
    daysPlanned: dayDates.length,
    decisions,
    feasibility,
  };
}

export function validateScheduleFeasibility(
  tasks: Array<Omit<ExamPlanTask, 'id'>>,
  exams: ExamSchedule[],
  dailyAvailableHours: number,
  wakeTime = '07:30',
  startDateStr: string = getLocalDateStr(0),
): ScheduleFeasibilityReport {
  const safeDaily = Math.max(1, Math.min(8, dailyAvailableHours));
  const validation = validateExamTimetable(tasks, wakeTime);

  const requiredHours =
    Math.round(exams.reduce((acc, e) => acc + Math.max(1, e.estimatedHours || 4), 0) * 10) / 10;

  const studyScheduled =
    Math.round(
      tasks
        .filter((t) => t.type === 'study')
        .reduce((acc, t) => acc + calculateSleepDuration(t.startTime, t.endTime), 0) * 10,
    ) / 10;

  const activeExams = exams
    .filter((e) => e.examDate >= startDateStr)
    .sort((a, b) => a.examDate.localeCompare(b.examDate));
  const pastDueExams = exams.filter((e) => e.examDate < startDateStr);

  const furthest = activeExams.reduce(
    (max, e) => (e.examDate > max ? e.examDate : max),
    startDateStr,
  );
  const availableDays = Math.max(1, diffDaysStr(startDateStr, furthest) + 1);
  const maxPossibleCapacityHours = Math.round(availableDays * safeDaily * 10) / 10;
  const deficitHours = Math.max(0, Math.round((requiredHours - studyScheduled) * 10) / 10);

  const warnings: string[] = [...validation.errors];

  // Explicit impossible deadline milestone check (cumulative study due by each exam date <= days * safeDaily)
  let cumulativeRequested = 0;
  for (const ex of activeExams) {
    cumulativeRequested += Math.max(1, ex.estimatedHours || 4);
    const daysToDeadline = Math.max(1, diffDaysStr(startDateStr, ex.examDate) + 1);
    const milestoneMaxCapacity = Math.round(daysToDeadline * safeDaily * 10) / 10;
    if (cumulativeRequested > milestoneMaxCapacity + 0.5) {
      warnings.push(
        `Impossible deadline constraint: ${cumulativeRequested.toFixed(1)}h cumulative study needed by ${formatShortDate(ex.examDate)} (${ex.subject}), exceeding safe ${milestoneMaxCapacity.toFixed(1)}h capacity (${daysToDeadline}d x ${safeDaily}h/day max with >=7h sleep).`,
      );
    }
  }

  if (pastDueExams.length > 0 && deficitHours > 0.5) {
    warnings.push(
      `${pastDueExams.length} exam date(s) already precede ${formatShortDate(startDateStr)}, leaving unscheduled target hours.`,
    );
  }

  if (deficitHours > 0.5) {
    warnings.push(
      `${deficitHours.toFixed(1)}h of requested study exceeds safe pre-exam capacity (${safeDaily}h/day max).`,
    );
  }

  const feasible = validation.valid && deficitHours <= 0.5 && warnings.length === 0;
  const summary = feasible
    ? `Feasible schedule: 0 overlaps, max ${validation.maxDailyStudyHours.toFixed(1)}h/day study (<=8h), min ${validation.minSleepHours.toFixed(1)}h/night sleep (>=7h).`
    : warnings[0] || 'Impossible schedule constraints detected under sleep & daily study caps.';

  return {
    feasible,
    requiredHours,
    maxPossibleCapacityHours,
    maxDailyStudyHours: validation.maxDailyStudyHours,
    minSleepHours: validation.minSleepHours,
    overlapCount: validation.overlapCount,
    midnightCrossingCount: validation.midnightCrossingCount,
    deficitHours,
    summary,
    warnings,
  };
}

export interface RescheduleResult {
  tasks: Omit<ExamPlanTask, 'id'>[];
  rescheduledCount: number;
  rescheduledHours: number;
  capacityWarning: string | null;
  totalRequestedHours: number;
  totalScheduledHours: number;
  unscheduledHours: number;
  daysPlanned: number;
  decisions: string[];
  feasibility: ScheduleFeasibilityReport;
}

/**
 * Detects incomplete study tasks prior to `currentDateStr` (or explicitly passed missedTaskIds),
 * carries their uncompleted hours forward, and generates a collision-free sleep-protected schedule
 * starting from `currentDateStr`.
 */
export function rescheduleMissedExamTasks(
  existingTasks: ExamPlanTask[],
  exams: ExamSchedule[],
  dailyAvailableHours: number,
  preferredWakeTime: string,
  currentDateStr: string = getLocalDateStr(0),
  missedTaskIds?: number[],
): RescheduleResult {
  const missedIdSet = missedTaskIds ? new Set(missedTaskIds) : null;
  const missedTasks = existingTasks.filter((t) => {
    if (t.type !== 'study' || t.completed) return false;
    if (missedIdSet) return missedIdSet.has(t.id);
    return t.date < currentDateStr;
  });

  const missedHoursBySubject = new Map<string, number>();
  let totalMissedHours = 0;
  for (const t of missedTasks) {
    const hrs = calculateSleepDuration(t.startTime, t.endTime);
    missedHoursBySubject.set(t.subject, (missedHoursBySubject.get(t.subject) ?? 0) + hrs);
    totalMissedHours += hrs;
  }

  // Remaining completed hours per subject from existing plan reduce base requirement if still ahead
  const completedHoursBySubject = new Map<string, number>();
  for (const t of existingTasks) {
    if (t.type === 'study' && t.completed) {
      const hrs = calculateSleepDuration(t.startTime, t.endTime);
      completedHoursBySubject.set(t.subject, (completedHoursBySubject.get(t.subject) ?? 0) + hrs);
    }
  }

  const adjustedExams: ExamSchedule[] = exams.map((ex) => {
    const completed = completedHoursBySubject.get(ex.subject) ?? 0;
    const missedCarryover = missedHoursBySubject.get(ex.subject) ?? 0;
    const remainingTarget = Math.max(
      1,
      Math.round((Math.max(0.5, ex.estimatedHours - completed) + missedCarryover * 0.25) * 10) / 10,
    );
    return {
      ...ex,
      estimatedHours: remainingTarget,
    };
  });

  const generated = generateProtectiveExamTimetable(
    adjustedExams,
    dailyAvailableHours,
    preferredWakeTime,
    currentDateStr,
  );

  const rescheduleDecision =
    missedTasks.length > 0
      ? `Reallocated ${missedTasks.length} missed study block(s) (${Math.round(totalMissedHours * 10) / 10}h) into upcoming days starting ${formatShortDate(currentDateStr)} without violating 8h/day study or 7h/night sleep limits.`
      : `Rebalanced active exam plan from ${formatShortDate(currentDateStr)} using priority and deadline urgency.`;

  return {
    ...generated,
    rescheduledCount: missedTasks.length,
    rescheduledHours: Math.round(totalMissedHours * 10) / 10,
    decisions: [rescheduleDecision, ...generated.decisions],
  };
}

/**
 * Verifies every Exam Week Sleep Preserver invariant across all days, including schedules crossing midnight:
 * - Every day's sleep duration >= 7.0h (computed via calculateSleepDuration)
 * - Every day's study duration <= 8.0h
 * - Zero overlapping tasks within a wake-cycle or across consecutive days
 * - Meals and breaks never overlap study sessions or each other
 */
export function validateExamTimetable(
  tasks: Array<Omit<ExamPlanTask, 'id'>>,
  wakeTime = '07:30',
): TimetableValidationResult {
  const errors: string[] = [];
  const wakeMin = parseTimeToMinutes(wakeTime);
  const safeWake = Number.isNaN(wakeMin) ? 450 : wakeMin;

  const byDate = new Map<string, Array<Omit<ExamPlanTask, 'id'>>>();
  for (const t of tasks) {
    const list = byDate.get(t.date) ?? [];
    list.push(t);
    byDate.set(t.date, list);
  }

  let maxDailyStudyHours = 0;
  let minSleepHours = tasks.length > 0 ? Infinity : 0;
  let midnightCrossingCount = 0;
  let overlapCount = 0;

  const timelineIntervals: Array<{
    date: string;
    title: string;
    type: string;
    absStart: number;
    absEnd: number;
  }> = [];

  const sortedDates = Array.from(byDate.keys()).sort();
  const baseDateStr = sortedDates[0] ?? '2026-01-01';
  const [by, bm, bd] = baseDateStr.split('-').map(Number);
  const baseUtcMs = Date.UTC(by, bm - 1, bd);

  for (const date of sortedDates) {
    const dayTasks = byDate.get(date) ?? [];
    const [y, m, d] = date.split('-').map(Number);
    const dayIndex = Math.round((Date.UTC(y, m - 1, d) - baseUtcMs) / 86400000);

    let dayStudyHours = 0;
    let daySleepHours = 0;

    for (const t of dayTasks) {
      const sMin = parseTimeToMinutes(t.startTime);
      const eMin = parseTimeToMinutes(t.endTime);
      if (Number.isNaN(sMin) || Number.isNaN(eMin)) {
        errors.push(`Invalid time format on ${date}: ${t.title}`);
        continue;
      }

      const durHours = calculateSleepDuration(t.startTime, t.endTime);
      const durMin = Math.round(durHours * 60);
      if (eMin < sMin) {
        midnightCrossingCount++;
      }

      // Compute wake-cycle relative offset [0, 1440)
      const relStart = ((sMin - safeWake) % 1440 + 1440) % 1440;
      const absStart = dayIndex * 1440 + relStart;
      const absEnd = absStart + durMin;

      timelineIntervals.push({
        date,
        title: t.title,
        type: t.type,
        absStart,
        absEnd,
      });

      if (t.type === 'study') dayStudyHours += durHours;
      if (t.type === 'sleep') daySleepHours += durHours;
    }

    dayStudyHours = Math.round(dayStudyHours * 100) / 100;
    daySleepHours = Math.round(daySleepHours * 100) / 100;

    if (dayStudyHours > maxDailyStudyHours) maxDailyStudyHours = dayStudyHours;
    if (daySleepHours < minSleepHours) minSleepHours = daySleepHours;

    if (dayStudyHours > 8 + 1e-6) {
      errors.push(`Study cap violated on ${date}: ${dayStudyHours}h > 8h`);
    }
    if (daySleepHours < 7 - 1e-6) {
      errors.push(`Sleep minimum violated on ${date}: ${daySleepHours}h < 7h`);
    }
  }

  timelineIntervals.sort((a, b) => a.absStart - b.absStart);
  for (let i = 1; i < timelineIntervals.length; i++) {
    const prev = timelineIntervals[i - 1];
    const curr = timelineIntervals[i];
    if (curr.absStart < prev.absEnd) {
      overlapCount++;
      errors.push(
        `Overlap on ${curr.date}: "${prev.title}" (${prev.type}) overlaps "${curr.title}" (${curr.type})`,
      );
    }
  }

  return {
    valid: errors.length === 0,
    errors,
    maxDailyStudyHours: Math.round(maxDailyStudyHours * 100) / 100,
    minSleepHours: Number.isFinite(minSleepHours) ? Math.round(minSleepHours * 100) / 100 : 0,
    midnightCrossingCount,
    overlapCount,
  };
}
