import React, { Suspense, lazy, useCallback, useEffect, useMemo, useState } from 'react';
import {
  AlarmClock,
  BatteryCharging,
  Bell,
  BookOpen,
  Calendar,
  Coffee,
  Database,
  FileText,
  Home,
  LayoutDashboard,
  LogIn,
  LogOut,
  Menu,
  Moon,
  Settings,
  ShieldCheck,
  TrendingUp,
  X,
} from 'lucide-react';
import { api } from './api/client.ts';
import { AuthModal } from './components/AuthModal.tsx';
import { BedtimeView } from './components/BedtimeView.tsx';
import { DashboardView, type NavSection } from './components/DashboardView.tsx';
import { LandingPage } from './components/LandingPage.tsx';
import { QuickLogModal } from './components/QuickLogModal.tsx';
import { SettingsView } from './components/SettingsView.tsx';
import { SleepDebtView } from './components/SleepDebtView.tsx';
import { SleepTrackerView } from './components/SleepTrackerView.tsx';
import { StudyTrackerView } from './components/StudyTrackerView.tsx';
import {
  ConfirmModal,
  DashboardSkeleton,
  ErrorBoundary,
  ToastList,
  type ToastItem,
} from './components/ui.tsx';
import type {
  AuthUser,
  CaffeineLog,
  DashboardAnalytics,
  ExamPlanTask,
  ExamSchedule,
  SleepLog,
  StudyLog,
  UserSettings,
} from './shared/types.ts';

const AnalyticsView = lazy(() =>
  import('./components/AnalyticsView.tsx').then((m) => ({ default: m.AnalyticsView })),
);
const CaffeineView = lazy(() =>
  import('./components/CaffeineView.tsx').then((m) => ({ default: m.CaffeineView })),
);
const ExamPlannerView = lazy(() =>
  import('./components/ExamPlannerView.tsx').then((m) => ({ default: m.ExamPlannerView })),
);
const ReportsView = lazy(() =>
  import('./components/ReportsView.tsx').then((m) => ({ default: m.ReportsView })),
);
const VerificationView = lazy(() =>
  import('./components/VerificationView.tsx').then((m) => ({ default: m.VerificationView })),
);

interface NavMeta {
  id: NavSection;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  group: 'core' | 'labs' | 'system';
}

const NAV_ITEMS: NavMeta[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, group: 'core' },
  { id: 'sleep', label: 'Sleep Tracker', icon: Moon, group: 'core' },
  { id: 'study', label: 'Study Tracker', icon: BookOpen, group: 'core' },
  { id: 'analytics', label: 'Analytics', icon: TrendingUp, group: 'core' },
  { id: 'sleep-debt', label: 'Sleep Debt', icon: BatteryCharging, group: 'core' },
  { id: 'bedtime', label: 'Optimal Bedtime Recommender', icon: AlarmClock, group: 'labs' },
  { id: 'caffeine', label: 'Caffeine Tracker', icon: Coffee, group: 'labs' },
  { id: 'exams', label: 'Exam Week Sleep Preserver', icon: Calendar, group: 'labs' },
  { id: 'reports', label: 'Wellness Reports', icon: FileText, group: 'labs' },
  { id: 'settings', label: 'Settings', icon: Settings, group: 'system' },
  { id: 'verify', label: 'System Verification', icon: ShieldCheck, group: 'system' },
];

const CORE_NAV = NAV_ITEMS.filter((i) => i.group === 'core');
const LABS_NAV = NAV_ITEMS.filter((i) => i.group === 'labs');
const SETTINGS_NAV = NAV_ITEMS.find((i) => i.id === 'settings')!;

export default function App() {
  const initialVerify =
    typeof window !== 'undefined' && window.location.hash === '#verify';

  const [showLanding, setShowLanding] = useState(!initialVerify);
  const [activeTab, setActiveTab] = useState<NavSection>(initialVerify ? 'verify' : 'dashboard');
  const [daysWindow, setDaysWindow] = useState<number>(21);

  const [analytics, setAnalytics] = useState<DashboardAnalytics | null>(null);
  const [sleepLogs, setSleepLogs] = useState<SleepLog[]>([]);
  const [studyLogs, setStudyLogs] = useState<StudyLog[]>([]);
  const [caffeineLogs, setCaffeineLogs] = useState<CaffeineLog[]>([]);
  const [exams, setExams] = useState<ExamSchedule[]>([]);
  const [examPlanTasks, setExamPlanTasks] = useState<ExamPlanTask[]>([]);
  const [settings, setSettings] = useState<UserSettings>({
    studentName: 'Maya Lin',
    sleepBaselineHours: 8,
    caffeineHalfLifeHours: 5,
    preferredWakeTime: '07:30',
    dailyAvailableHours: 7,
    onboardingDismissed: false,
    demoCleared: false,
  });

  const [authUser, setAuthUser] = useState<AuthUser | null>(null);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [runningDemo, setRunningDemo] = useState(false);
  const [quickModalMode, setQuickModalMode] = useState<'sleep' | 'study' | null>(null);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [confirmClearDemo, setConfirmClearDemo] = useState(false);
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const notify = useCallback(
    (type: 'success' | 'error' | 'info', message: string, onRetry?: () => void) => {
      const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      setToasts((prev) => [...prev, { id, type, message, onRetry }]);
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 5000);
    },
    [],
  );

  const navigateTo = useCallback((tab: NavSection) => {
    setShowLanding(false);
    setActiveTab(tab);
    setMobileMenuOpen(false);
    if (typeof window !== 'undefined') {
      if (tab === 'verify') {
        if (window.location.hash !== '#verify') {
          window.history.replaceState(null, '', '#verify');
        }
      } else if (window.location.hash === '#verify') {
        window.history.replaceState(null, '', window.location.pathname + window.location.search);
      }
    }
  }, []);

  const openLanding = useCallback(() => {
    setShowLanding(true);
    setMobileMenuOpen(false);
    if (typeof window !== 'undefined' && window.location.hash === '#verify') {
      window.history.replaceState(null, '', window.location.pathname + window.location.search);
    }
  }, []);

  useEffect(() => {
    const onHashChange = () => {
      if (window.location.hash === '#verify') {
        setShowLanding(false);
        setActiveTab('verify');
      }
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const loadAllData = useCallback(
    async (windowDays = daysWindow) => {
      try {
        const [dashData, sleeps, studies, caffeines, examList, planList, userCfg] =
          await Promise.all([
            api.getDashboard(windowDays),
            api.getSleepLogs(),
            api.getStudyLogs(),
            api.getCaffeineLogs(),
            api.getExams(),
            api.getExamPlan(),
            api.getSettings(),
          ]);
        setAnalytics(dashData);
        setSleepLogs(sleeps);
        setStudyLogs(studies);
        setCaffeineLogs(caffeines);
        setExams(examList);
        setExamPlanTasks(planList);
        setSettings(userCfg);
      } catch (err) {
        notify(
          'error',
          err instanceof Error ? err.message : 'Failed to load DreamLog data.',
          () => loadAllData(windowDays),
        );
      } finally {
        setLoading(false);
      }
    },
    [daysWindow, notify],
  );

  const ensureSession = useCallback(async (): Promise<AuthUser | null> => {
    if (authUser) return authUser;
    const me = await api.authMe();
    if (me.authenticated && me.user) {
      setAuthUser(me.user);
      return me.user;
    }
    const demo = await api.demoSession();
    setAuthUser(demo.user);
    return demo.user;
  }, [authUser]);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const me = await api.authMe();
        if (!active) return;
        if (me.authenticated && me.user) {
          setAuthUser(me.user);
          await loadAllData(daysWindow);
        } else if (initialVerify) {
          const demo = await api.demoSession();
          if (!active) return;
          setAuthUser(demo.user);
          await loadAllData(daysWindow);
        } else {
          setLoading(false);
        }
      } catch {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, [daysWindow, initialVerify, loadAllData]);

  const handleEnterWorkspace = async (targetTab: NavSection = 'dashboard') => {
    try {
      await ensureSession();
      await loadAllData(daysWindow);
      navigateTo(targetTab);
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Unable to enter workspace.');
    }
  };

  const handleAuthenticated = async (user: AuthUser) => {
    setAuthUser(user);
    await loadAllData(daysWindow);
    navigateTo('dashboard');
  };

  const handleLogout = async () => {
    try {
      await api.logout();
      setAuthUser(null);
      setAnalytics(null);
      setSleepLogs([]);
      setStudyLogs([]);
      setCaffeineLogs([]);
      setExams([]);
      setExamPlanTasks([]);
      setShowLanding(true);
      setMobileMenuOpen(false);
      notify('info', 'Signed out cleanly. Session closed.');
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to sign out.');
    }
  };

  const handleChangeDaysWindow = (days: number) => {
    setDaysWindow(days);
    if (authUser) {
      loadAllData(days);
    }
  };

  const handleDismissOnboarding = async () => {
    try {
      const updated = await api.updateSettings({ onboardingDismissed: true });
      setSettings(updated);
    } catch {
      setSettings((s) => ({ ...s, onboardingDismissed: true }));
    }
  };

  const handleClearDemoData = async () => {
    try {
      await api.clearDemoData();
      setConfirmClearDemo(false);
      notify('info', 'Sample demo dataset removed. Start recording your own sleep and study logs.');
      await loadAllData(daysWindow);
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to clear demo data.');
    }
  };

  const handleRunDemoScenario = async (enterDashboard = false) => {
    setRunningDemo(true);
    try {
      await ensureSession();
      const updated = await api.runDemoScenario();
      setDaysWindow(21);
      await loadAllData(21);
      if (enterDashboard) {
        navigateTo('dashboard');
      }
      const rText =
        updated.correlation.r !== null
          ? `r = ${updated.correlation.r >= 0 ? '+' : ''}${updated.correlation.r.toFixed(2)} (${updated.correlation.category})`
          : updated.correlation.category;
      notify(
        'success',
        `Demo Scenario logged: 11:30 PM → 7:30 AM (8.0h) + 4.5h Algorithms (5/5 Deep Focus). ${rText}.`,
      );
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to run demo scenario.');
    } finally {
      setRunningDemo(false);
    }
  };

  const handleResetDemoScenario = async () => {
    setRunningDemo(true);
    try {
      await api.resetDemoScenario();
      await loadAllData(daysWindow);
      notify('info', 'Reset today’s demo scenario entry back to the 21-day baseline.');
    } catch (err) {
      notify('error', err instanceof Error ? err.message : 'Failed to reset demo scenario.');
    } finally {
      setRunningDemo(false);
    }
  };

  const notifications = useMemo(() => {
    const list: Array<{ id: string; title: string; detail: string; target: NavSection }> = [];
    if (analytics?.hasDemoData) {
      list.push({
        id: 'demo',
        title: '21-Day Demo Dataset Active',
        detail: `${analytics.demoCount} sample entries loaded. Explore or clear them anytime.`,
        target: 'settings',
      });
    }
    if (analytics && !analytics.correlation.hasConfidence) {
      list.push({
        id: 'corr',
        title: 'Correlation Confidence Threshold',
        detail: `${analytics.correlation.observationCount}/7 paired sleep-study days logged.`,
        target: 'analytics',
      });
    }
    if (analytics && analytics.weeklySleepDebt >= 4) {
      list.push({
        id: 'debt',
        title: `Weekly Sleep Debt: ${analytics.weeklySleepDebt.toFixed(1)}h`,
        detail: 'Consider moving bedtime 30 minutes earlier to recover toward your baseline.',
        target: 'sleep-debt',
      });
    }
    if (exams.length > 0) {
      list.push({
        id: 'exam',
        title: `${exams.length} Upcoming Exam${exams.length === 1 ? '' : 's'} Tracked`,
        detail: `Next: ${exams[0].subject} on ${exams[0].examDate}`,
        target: 'exams',
      });
    }
    return list;
  }, [analytics, exams]);

  const activeNavMeta = NAV_ITEMS.find((n) => n.id === activeTab) || NAV_ITEMS[0];

  const renderNavButton = (item: NavMeta) => {
    const Icon = item.icon;
    const isActive = activeTab === item.id;
    return (
      <button
        key={item.id}
        type="button"
        onClick={() => navigateTo(item.id)}
        className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA] ${
          isActive
            ? 'bg-[#60A5FA]/15 text-[#60A5FA] border border-[#60A5FA]/30'
            : 'text-[#CBD5E1] hover:text-[#F8FAFC] hover:bg-[#1E293B]/60 border border-transparent'
        }`}
      >
        <Icon className="w-4 h-4 shrink-0" />
        <span className="truncate">{item.label}</span>
      </button>
    );
  };

  if (showLanding) {
    return (
      <ErrorBoundary>
        <LandingPage
          onGetStarted={() => handleEnterWorkspace('dashboard')}
          onExploreDashboard={() => handleEnterWorkspace('dashboard')}
          onRunDemoScenario={() => handleRunDemoScenario(true)}
          runningDemo={runningDemo}
          onOpenVerify={() => handleEnterWorkspace('verify')}
          onOpenAuth={() => setAuthModalOpen(true)}
          authenticatedName={authUser ? authUser.name : null}
        />
        <AuthModal
          open={authModalOpen}
          onClose={() => setAuthModalOpen(false)}
          onAuthenticated={handleAuthenticated}
          onNotify={notify}
        />
        <ToastList
          toasts={toasts}
          onDismiss={(id) => setToasts((p) => p.filter((t) => t.id !== id))}
        />
      </ErrorBoundary>
    );
  }

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-[#0F172A] text-[#F8FAFC] flex overflow-x-hidden">
        {/* Desktop Sidebar */}
        <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 bg-[#111827] border-r border-slate-800/90 z-30 print:hidden">
          <div className="h-16 px-5 flex items-center justify-between border-b border-slate-800/90">
            <button
              type="button"
              onClick={openLanding}
              className="flex items-center gap-2.5 text-left group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA] rounded-lg"
            >
              <Moon className="w-5 h-5 text-[#60A5FA]" />
              <span className="font-display font-bold text-base tracking-tight text-[#F8FAFC] group-hover:text-[#60A5FA] transition-colors">
                DreamLog
              </span>
            </button>
            <button
              type="button"
              onClick={openLanding}
              className="p-1.5 rounded-lg text-[#CBD5E1] hover:text-[#F8FAFC] hover:bg-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
              title="Return to Welcome Page"
              aria-label="Return to Welcome Page"
            >
              <Home className="w-4 h-4" />
            </button>
          </div>

          <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-5" aria-label="Workspace Navigation">
            <div className="space-y-1">
              {CORE_NAV.map(renderNavButton)}
            </div>

            <div>
              <div className="px-3 mb-1.5 text-[11px] font-semibold uppercase tracking-wider text-[#94A3B8]">
                Labs
              </div>
              <div className="space-y-1">
                {LABS_NAV.map(renderNavButton)}
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800/80 space-y-1">
              {renderNavButton(SETTINGS_NAV)}
            </div>
          </nav>

          {/* Student Profile & System Verification Footer */}
          <div className="p-3 border-t border-slate-800/90 space-y-2">
            <button
              type="button"
              onClick={() => navigateTo('verify')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA] ${
                activeTab === 'verify'
                  ? 'bg-[#34D399]/15 text-[#34D399] border border-[#34D399]/30'
                  : 'text-[#CBD5E1] hover:text-[#F8FAFC] hover:bg-[#1E293B]/60'
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-[#34D399] shrink-0" />
              <span>System Verification</span>
            </button>

            <button
              type="button"
              onClick={() => navigateTo('settings')}
              className="w-full flex items-center gap-3 p-2 rounded-xl hover:bg-[#1E293B]/70 transition-colors text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
            >
              <img
                src="/src/assets/images/student_profile_avatar.webp"
                alt={settings.studentName}
                width={36}
                height={36}
                loading="lazy"
                referrerPolicy="no-referrer"
                className="w-9 h-9 rounded-full object-cover border border-slate-700 shrink-0"
              />
              <div className="min-w-0 flex-1">
                <div className="text-sm font-semibold text-[#F8FAFC] truncate">
                  {authUser?.name || settings.studentName}
                </div>
                <div className="text-xs text-[#CBD5E1] truncate">
                  {authUser?.role === 'demo' ? 'Demo Workspace' : authUser?.email || `Baseline: ${settings.sleepBaselineHours}h`}
                </div>
              </div>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setAuthModalOpen(true)}
                className="flex-1 py-1.5 px-2.5 rounded-lg border border-slate-700 bg-[#0F172A] text-[11px] font-medium text-[#CBD5E1] hover:border-[#60A5FA] hover:text-[#F8FAFC] transition-colors inline-flex items-center justify-center gap-1.5"
              >
                <LogIn className="w-3.5 h-3.5 text-[#60A5FA]" />
                <span>Switch Account</span>
              </button>
              <button
                type="button"
                onClick={handleLogout}
                className="py-1.5 px-2.5 rounded-lg border border-slate-700 bg-[#0F172A] text-[11px] font-medium text-[#CBD5E1] hover:border-[#F87171] hover:text-[#F87171] transition-colors inline-flex items-center justify-center"
                title="Sign Out"
                aria-label="Sign Out"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </aside>

        {/* Mobile Slide-Over Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 lg:hidden flex">
            <div
              className="fixed inset-0 bg-black/70 backdrop-blur-sm"
              onClick={() => setMobileMenuOpen(false)}
            />
            <aside className="relative w-72 max-w-[85vw] bg-[#111827] border-r border-slate-800 h-full flex flex-col z-10">
              <div className="h-16 px-5 flex items-center justify-between border-b border-slate-800">
                <div className="flex items-center gap-2.5">
                  <Moon className="w-5 h-5 text-[#60A5FA]" />
                  <span className="font-display font-bold text-base text-[#F8FAFC]">DreamLog</span>
                </div>
                <button
                  type="button"
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-2 text-[#CBD5E1] hover:text-[#F8FAFC] rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
                  aria-label="Close navigation menu"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-4">
                <div className="space-y-1">{CORE_NAV.map(renderNavButton)}</div>
                <div>
                  <div className="px-3 mb-1.5 text-[11px] font-semibold uppercase tracking-wider text-[#94A3B8]">
                    Labs
                  </div>
                  <div className="space-y-1">{LABS_NAV.map(renderNavButton)}</div>
                </div>
                <div className="pt-2 border-t border-slate-800 space-y-1">
                  {renderNavButton(SETTINGS_NAV)}
                  {renderNavButton(NAV_ITEMS.find((i) => i.id === 'verify')!)}
                </div>
              </nav>
              <div className="p-4 border-t border-slate-800 space-y-2">
                <button
                  type="button"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    setAuthModalOpen(true);
                  }}
                  className="w-full py-2 px-3 rounded-lg border border-slate-700 text-xs font-medium text-[#F8FAFC] flex items-center justify-center gap-2"
                >
                  <LogIn className="w-4 h-4 text-[#60A5FA]" />
                  <span>{authUser ? `Account (${authUser.name})` : 'Sign In / Register'}</span>
                </button>
                <button
                  type="button"
                  onClick={openLanding}
                  className="w-full py-2 px-3 rounded-lg border border-slate-700 text-xs font-medium text-[#CBD5E1] flex items-center justify-center gap-2"
                >
                  <Home className="w-4 h-4" />
                  <span>Welcome Landing Page</span>
                </button>
                {authUser && (
                  <button
                    type="button"
                    onClick={handleLogout}
                    className="w-full py-2 px-3 rounded-lg border border-[#F87171]/40 text-xs font-medium text-[#F87171] flex items-center justify-center gap-2"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Sign Out</span>
                  </button>
                )}
              </div>
            </aside>
          </div>
        )}

        {/* Main Content Area */}
        <div className="flex-1 lg:pl-64 flex flex-col min-w-0 pb-20 lg:pb-8">
          {/* Top Workspace Header */}
          <header className="sticky top-0 z-20 h-16 bg-[#0F172A]/90 backdrop-blur-md border-b border-slate-800/90 px-4 sm:px-6 flex items-center justify-between gap-4 print:hidden">
            <div className="flex items-center gap-3 min-w-0">
              <button
                type="button"
                onClick={() => setMobileMenuOpen(true)}
                className="lg:hidden p-2 rounded-lg text-[#CBD5E1] hover:text-[#F8FAFC] hover:bg-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
                aria-label="Open menu"
              >
                <Menu className="w-5 h-5" />
              </button>
              <div className="min-w-0">
                <div className="text-xs text-[#CBD5E1] hidden sm:block">
                  DreamLog – SnoozeScience / {activeNavMeta.label}
                </div>
                <h1 className="font-display text-base sm:text-lg font-bold text-[#F8FAFC] truncate">
                  {activeNavMeta.label}
                </h1>
              </div>
            </div>

            <div className="flex items-center gap-2.5 shrink-0">
              <button
                type="button"
                onClick={() => setQuickModalMode('sleep')}
                className="hidden sm:inline-flex px-3 py-1.5 rounded-lg border border-slate-700 bg-[#1E293B] text-xs font-medium text-[#F8FAFC] hover:border-[#60A5FA]/60 transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
              >
                + Sleep
              </button>
              <button
                type="button"
                onClick={() => setQuickModalMode('study')}
                className="hidden sm:inline-flex px-3 py-1.5 rounded-lg bg-[#60A5FA] text-xs font-semibold text-[#0F172A] hover:bg-[#93C5FD] transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
              >
                + Study
              </button>

              {/* Notification Area */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setNotificationsOpen((v) => !v)}
                  className="relative p-2 rounded-lg border border-slate-800 bg-[#1E293B] text-[#CBD5E1] hover:text-[#F8FAFC] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
                  aria-label="Notifications"
                >
                  <Bell className="w-4 h-4" />
                  {notifications.length > 0 && (
                    <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#FBBF24] text-[#0F172A] text-[10px] font-mono font-bold flex items-center justify-center">
                      {notifications.length}
                    </span>
                  )}
                </button>

                {notificationsOpen && (
                  <div className="absolute right-0 mt-2 w-72 sm:w-80 max-w-[calc(100vw-2rem)] rounded-xl border border-slate-700 bg-[#1E293B] shadow-2xl p-4 z-40">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-semibold text-[#F8FAFC]">
                        Workspace Notifications
                      </span>
                      <button
                        type="button"
                        onClick={() => setNotificationsOpen(false)}
                        className="text-xs text-[#CBD5E1] hover:text-[#F8FAFC]"
                      >
                        Close
                      </button>
                    </div>
                    {notifications.length === 0 ? (
                      <p className="text-xs text-[#CBD5E1]">All metrics look balanced.</p>
                    ) : (
                      <div className="divide-y divide-slate-800">
                        {notifications.map((n) => (
                          <button
                            key={n.id}
                            type="button"
                            onClick={() => {
                              navigateTo(n.target);
                              setNotificationsOpen(false);
                            }}
                            className="w-full py-2.5 text-left hover:bg-slate-800/40 rounded px-1.5 transition-colors"
                          >
                            <div className="text-xs font-semibold text-[#F8FAFC]">{n.title}</div>
                            <div className="text-[11px] text-[#CBD5E1] mt-0.5">{n.detail}</div>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </header>

          {/* DEMO DATA Notice Banner */}
          {analytics?.hasDemoData && (
            <div className="mx-4 sm:mx-6 mt-5 rounded-xl border border-[#FBBF24]/30 bg-[#FBBF24]/10 px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 print:hidden">
              <div className="flex items-center gap-2.5 text-xs text-[#FDE68A]">
                <Database className="w-4 h-4 text-[#FBBF24] shrink-0" />
                <span>
                  <strong>DEMO DATA</strong> active ({analytics.demoCount} seeded records over 21 days). Add your own logs to see live recalculation, or clear demo records anytime.
                </span>
              </div>
              <button
                type="button"
                onClick={() => setConfirmClearDemo(true)}
                className="px-3 py-1.5 rounded-lg bg-[#1E293B] border border-slate-700 text-xs font-medium text-[#F8FAFC] hover:border-[#F87171] transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
              >
                Clear Demo Data
              </button>
            </div>
          )}

          {/* Active Module Viewport */}
          <main className="flex-1 p-4 sm:p-6 max-w-7xl w-full mx-auto">
            <Suspense fallback={<DashboardSkeleton />}>
              {activeTab === 'dashboard' && (
                <DashboardView
                  analytics={analytics}
                  settings={settings}
                  loading={loading}
                  daysWindow={daysWindow}
                  onChangeDaysWindow={handleChangeDaysWindow}
                  onNavigate={navigateTo}
                  onDismissOnboarding={handleDismissOnboarding}
                  onOpenQuickSleep={() => setQuickModalMode('sleep')}
                  onOpenQuickStudy={() => setQuickModalMode('study')}
                  onRunDemoScenario={() => handleRunDemoScenario(false)}
                  onResetDemoScenario={handleResetDemoScenario}
                  runningDemo={runningDemo}
                />
              )}

              {activeTab === 'sleep' && (
                <SleepTrackerView
                  logs={sleepLogs}
                  onDataChanged={() => loadAllData(daysWindow)}
                  onNotify={notify}
                />
              )}

              {activeTab === 'study' && (
                <StudyTrackerView
                  logs={studyLogs}
                  subjectStats={analytics?.subjectStats ?? []}
                  onDataChanged={() => loadAllData(daysWindow)}
                  onNotify={notify}
                />
              )}

              {activeTab === 'analytics' && analytics && (
                <AnalyticsView
                  analytics={analytics}
                  daysWindow={daysWindow}
                  onChangeDaysWindow={handleChangeDaysWindow}
                />
              )}

              {activeTab === 'sleep-debt' && analytics && (
                <SleepDebtView
                  sleepDebt={analytics.sleepDebt}
                  onNavigateSleep={() => navigateTo('sleep')}
                />
              )}

              {activeTab === 'bedtime' && (
                <BedtimeView defaultWakeTime={settings.preferredWakeTime} />
              )}

              {activeTab === 'caffeine' && (
                <CaffeineView
                  logs={caffeineLogs}
                  dailySeries={analytics?.dailySeries ?? []}
                  halfLifeHours={settings.caffeineHalfLifeHours}
                  onDataChanged={() => loadAllData(daysWindow)}
                  onNotify={notify}
                />
              )}

              {activeTab === 'exams' && analytics && (
                <ExamPlannerView
                  exams={exams}
                  tasks={examPlanTasks}
                  examPerformance={analytics.examPerformance}
                  settings={settings}
                  onDataChanged={() => loadAllData(daysWindow)}
                  onNotify={notify}
                />
              )}

              {activeTab === 'reports' && analytics && (
                <ReportsView
                  analytics={analytics}
                  settings={settings}
                  daysWindow={daysWindow}
                  onChangeDaysWindow={handleChangeDaysWindow}
                  onNotify={notify}
                />
              )}

              {activeTab === 'settings' && (
                <SettingsView
                  settings={settings}
                  hasDemoData={analytics?.hasDemoData ?? false}
                  demoCount={analytics?.demoCount ?? 0}
                  onDataChanged={() => loadAllData(daysWindow)}
                  onNotify={notify}
                />
              )}

              {activeTab === 'verify' && <VerificationView onNavigate={navigateTo} />}
            </Suspense>
          </main>
        </div>

        {/* Mobile Bottom Navigation */}
        <nav
          className="lg:hidden fixed bottom-0 inset-x-0 z-30 h-16 bg-[#111827]/95 backdrop-blur-md border-t border-slate-800 grid grid-cols-5 px-1 print:hidden"
          aria-label="Mobile Navigation"
        >
          {(
            [
              { id: 'dashboard', label: 'Home', icon: LayoutDashboard },
              { id: 'sleep', label: 'Sleep', icon: Moon },
              { id: 'study', label: 'Study', icon: BookOpen },
              { id: 'analytics', label: 'Stats', icon: TrendingUp },
            ] as const
          ).map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => navigateTo(item.id)}
                className={`flex flex-col items-center justify-center gap-1 text-[11px] font-medium focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA] ${
                  active ? 'text-[#60A5FA]' : 'text-[#CBD5E1]'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            );
          })}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(true)}
            className="flex flex-col items-center justify-center gap-1 text-[11px] font-medium text-[#CBD5E1] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
          >
            <Menu className="w-4 h-4" />
            <span>More</span>
          </button>
        </nav>

        {/* Quick Log Modal */}
        <QuickLogModal
          mode={quickModalMode}
          onClose={() => setQuickModalMode(null)}
          onSaved={() => loadAllData(daysWindow)}
          onNotify={notify}
        />

        {/* Demo Data Clear Confirmation */}
        <ConfirmModal
          open={confirmClearDemo}
          title="Clear 21-Day Demo Dataset"
          message="This deletes all DEMO DATA entries while preserving any personal records you created. You can restore the sample dataset anytime in Settings."
          confirmLabel="Clear Demo Data"
          variant="danger"
          onConfirm={handleClearDemoData}
          onCancel={() => setConfirmClearDemo(false)}
        />

        {/* Auth Modal */}
        <AuthModal
          open={authModalOpen}
          onClose={() => setAuthModalOpen(false)}
          onAuthenticated={handleAuthenticated}
          onNotify={notify}
        />

        {/* Toast Notifications */}
        <ToastList
          toasts={toasts}
          onDismiss={(id) => setToasts((p) => p.filter((t) => t.id !== id))}
        />
      </div>
    </ErrorBoundary>
  );
}
