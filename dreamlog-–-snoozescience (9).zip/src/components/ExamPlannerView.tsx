import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Award,
  Calendar,
  CheckSquare,
  Clock,
  Info,
  Plus,
  RefreshCw,
  ShieldCheck,
  Square,
  Trash2,
} from 'lucide-react';
import { api } from '../api/client.ts';
import {
  formatShortDate,
  formatTime12h,
  getLocalDateStr,
  getWeekdayName,
  validateScheduleFeasibility,
} from '../shared/math.ts';
import type {
  ExamPerformanceAnalysis,
  ExamPlanTask,
  ExamPriority,
  ExamSchedule,
  ScheduleFeasibilityReport,
  UserSettings,
} from '../shared/types.ts';
import { ConfirmModal, EmptyState } from './ui.tsx';

export function ExamPlannerView({
  exams,
  tasks,
  examPerformance,
  settings,
  onDataChanged,
  onNotify,
}: {
  exams: ExamSchedule[];
  tasks: ExamPlanTask[];
  examPerformance: ExamPerformanceAnalysis;
  settings: UserSettings;
  onDataChanged: () => Promise<void>;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}) {
  const [examDate, setExamDate] = useState(getLocalDateStr(5));
  const [subject, setSubject] = useState('');
  const [topics, setTopics] = useState('');
  const [priority, setPriority] = useState<ExamPriority>('High');
  const [topicDifficulty, setTopicDifficulty] = useState('3');
  const [estimatedHours, setEstimatedHours] = useState('6');
  const [dailyAvailableHours, setDailyAvailableHours] = useState(
    String(Math.min(8, settings.dailyAvailableHours || 7)),
  );
  const [preferredWakeTime, setPreferredWakeTime] = useState(settings.preferredWakeTime || '07:30');

  // Past exam result form
  const [resSubject, setResSubject] = useState('');
  const [resDate, setResDate] = useState(getLocalDateStr(-1));
  const [resScore, setResScore] = useState('88');
  const [resNotes, setResNotes] = useState('');
  const [savingResult, setSavingResult] = useState(false);

  const [viewMode, setViewMode] = useState<'daily' | 'weekly' | 'checklist'>('daily');
  const [selectedDay, setSelectedDay] = useState<string>('');
  const [capacityWarning, setCapacityWarning] = useState<string | null>(null);
  const [decisions, setDecisions] = useState<string[]>([]);
  const [latestFeasibility, setLatestFeasibility] = useState<ScheduleFeasibilityReport | null>(null);
  const [generating, setGenerating] = useState(false);
  const [rescheduling, setRescheduling] = useState(false);
  const [addingExam, setAddingExam] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<ExamSchedule | null>(null);
  const [deleteResultTarget, setDeleteResultTarget] = useState<number | null>(null);

  const uniqueDates = useMemo(
    () => Array.from(new Set(tasks.map((t) => t.date))).sort(),
    [tasks],
  );
  const activeDay = selectedDay && uniqueDates.includes(selectedDay) ? selectedDay : uniqueDates[0] || '';
  const dayTasks = useMemo(
    () => tasks.filter((t) => t.date === activeDay),
    [tasks, activeDay],
  );

  const studyTasksOnly = useMemo(() => tasks.filter((t) => t.type === 'study'), [tasks]);
  const completedCount = useMemo(
    () => studyTasksOnly.filter((t) => t.completed).length,
    [studyTasksOnly],
  );
  const todayStr = getLocalDateStr(0);
  const overdueMissedCount = useMemo(
    () => studyTasksOnly.filter((t) => !t.completed && t.date < todayStr).length,
    [studyTasksOnly, todayStr],
  );

  const liveFeasibility = useMemo(() => {
    if (latestFeasibility) return latestFeasibility;
    if (tasks.length === 0) return null;
    return validateScheduleFeasibility(
      tasks,
      exams,
      Number(dailyAvailableHours) || settings.dailyAvailableHours || 7,
      preferredWakeTime || settings.preferredWakeTime || '07:30',
      todayStr,
    );
  }, [latestFeasibility, tasks, exams, dailyAvailableHours, preferredWakeTime, settings, todayStr]);

  const handleAddExam = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim()) {
      onNotify('error', 'Please enter an exam subject.');
      return;
    }
    setAddingExam(true);
    try {
      await api.createExam({
        examDate,
        subject: subject.trim(),
        topics: topics.trim() || `${subject.trim()} Core Review`,
        priority,
        estimatedHours: Math.max(1, Math.min(40, Number(estimatedHours) || 6)),
        topicDifficulty: Math.max(1, Math.min(5, Number(topicDifficulty) || 3)),
      });
      setSubject('');
      setTopics('');
      setTopicDifficulty('3');
      setLatestFeasibility(null);
      onNotify('success', `Added ${subject.trim()} exam on ${formatShortDate(examDate)}.`);
      await onDataChanged();
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Failed to add exam.');
    } finally {
      setAddingExam(false);
    }
  };

  const handleAddExamResult = async (e: React.FormEvent) => {
    e.preventDefault();
    const score = Number(resScore);
    if (!resSubject.trim() || Number.isNaN(score) || score < 0 || score > 100) {
      onNotify('error', 'Provide a subject and exam score between 0 and 100.');
      return;
    }
    setSavingResult(true);
    try {
      await api.createExamResult({
        subject: resSubject.trim(),
        examDate: resDate,
        scorePercent: score,
        notes: resNotes.trim(),
      });
      setResSubject('');
      setResNotes('');
      onNotify('success', `Logged ${score}% exam result for ${resSubject.trim()}.`);
      await onDataChanged();
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Failed to save exam result.');
    } finally {
      setSavingResult(false);
    }
  };

  const handleGeneratePlan = async () => {
    const requestedDaily = Number(dailyAvailableHours) || 7;
    if (requestedDaily > 8) {
      onNotify(
        'info',
        'Daily study is automatically capped at 8 hours to preserve restorative sleep.',
      );
    }
    setGenerating(true);
    try {
      const res = await api.generateExamPlan({
        dailyAvailableHours: Math.min(8, Math.max(1, requestedDaily)),
        preferredWakeTime,
      });
      setCapacityWarning(res.capacityWarning);
      setDecisions(res.decisions || []);
      setLatestFeasibility(res.feasibility || null);
      if (res.tasks[0]) setSelectedDay(res.tasks[0].date);
      onNotify(
        'success',
        `Generated sleep-protected schedule (${res.totalScheduledHours}h study across ${res.daysPlanned} days).`,
      );
      await onDataChanged();
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Failed to generate timetable.');
    } finally {
      setGenerating(false);
    }
  };

  const handleRescheduleMissed = async (explicitIds?: number[]) => {
    setRescheduling(true);
    try {
      const requestedDaily = Math.min(8, Math.max(1, Number(dailyAvailableHours) || 7));
      const res = await api.rescheduleExamPlan({
        missedTaskIds: explicitIds,
        dailyAvailableHours: requestedDaily,
        preferredWakeTime,
      });
      setCapacityWarning(res.capacityWarning);
      setDecisions(res.decisions || []);
      setLatestFeasibility(res.feasibility || null);
      if (res.tasks[0]) setSelectedDay(res.tasks[0].date);
      onNotify(
        'success',
        res.rescheduledCount > 0
          ? `Rescheduled ${res.rescheduledCount} missed study block(s) (${res.rescheduledHours}h) while preserving 7.5h nightly sleep.`
          : 'Rebalanced active timetable by priority and deadline urgency.',
      );
      await onDataChanged();
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Failed to reschedule tasks.');
    } finally {
      setRescheduling(false);
    }
  };

  const handleToggleTask = async (task: ExamPlanTask) => {
    try {
      await api.updateExamPlanTask(task.id, { completed: !task.completed });
      await onDataChanged();
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Failed to update task.');
    }
  };

  const handleConfirmDeleteExam = async () => {
    if (!deleteTarget) return;
    try {
      await api.deleteExam(deleteTarget.id);
      setLatestFeasibility(null);
      onNotify('info', `Removed ${deleteTarget.subject} exam.`);
      setDeleteTarget(null);
      await onDataChanged();
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Failed to delete exam.');
    }
  };

  const handleConfirmDeleteResult = async () => {
    if (deleteResultTarget === null) return;
    try {
      await api.deleteExamResult(deleteResultTarget);
      onNotify('info', 'Removed exam result.');
      setDeleteResultTarget(null);
      await onDataChanged();
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Failed to delete exam result.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Mandatory Constraints & Feasibility Banner */}
      <div className="rounded-xl border border-[#34D399]/30 bg-[#1E293B]/80 p-4 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-[#34D399] shrink-0 mt-0.5" />
            <div>
              <h2 className="text-sm font-semibold text-[#F8FAFC]">
                Exam Week Sleep Preserver — Protective Invariants Active
              </h2>
              <p className="text-xs text-[#CBD5E1] mt-0.5">
                Prioritizes high-urgency deadlines, enforces &le;8h daily study, reserves &ge;7h nightly sleep, and detects overlapping meals/breaks automatically.
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <span className="font-mono text-xs text-[#34D399] tabular-nums">
              {completedCount}/{studyTasksOnly.length} completed
            </span>
            {tasks.length > 0 && (
              <button
                type="button"
                disabled={rescheduling || exams.length === 0}
                onClick={() => handleRescheduleMissed()}
                className="px-3 py-1.5 rounded-lg border border-[#60A5FA]/50 bg-[#60A5FA]/15 text-[#93C5FD] text-xs font-semibold hover:bg-[#60A5FA]/25 disabled:opacity-50 transition-colors inline-flex items-center gap-1.5"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${rescheduling ? 'animate-spin' : ''}`} />
                <span>
                  {rescheduling
                    ? 'Rescheduling...'
                    : overdueMissedCount > 0
                      ? `Reschedule ${overdueMissedCount} Missed`
                      : 'Rebalance Missed / Forward'}
                </span>
              </button>
            )}
          </div>
        </div>

        {liveFeasibility && (
          <div className="pt-2.5 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className={liveFeasibility.feasible ? 'text-[#34D399]' : 'text-[#FBBF24]'}>
              {liveFeasibility.summary}
            </span>
            <span className="font-mono text-[#94A3B8] tabular-nums">
              Overlaps: {liveFeasibility.overlapCount} · Max study: {liveFeasibility.maxDailyStudyHours.toFixed(1)}h/d · Min sleep: {liveFeasibility.minSleepHours.toFixed(1)}h
            </span>
          </div>
        )}
      </div>

      {capacityWarning && (
        <div className="rounded-xl border border-[#F59E0B]/40 bg-[#F59E0B]/10 p-4 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-[#FBBF24] shrink-0 mt-0.5" />
          <p className="text-xs sm:text-sm text-[#FDE68A] leading-relaxed">{capacityWarning}</p>
        </div>
      )}

      {decisions.length > 0 && (
        <div className="rounded-xl border border-slate-800 bg-[#111827]/90 p-4 space-y-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#60A5FA]">
            <Info className="w-4 h-4 shrink-0" />
            <span>Scheduling Decisions &amp; Priority Explanations</span>
          </div>
          <ul className="space-y-1 text-xs text-[#CBD5E1] list-disc pl-5">
            {decisions.map((d, idx) => (
              <li key={idx}>{d}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Add Exams & Generator Controls */}
        <div className="lg:col-span-4 space-y-6">
          <form
            onSubmit={handleAddExam}
            className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5 space-y-3.5"
          >
            <h3 className="text-sm font-semibold text-[#F8FAFC]">Add Upcoming Exam</h3>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="exam-date" className="block text-xs text-[#CBD5E1] mb-1">
                  Exam Date
                </label>
                <input
                  id="exam-date"
                  type="date"
                  value={examDate}
                  onChange={(e) => setExamDate(e.target.value)}
                  required
                  className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-xs text-[#F8FAFC]"
                />
              </div>
              <div>
                <label htmlFor="exam-priority" className="block text-xs text-[#CBD5E1] mb-1">
                  Priority
                </label>
                <select
                  id="exam-priority"
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as ExamPriority)}
                  className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-xs text-[#F8FAFC]"
                >
                  <option value="High">High</option>
                  <option value="Medium">Medium</option>
                  <option value="Low">Low</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="col-span-2">
                <label htmlFor="exam-subject" className="block text-xs text-[#CBD5E1] mb-1">
                  Subject
                </label>
                <input
                  id="exam-subject"
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="e.g., Data Structures"
                  required
                  className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-xs text-[#F8FAFC]"
                />
              </div>
              <div>
                <label htmlFor="exam-hours" className="block text-xs text-[#CBD5E1] mb-1">
                  Est. Hours
                </label>
                <input
                  id="exam-hours"
                  type="number"
                  min="1"
                  max="40"
                  value={estimatedHours}
                  onChange={(e) => setEstimatedHours(e.target.value)}
                  className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-xs font-mono text-[#F8FAFC]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <label htmlFor="exam-topics" className="block text-xs text-[#CBD5E1] mb-1">
                  Study Topics (comma-separated)
                </label>
                <input
                  id="exam-topics"
                  type="text"
                  value={topics}
                  onChange={(e) => setTopics(e.target.value)}
                  placeholder="Trees, Graph BFS/DFS, Hashing"
                  className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-xs text-[#F8FAFC]"
                />
              </div>
              <div>
                <label htmlFor="exam-difficulty" className="block text-xs text-[#CBD5E1] mb-1">
                  Topic Difficulty
                </label>
                <select
                  id="exam-difficulty"
                  value={topicDifficulty}
                  onChange={(e) => setTopicDifficulty(e.target.value)}
                  className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-xs text-[#F8FAFC]"
                >
                  <option value="1">1 - Easy</option>
                  <option value="2">2 - Light</option>
                  <option value="3">3 - Moderate</option>
                  <option value="4">4 - Hard</option>
                  <option value="5">5 - Very Hard</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              disabled={addingExam}
              className="w-full py-2 px-4 rounded-lg bg-[#111827] border border-slate-700 text-xs font-semibold text-[#F8FAFC] hover:border-[#60A5FA] transition-colors inline-flex items-center justify-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5 text-[#60A5FA]" />
              <span>{addingExam ? 'Adding...' : 'Add Exam Target'}</span>
            </button>
          </form>

          {/* Upcoming Exams List + Schedule Generator */}
          <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5 space-y-4">
            <h3 className="text-sm font-semibold text-[#F8FAFC]">
              Upcoming Exams ({exams.length})
            </h3>
            {exams.length === 0 ? (
              <p className="text-xs text-[#CBD5E1]">Add at least one exam above to generate a plan.</p>
            ) : (
              <div className="space-y-2.5">
                {exams.map((ex) => (
                  <div
                    key={ex.id}
                    className="rounded-lg bg-[#0F172A]/70 border border-slate-800 p-3 flex items-start justify-between gap-2"
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-[#F8FAFC] truncate">
                        {ex.subject}{' '}
                        <span
                          className={`ml-1 ${
                            ex.priority === 'High'
                              ? 'text-[#F87171]'
                              : ex.priority === 'Medium'
                                ? 'text-[#FBBF24]'
                                : 'text-[#34D399]'
                          }`}
                        >
                          · {ex.priority}
                        </span>
                      </div>
                      <div className="text-[11px] text-[#CBD5E1] mt-0.5">
                        {formatShortDate(ex.examDate)} · {ex.estimatedHours}h target · diff{' '}
                        {ex.topicDifficulty ?? 3}/5
                      </div>
                      <div className="text-[11px] text-[#94A3B8] truncate">{ex.topics}</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setDeleteTarget(ex)}
                      className="p-1 text-[#CBD5E1] hover:text-[#F87171]"
                      aria-label={`Delete ${ex.subject}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div className="pt-3 border-t border-slate-800 space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="plan-daily-hrs" className="block text-xs text-[#CBD5E1] mb-1">
                    Daily Study Cap (&lt;=8h)
                  </label>
                  <input
                    id="plan-daily-hrs"
                    type="number"
                    min="1"
                    max="8"
                    step="0.5"
                    value={dailyAvailableHours}
                    onChange={(e) => setDailyAvailableHours(e.target.value)}
                    className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-xs font-mono text-[#F8FAFC]"
                  />
                </div>
                <div>
                  <label htmlFor="plan-wake" className="block text-xs text-[#CBD5E1] mb-1">
                    Wake-up Time
                  </label>
                  <input
                    id="plan-wake"
                    type="time"
                    value={preferredWakeTime}
                    onChange={(e) => setPreferredWakeTime(e.target.value)}
                    className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-xs font-mono text-[#F8FAFC]"
                  />
                </div>
              </div>

              <button
                type="button"
                disabled={generating || exams.length === 0}
                onClick={handleGeneratePlan}
                className="w-full py-2.5 px-4 rounded-lg bg-[#60A5FA] text-[#0F172A] text-xs font-semibold hover:bg-[#93C5FD] disabled:opacity-50 transition-colors"
              >
                {generating ? 'Building Schedule...' : 'Generate Protective Timetable'}
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Timetable Views */}
        <div className="lg:col-span-8 rounded-xl border border-slate-800 bg-[#1E293B]/75 p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h3 className="text-base font-semibold text-[#F8FAFC]">Protective Study Timetable</h3>

            <div className="flex items-center gap-1 p-1 bg-[#0F172A] border border-slate-800 rounded-lg">
              {(
                [
                  { id: 'daily', label: 'Daily Schedule' },
                  { id: 'weekly', label: 'Weekly Calendar' },
                  { id: 'checklist', label: 'Task Checklist' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setViewMode(tab.id)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    viewMode === tab.id
                      ? 'bg-[#60A5FA] text-[#0F172A] font-semibold'
                      : 'text-[#CBD5E1] hover:text-[#F8FAFC]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {tasks.length === 0 ? (
            <EmptyState
              icon={Calendar}
              title="No timetable generated yet"
              description="Add your exam subjects on the left and click Generate Protective Timetable."
            />
          ) : viewMode === 'daily' ? (
            <div className="space-y-4">
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                {uniqueDates.map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setSelectedDay(d)}
                    className={`px-3 py-1.5 rounded-lg text-xs border transition-colors whitespace-nowrap shrink-0 ${
                      activeDay === d
                        ? 'bg-[#60A5FA]/20 border-[#60A5FA] text-[#F8FAFC] font-semibold'
                        : 'bg-[#0F172A] border-slate-800 text-[#CBD5E1] hover:text-[#F8FAFC]'
                    }`}
                  >
                    {getWeekdayName(d).slice(0, 3)} · {formatShortDate(d)}
                  </button>
                ))}
              </div>

              <div className="divide-y divide-slate-800/80">
                {dayTasks.map((t) => (
                  <div key={t.id} className="py-3 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3 min-w-0">
                      {t.type === 'study' ? (
                        <button
                          type="button"
                          onClick={() => handleToggleTask(t)}
                          className="text-[#60A5FA] hover:text-[#93C5FD] shrink-0"
                          aria-label={`Mark ${t.title} complete`}
                        >
                          {t.completed ? (
                            <CheckSquare className="w-4 h-4 text-[#34D399]" />
                          ) : (
                            <Square className="w-4 h-4" />
                          )}
                        </button>
                      ) : (
                        <Clock className="w-4 h-4 text-[#94A3B8] shrink-0" />
                      )}
                      <div className="min-w-0">
                        <div
                          className={`text-sm font-medium truncate ${
                            t.completed
                              ? 'line-through text-[#94A3B8]'
                              : t.type === 'sleep'
                                ? 'text-[#60A5FA]'
                                : t.type === 'meal' || t.type === 'break'
                                  ? 'text-[#34D399]'
                                  : 'text-[#F8FAFC]'
                          }`}
                        >
                          {t.title}
                        </div>
                        <div className="text-xs text-[#CBD5E1] capitalize">
                          {t.type} · {t.subject}
                          {t.schedulingReason && (
                            <span className="text-[#94A3B8] normal-case">
                              {' '}— {t.schedulingReason}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2.5 shrink-0">
                      {t.type === 'study' && !t.completed && (
                        <button
                          type="button"
                          disabled={rescheduling}
                          onClick={() => handleRescheduleMissed([t.id])}
                          className="px-2 py-1 rounded border border-slate-700 text-[11px] text-[#93C5FD] hover:border-[#60A5FA] hover:bg-[#60A5FA]/10 transition-colors"
                          title="Mark missed and reschedule into upcoming capacity"
                        >
                          Missed?
                        </button>
                      )}
                      <div className="font-mono text-xs text-[#CBD5E1] tabular-nums">
                        {formatTime12h(t.startTime)} – {formatTime12h(t.endTime)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : viewMode === 'weekly' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[540px] overflow-y-auto pr-1">
              {uniqueDates.slice(0, 7).map((d) => {
                const items = tasks.filter((t) => t.date === d);
                return (
                  <div key={d} className="rounded-lg border border-slate-800 bg-[#0F172A]/70 p-4">
                    <div className="text-xs font-semibold text-[#F8FAFC] mb-2.5 flex items-center justify-between">
                      <span>
                        {getWeekdayName(d)} · {formatShortDate(d)}
                      </span>
                      <span className="font-mono text-[#60A5FA]">
                        {items.filter((i) => i.type === 'study').length} study blocks
                      </span>
                    </div>
                    <div className="space-y-1.5 text-xs">
                      {items.map((i) => (
                        <div key={i.id} className="flex items-center justify-between gap-2">
                          <span
                            className={`truncate ${
                              i.type === 'sleep'
                                ? 'text-[#60A5FA]'
                                : i.type === 'study'
                                  ? 'text-[#F8FAFC]'
                                  : 'text-[#CBD5E1]'
                            }`}
                          >
                            {i.title}
                          </span>
                          <span className="font-mono text-[11px] text-[#CBD5E1] shrink-0">
                            {i.startTime}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="divide-y divide-slate-800/80 max-h-[520px] overflow-y-auto">
              {studyTasksOnly.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => handleToggleTask(t)}
                  className="w-full py-3 flex items-center justify-between gap-3 text-left hover:bg-slate-800/30 px-2 rounded-lg transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    {t.completed ? (
                      <CheckSquare className="w-4 h-4 text-[#34D399] shrink-0" />
                    ) : (
                      <Square className="w-4 h-4 text-[#60A5FA] shrink-0" />
                    )}
                    <div className="min-w-0">
                      <div
                        className={`text-sm font-medium truncate ${
                          t.completed ? 'line-through text-[#94A3B8]' : 'text-[#F8FAFC]'
                        }`}
                      >
                        {t.title}
                      </div>
                      <div className="text-xs text-[#CBD5E1]">
                        {formatShortDate(t.date)} · {formatTime12h(t.startTime)} – {formatTime12h(t.endTime)}
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Sleep vs Exam Performance (Step 4: Past Exam Results) */}
      <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-6 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <Award className="w-5 h-5 text-[#FBBF24]" />
            <div>
              <h3 className="text-base font-semibold text-[#F8FAFC]">
                Completed Exam Results (Sleep vs Exam Performance)
              </h3>
              <p className="text-xs text-[#CBD5E1]">
                Tracks your exam scores against your average sleep in the 3 nights prior to each exam (included in PDF reports).
              </p>
            </div>
          </div>
          <div className="text-xs font-mono text-[#FBBF24]">
            {examPerformance.hasConfidence && examPerformance.r !== null
              ? `r = ${examPerformance.r >= 0 ? '+' : ''}${examPerformance.r.toFixed(2)} (n = ${examPerformance.observationCount})`
              : `${examPerformance.confidenceWarning} (${examPerformance.observationCount}/5)`}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <form onSubmit={handleAddExamResult} className="lg:col-span-4 space-y-3 bg-[#0F172A]/60 border border-slate-800 rounded-xl p-4">
            <h4 className="text-xs font-semibold text-[#F8FAFC]">Record Past Exam Score</h4>
            <div>
              <label htmlFor="res-subject" className="block text-xs text-[#CBD5E1] mb-1">
                Subject
              </label>
              <input
                id="res-subject"
                type="text"
                value={resSubject}
                onChange={(e) => setResSubject(e.target.value)}
                placeholder="e.g., Data Structures"
                required
                className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-xs text-[#F8FAFC]"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="res-date" className="block text-xs text-[#CBD5E1] mb-1">
                  Exam Date
                </label>
                <input
                  id="res-date"
                  type="date"
                  value={resDate}
                  onChange={(e) => setResDate(e.target.value)}
                  required
                  className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-xs text-[#F8FAFC]"
                />
              </div>
              <div>
                <label htmlFor="res-score" className="block text-xs text-[#CBD5E1] mb-1">
                  Score (0–100%)
                </label>
                <input
                  id="res-score"
                  type="number"
                  min="0"
                  max="100"
                  step="0.5"
                  value={resScore}
                  onChange={(e) => setResScore(e.target.value)}
                  required
                  className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-xs font-mono text-[#F8FAFC]"
                />
              </div>
            </div>
            <div>
              <label htmlFor="res-notes" className="block text-xs text-[#CBD5E1] mb-1">
                Notes (optional)
              </label>
              <input
                id="res-notes"
                type="text"
                value={resNotes}
                onChange={(e) => setResNotes(e.target.value)}
                placeholder="e.g., Midterm 2"
                className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-xs text-[#F8FAFC]"
              />
            </div>
            <button
              type="submit"
              disabled={savingResult}
              className="w-full py-2 px-4 rounded-lg bg-[#60A5FA] text-[#0F172A] text-xs font-semibold hover:bg-[#93C5FD] disabled:opacity-50"
            >
              {savingResult ? 'Saving...' : 'Add Exam Result'}
            </button>
          </form>

          <div className="lg:col-span-8 overflow-x-auto">
            {examPerformance.points.length === 0 ? (
              <p className="text-xs text-[#CBD5E1]">No past exam results logged yet.</p>
            ) : (
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-800 text-xs text-[#CBD5E1]">
                    <th className="py-2 pr-3">Subject</th>
                    <th className="py-2 px-3">Exam Date</th>
                    <th className="py-2 px-3 text-right">3-Night Avg Sleep</th>
                    <th className="py-2 px-3 text-right">Score</th>
                    <th className="py-2 pl-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/70">
                  {examPerformance.points.map((pt) => (
                    <tr key={pt.examId} className="hover:bg-slate-800/30">
                      <td className="py-2.5 pr-3">
                        <div className="font-medium text-[#F8FAFC]">{pt.subject}</div>
                        {pt.notes && <div className="text-xs text-[#94A3B8]">{pt.notes}</div>}
                      </td>
                      <td className="py-2.5 px-3 text-xs text-[#CBD5E1] whitespace-nowrap">
                        {formatShortDate(pt.examDate)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-xs text-[#60A5FA] tabular-nums">
                        {pt.preExamAvgSleep !== null
                          ? `${pt.preExamAvgSleep.toFixed(2)}h (${pt.sleepNightsCount}/3 nights)`
                          : 'No prior sleep logs'}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-semibold text-[#34D399] tabular-nums">
                        {pt.scorePercent.toFixed(1)}%
                      </td>
                      <td className="py-2.5 pl-3 text-right">
                        <button
                          type="button"
                          onClick={() => setDeleteResultTarget(pt.examId)}
                          className="p-1.5 rounded-lg text-[#CBD5E1] hover:text-[#F87171]"
                          aria-label={`Delete exam result ${pt.subject}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>

      <ConfirmModal
        open={deleteTarget !== null}
        title="Remove Exam Target"
        message={`Delete ${deleteTarget?.subject ?? ''} exam from your exam list?`}
        onConfirm={handleConfirmDeleteExam}
        onCancel={() => setDeleteTarget(null)}
      />

      <ConfirmModal
        open={deleteResultTarget !== null}
        title="Remove Exam Result"
        message="Delete this past exam result from your performance records?"
        onConfirm={handleConfirmDeleteResult}
        onCancel={() => setDeleteResultTarget(null)}
      />
    </div>
  );
}
