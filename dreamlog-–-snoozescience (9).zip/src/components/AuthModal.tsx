import React, { useState } from 'react';
import { Lock, LogIn, Moon, Sparkles, UserPlus, X } from 'lucide-react';
import { api } from '../api/client.ts';
import type { AuthUser } from '../shared/types.ts';

export function AuthModal({
  open,
  initialMode = 'login',
  onClose,
  onAuthenticated,
  onNotify,
}: {
  open: boolean;
  initialMode?: 'login' | 'register';
  onClose: () => void;
  onAuthenticated: (user: AuthUser) => Promise<void>;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}) {
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  if (!open) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSubmitting(true);
    try {
      const res =
        mode === 'register'
          ? await api.register({ name: name.trim(), email: email.trim(), password })
          : await api.login({ email: email.trim(), password });
      await onAuthenticated(res.user);
      onNotify(
        'success',
        mode === 'register'
          ? `Welcome to DreamLog, ${res.user.name}. Your private workspace is ready.`
          : `Signed in as ${res.user.name}.`,
      );
      setPassword('');
      onClose();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleEnterDemo = async () => {
    setErrorMsg(null);
    setSubmitting(true);
    try {
      const res = await api.demoSession();
      await onAuthenticated(res.user);
      onNotify('info', 'Entered Demo Student workspace (21-day sample telemetry active).');
      onClose();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to start demo session.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="auth-modal-title"
    >
      <div className="w-full max-w-md rounded-2xl border border-slate-700 bg-[#1E293B] shadow-2xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-[#111827]">
          <div className="flex items-center gap-2.5">
            <Moon className="w-5 h-5 text-[#60A5FA]" />
            <h2 id="auth-modal-title" className="font-display text-base font-bold text-[#F8FAFC]">
              DreamLog Account Access
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#CBD5E1] hover:text-[#F8FAFC] hover:bg-slate-800"
            aria-label="Close authentication modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          <div className="grid grid-cols-2 gap-1 p-1 rounded-lg bg-[#0F172A] border border-slate-800">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setErrorMsg(null);
              }}
              className={`py-2 text-xs font-semibold rounded-md transition-colors inline-flex items-center justify-center gap-1.5 ${
                mode === 'login'
                  ? 'bg-[#60A5FA] text-[#0F172A]'
                  : 'text-[#CBD5E1] hover:text-[#F8FAFC]'
              }`}
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Sign In</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setErrorMsg(null);
              }}
              className={`py-2 text-xs font-semibold rounded-md transition-colors inline-flex items-center justify-center gap-1.5 ${
                mode === 'register'
                  ? 'bg-[#60A5FA] text-[#0F172A]'
                  : 'text-[#CBD5E1] hover:text-[#F8FAFC]'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Create Account</span>
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3.5">
            {mode === 'register' && (
              <div>
                <label htmlFor="auth-name" className="block text-xs font-medium text-[#CBD5E1] mb-1">
                  Student Name
                </label>
                <input
                  id="auth-name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Alex Rivera"
                  required
                  className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3.5 py-2.5 text-sm text-[#F8FAFC] focus:outline-none focus:border-[#60A5FA]"
                />
              </div>
            )}

            <div>
              <label htmlFor="auth-email" className="block text-xs font-medium text-[#CBD5E1] mb-1">
                University or Personal Email
              </label>
              <input
                id="auth-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="student@university.edu"
                required
                className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3.5 py-2.5 text-sm text-[#F8FAFC] focus:outline-none focus:border-[#60A5FA]"
              />
            </div>

            <div>
              <label htmlFor="auth-password" className="block text-xs font-medium text-[#CBD5E1] mb-1">
                Password (min. 6 characters)
              </label>
              <input
                id="auth-password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                minLength={6}
                required
                placeholder="••••••••"
                className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3.5 py-2.5 text-sm text-[#F8FAFC] focus:outline-none focus:border-[#60A5FA]"
              />
            </div>

            {errorMsg && (
              <div className="rounded-lg border border-[#F87171]/40 bg-[#F87171]/10 px-3 py-2 text-xs text-[#FCA5A5]">
                {errorMsg}
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-2.5 px-4 rounded-lg bg-[#60A5FA] text-[#0F172A] text-sm font-semibold hover:bg-[#93C5FD] disabled:opacity-50 transition-colors inline-flex items-center justify-center gap-2"
            >
              <Lock className="w-4 h-4" />
              <span>
                {submitting
                  ? 'Please wait...'
                  : mode === 'register'
                    ? 'Create Private Workspace'
                    : 'Sign In Securely'}
              </span>
            </button>
          </form>

          <div className="pt-3 border-t border-slate-800 space-y-2.5">
            <button
              type="button"
              disabled={submitting}
              onClick={handleEnterDemo}
              className="w-full py-2.5 px-4 rounded-lg border border-[#FBBF24]/40 bg-[#FBBF24]/10 text-[#FDE68A] text-xs font-semibold hover:bg-[#FBBF24]/20 transition-colors inline-flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-[#FBBF24]" />
              <span>Continue in Demo Workspace (Maya Lin · 21-Day Seed)</span>
            </button>
            <p className="text-[11px] text-[#94A3B8] text-center leading-relaxed">
              Passwords are salted and hashed with bcrypt. Each student account stores strictly isolated sleep, study, caffeine, and report records.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
