import React, { Component, useEffect, useRef, useState } from 'react';
import { AlertTriangle, CheckCircle2, Info, RefreshCw, Star, X, XCircle } from 'lucide-react';

export class ErrorBoundary extends Component<
  { children: React.ReactNode },
  { hasError: boolean; message: string }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, message: error.message || 'An unexpected rendering error occurred.' };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#0F172A] text-[#F8FAFC] flex items-center justify-center p-6">
          <div className="max-w-md w-full rounded-2xl border border-slate-800 bg-[#1E293B] p-6 space-y-4">
            <div className="flex items-center gap-3 text-[#F87171]">
              <AlertTriangle className="w-6 h-6 shrink-0" />
              <h1 className="font-display text-lg font-bold">Something went wrong</h1>
            </div>
            <p className="text-sm text-[#CBD5E1] leading-relaxed">{this.state.message}</p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="px-4 py-2 rounded-lg bg-[#60A5FA] text-[#0F172A] text-sm font-semibold hover:bg-[#93C5FD] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA] inline-flex items-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Reload DreamLog</span>
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export function AnimatedNumber({
  value,
  decimals = 1,
  prefix = '',
  suffix = '',
  className = '',
}: {
  value: number;
  decimals?: number;
  prefix?: string;
  suffix?: string;
  className?: string;
}) {
  const [display, setDisplay] = useState(value);
  const prevRef = useRef(value);

  useEffect(() => {
    const prefersReduced =
      typeof window !== 'undefined' &&
      window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if (prefersReduced) {
      setDisplay(value);
      prevRef.current = value;
      return;
    }

    const start = prevRef.current;
    const end = value;
    if (Math.abs(start - end) < 0.001) {
      setDisplay(end);
      return;
    }
    const duration = 340;
    const startTime = performance.now();
    let frameId = 0;

    const tick = (now: number) => {
      const elapsed = now - startTime;
      const t = Math.min(1, elapsed / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      setDisplay(start + (end - start) * eased);
      if (t < 1) {
        frameId = requestAnimationFrame(tick);
      } else {
        prevRef.current = end;
      }
    };

    frameId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frameId);
  }, [value]);

  const formatted = Number.isFinite(display) ? display.toFixed(decimals) : '0';
  return (
    <span className={`tabular-nums ${className}`}>
      {prefix}
      {formatted}
      {suffix}
    </span>
  );
}

export function StarRatingInput({
  value,
  onChange,
  label,
}: {
  value: number;
  onChange: (val: number) => void;
  label?: string;
}) {
  const handleKeyDown = (e: React.KeyboardEvent, star: number) => {
    if (e.key === 'ArrowRight' || e.key === 'ArrowUp') {
      e.preventDefault();
      onChange(Math.min(5, star + 1));
    } else if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') {
      e.preventDefault();
      onChange(Math.max(1, star - 1));
    } else if (['1', '2', '3', '4', '5'].includes(e.key)) {
      e.preventDefault();
      onChange(Number(e.key));
    }
  };

  return (
    <div className="flex items-center gap-1.5" role="radiogroup" aria-label={label || 'Rating'}>
      {[1, 2, 3, 4, 5].map((star) => {
        const active = star <= value;
        const selected = value === star;
        return (
          <button
            key={star}
            type="button"
            onClick={() => onChange(star)}
            onKeyDown={(e) => handleKeyDown(e, star)}
            tabIndex={selected ? 0 : -1}
            className="p-1.5 rounded-lg transition-transform hover:scale-105 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
            aria-label={`${star} out of 5 stars`}
            aria-checked={selected}
            role="radio"
          >
            <Star
              className={`w-5 h-5 transition-colors ${
                active
                  ? 'fill-[#FBBF24] text-[#FBBF24]'
                  : 'text-[#64748B] hover:text-[#94A3B8]'
              }`}
            />
          </button>
        );
      })}
      <span className="ml-2 text-xs font-mono tabular-nums text-[#CBD5E1]">{value}/5</span>
    </div>
  );
}

export function ConfirmModal({
  open,
  title,
  message,
  confirmLabel = 'Confirm Delete',
  variant = 'danger',
  onConfirm,
  onCancel,
}: {
  open: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  variant?: 'danger' | 'primary';
  onConfirm: () => void;
  onCancel: () => void;
}) {
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="confirm-modal-title"
    >
      <div className="w-full max-w-md rounded-xl bg-[#1E293B] border border-slate-700/80 p-6 shadow-2xl">
        <div className="flex items-start gap-3">
          <div
            className={`p-2 rounded-lg shrink-0 ${
              variant === 'danger' ? 'bg-[#F87171]/15 text-[#F87171]' : 'bg-[#60A5FA]/15 text-[#60A5FA]'
            }`}
          >
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div className="flex-1">
            <h3 id="confirm-modal-title" className="text-base font-semibold text-[#F8FAFC]">
              {title}
            </h3>
            <p className="mt-1.5 text-sm text-[#CBD5E1] leading-relaxed">{message}</p>
          </div>
        </div>
        <div className="mt-6 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 text-sm font-medium text-[#CBD5E1] hover:text-[#F8FAFC] rounded-lg border border-slate-700 hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA] ${
              variant === 'danger'
                ? 'bg-[#F87171] text-[#0F172A] hover:bg-[#FCA5A5]'
                : 'bg-[#60A5FA] text-[#0F172A] hover:bg-[#93C5FD]'
            }`}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

export interface ToastItem {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
  onRetry?: () => void;
}

export function ToastList({
  toasts,
  onDismiss,
}: {
  toasts: ToastItem[];
  onDismiss: (id: string) => void;
}) {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-20 md:bottom-6 right-4 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
      {toasts.map((t) => (
        <div
          key={t.id}
          className="pointer-events-auto flex items-start gap-3 rounded-xl bg-[#1E293B] border border-slate-700/80 px-4 py-3 shadow-xl"
          role="status"
          aria-live="polite"
        >
          {t.type === 'success' && <CheckCircle2 className="w-5 h-5 text-[#34D399] shrink-0 mt-0.5" />}
          {t.type === 'error' && <XCircle className="w-5 h-5 text-[#F87171] shrink-0 mt-0.5" />}
          {t.type === 'info' && <Info className="w-5 h-5 text-[#60A5FA] shrink-0 mt-0.5" />}
          <div className="flex-1 min-w-0">
            <p className="text-sm text-[#F8FAFC] leading-snug">{t.message}</p>
            {t.onRetry && (
              <button
                type="button"
                onClick={() => {
                  onDismiss(t.id);
                  t.onRetry?.();
                }}
                className="mt-1.5 text-xs font-semibold text-[#60A5FA] hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA] rounded"
              >
                Retry request
              </button>
            )}
          </div>
          <button
            type="button"
            onClick={() => onDismiss(t.id)}
            className="text-[#94A3B8] hover:text-[#F8FAFC] p-0.5 rounded focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
            aria-label="Dismiss notification"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
}

export function EmptyState({
  icon: Icon,
  title,
  description,
  actionLabel,
  onAction,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
}) {
  return (
    <div className="rounded-xl border border-slate-800 bg-[#1E293B]/60 p-10 text-center flex flex-col items-center justify-center">
      <div className="w-12 h-12 rounded-xl bg-[#60A5FA]/10 border border-[#60A5FA]/20 flex items-center justify-center text-[#60A5FA] mb-4">
        <Icon className="w-6 h-6" />
      </div>
      <h3 className="text-base font-semibold text-[#F8FAFC]">{title}</h3>
      <p className="mt-1.5 text-sm text-[#CBD5E1] max-w-md leading-relaxed">{description}</p>
      {actionLabel && onAction && (
        <button
          type="button"
          onClick={onAction}
          className="mt-5 px-4 py-2 rounded-lg bg-[#60A5FA] text-[#0F172A] text-sm font-semibold hover:bg-[#93C5FD] transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
}

export function DashboardSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="h-28 rounded-xl bg-[#1E293B]/80 border border-slate-800" />
        ))}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="h-80 rounded-xl bg-[#1E293B]/80 border border-slate-800" />
        <div className="h-80 rounded-xl bg-[#1E293B]/80 border border-slate-800" />
      </div>
    </div>
  );
}
