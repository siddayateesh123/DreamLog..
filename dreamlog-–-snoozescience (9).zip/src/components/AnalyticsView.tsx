import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Info,
  Sliders,
  Sparkles,
  TrendingUp,
} from 'lucide-react';
import { api } from '../api/client.ts';
import { formatShortDate } from '../shared/math.ts';
import type { DashboardAnalytics, SimulationResult } from '../shared/types.ts';
import { SleepFocusScatterChart, SleepVsProductivityTrendChart } from './Charts.tsx';

export function AnalyticsView({
  analytics,
  daysWindow,
  onChangeDaysWindow,
}: {
  analytics: DashboardAnalytics;
  daysWindow: number;
  onChangeDaysWindow: (days: number) => void;
}) {
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [simEnabled, setSimEnabled] = useState(true);
  const [simSleepHours, setSimSleepHours] = useState(8.0);
  const [simNights, setSimNights] = useState(3);
  const [simulation, setSimulation] = useState<SimulationResult | null>(null);
  const [simLoading, setSimLoading] = useState(false);

  const { correlation, insights } = analytics;

  useEffect(() => {
    if (!simEnabled) {
      setSimulation(null);
      return;
    }
    let cancelled = false;
    setSimLoading(true);
    api
      .simulateSleepShift({
        sleepHours: simSleepHours,
        nights: simNights,
        daysWindow,
      })
      .then((res) => {
        if (!cancelled) setSimulation(res);
      })
      .catch(() => {
        if (!cancelled) setSimulation(null);
      })
      .finally(() => {
        if (!cancelled) setSimLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [simEnabled, simSleepHours, simNights, daysWindow, analytics.correlation.observationCount]);

  const selectedPoint = selectedDate
    ? correlation.points.find((p) => p.date === selectedDate) ?? null
    : correlation.points.find((p) => p.isLatest) ?? null;

  return (
    <div className="space-y-6">
      {/* Window Selector */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-[#F8FAFC]">
            Sleep-Productivity Correlation &amp; Regression Engine
          </h2>
          <p className="text-xs text-[#CBD5E1]">
            Pairs exact matching dates with sleep duration and hour-weighted study focus ratings
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-1 p-1 bg-[#111827] border border-slate-800 rounded-lg max-w-full">
          {[7, 14, 21, 30].map((d) => (
            <button
              key={d}
              type="button"
              onClick={() => onChangeDaysWindow(d)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA] ${
                daysWindow === d
                  ? 'bg-[#60A5FA] text-[#0F172A] font-semibold'
                  : 'text-[#CBD5E1] hover:text-[#F8FAFC]'
              }`}
            >
              Last {d} days
            </button>
          ))}
        </div>
      </div>

      {/* Statistical Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5">
          <span className="text-xs text-[#CBD5E1]">Pearson Correlation (r)</span>
          <div className="mt-2 font-mono text-2xl font-bold text-[#F8FAFC] tabular-nums">
            {correlation.hasConfidence && correlation.r !== null
              ? `${correlation.r >= 0 ? '+' : ''}${correlation.r.toFixed(2)}`
              : '—'}
          </div>
          <p className="mt-1 text-xs text-[#60A5FA]">
            {correlation.category} · n = {correlation.observationCount}
          </p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5">
          <span className="text-xs text-[#CBD5E1]">Paired Observations (n)</span>
          <div className="mt-2 font-mono text-2xl font-bold text-[#F8FAFC] tabular-nums">
            {correlation.observationCount}{' '}
            <span className="text-sm font-normal text-[#CBD5E1]">/ {correlation.requiredCount} min</span>
          </div>
          <p className="mt-1 text-xs text-[#CBD5E1]">
            {correlation.hasConfidence ? 'Statistical threshold met' : 'Building sample size'}
          </p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5">
          <span className="text-xs text-[#CBD5E1]">OLS Regression Line</span>
          <div className="mt-2 font-mono text-lg font-bold text-[#FBBF24] tabular-nums">
            {correlation.ols ? correlation.ols.equation : 'Unavailable'}
          </div>
          <p className="mt-1 text-xs text-[#CBD5E1]">
            {correlation.ols
              ? `Slope: ${correlation.ols.slope >= 0 ? '+' : ''}${correlation.ols.slope.toFixed(3)} focus / hr sleep`
              : 'Requires >= 7 paired days with variance'}
          </p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5">
          <span className="text-xs text-[#CBD5E1]">Sample Means (x̄, ȳ)</span>
          <div className="mt-2 font-mono text-lg font-bold text-[#34D399] tabular-nums">
            {correlation.meanSleep !== null && correlation.meanFocus !== null
              ? `${correlation.meanSleep.toFixed(2)}h · ${correlation.meanFocus.toFixed(2)}/5`
              : '—'}
          </div>
          <p className="mt-1 text-xs text-[#CBD5E1]">Mean sleep &amp; mean focus</p>
        </div>
      </div>

      {/* Confidence Warning if < 7 paired observations */}
      {!correlation.hasConfidence && (
        <div className="rounded-xl border border-[#F59E0B]/40 bg-[#F59E0B]/10 p-4 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-[#FBBF24] shrink-0 mt-0.5" />
          <div>
            <h3 className="text-sm font-semibold text-[#FDE68A]">
              {correlation.confidenceWarning}
            </h3>
            <p className="mt-1 text-xs text-[#CBD5E1] leading-relaxed">
              {correlation.explanation} DreamLog never invents placeholder correlation values when fewer than 7 paired dates exist.
            </p>
          </div>
        </div>
      )}

      {correlation.hasConfidence && (
        <div className="rounded-xl border border-slate-800 bg-[#111827] p-4 flex items-start gap-3">
          <Info className="w-5 h-5 text-[#60A5FA] shrink-0 mt-0.5" />
          <p className="text-xs sm:text-sm text-[#CBD5E1] leading-relaxed">
            <strong className="text-[#F8FAFC]">{correlation.category} (n = {correlation.observationCount}):</strong>{' '}
            {correlation.explanation}{' '}
            <span className="text-[#94A3B8]">
              Correlation measures linear association in your records and does not prove causation alone.
            </span>
          </p>
        </div>
      )}

      {/* Sleep Shift Simulator (Plan Step 10) */}
      <div className="rounded-xl border border-[#34D399]/35 bg-[#1E293B]/75 p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <Sliders className="w-5 h-5 text-[#34D399]" />
            <div>
              <h3 className="text-sm sm:text-base font-semibold text-[#F8FAFC]">
                Sleep Shift Simulator (What-If Projection)
              </h3>
              <p className="text-xs text-[#CBD5E1]">
                Project how logging upcoming nights of target sleep shifts your correlation curve without modifying saved logs.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setSimEnabled((v) => !v)}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#34D399] ${
              simEnabled
                ? 'bg-[#34D399]/20 border-[#34D399] text-[#34D399]'
                : 'bg-[#0F172A] border-slate-700 text-[#CBD5E1]'
            }`}
          >
            {simEnabled ? 'Projection Overlay: On' : 'Projection Overlay: Off'}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
          <div className="md:col-span-5 grid grid-cols-2 gap-4">
            <div>
              <div className="flex items-center justify-between text-xs text-[#CBD5E1] mb-1.5">
                <label htmlFor="sim-sleep-hours">Target Sleep (hrs)</label>
                <span className="font-mono font-semibold text-[#34D399] tabular-nums">
                  {simSleepHours.toFixed(1)}h
                </span>
              </div>
              <input
                id="sim-sleep-hours"
                type="range"
                min="4.5"
                max="10"
                step="0.5"
                value={simSleepHours}
                onChange={(e) => setSimSleepHours(Number(e.target.value))}
                disabled={!simEnabled}
                className="w-full accent-[#34D399]"
              />
            </div>

            <div>
              <div className="flex items-center justify-between text-xs text-[#CBD5E1] mb-1.5">
                <label htmlFor="sim-nights">Upcoming Nights</label>
                <span className="font-mono font-semibold text-[#60A5FA] tabular-nums">
                  {simNights}
                </span>
              </div>
              <input
                id="sim-nights"
                type="range"
                min="1"
                max="10"
                step="1"
                value={simNights}
                onChange={(e) => setSimNights(Number(e.target.value))}
                disabled={!simEnabled}
                className="w-full accent-[#60A5FA]"
              />
            </div>
          </div>

          <div className="md:col-span-7 rounded-lg bg-[#0F172A]/80 border border-slate-800 p-4 space-y-2">
            {simEnabled && simulation ? (
              <>
                <div className="flex flex-wrap items-center gap-6 text-xs font-mono tabular-nums">
                  <div>
                    <span className="text-[#CBD5E1]">r: </span>
                    <span className="text-[#FBBF24]">
                      {simulation.beforeR !== null
                        ? `${simulation.beforeR >= 0 ? '+' : ''}${simulation.beforeR.toFixed(2)}`
                        : 'Pending'}
                    </span>
                    <span className="text-[#CBD5E1] mx-1.5">-&gt;</span>
                    <span className="text-[#34D399] font-bold">
                      {simulation.afterR !== null
                        ? `${simulation.afterR >= 0 ? '+' : ''}${simulation.afterR.toFixed(2)}`
                        : 'Pending'}
                    </span>
                  </div>
                  <div>
                    <span className="text-[#CBD5E1]">slope: </span>
                    <span className="text-[#FBBF24]">
                      {simulation.beforeSlope !== null ? simulation.beforeSlope.toFixed(3) : '—'}
                    </span>
                    <span className="text-[#CBD5E1] mx-1.5">-&gt;</span>
                    <span className="text-[#34D399] font-bold">
                      {simulation.afterSlope !== null ? simulation.afterSlope.toFixed(3) : '—'}
                    </span>
                  </div>
                  {simLoading && <span className="text-[#94A3B8]">Recalculating...</span>}
                </div>
                <p className="text-xs text-[#CBD5E1] leading-relaxed">
                  {simulation.summarySentence}
                </p>
              </>
            ) : (
              <p className="text-xs text-[#CBD5E1]">
                Enable the projection overlay to preview how consistent nights shift your correlation curve.
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Scatter Plot + Dual-Axis Weekly Trend */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5">
          <div className="h-80">
            <SleepFocusScatterChart
              correlation={correlation}
              simulation={simEnabled ? simulation : null}
              selectedDate={selectedDate}
              onSelectDate={setSelectedDate}
            />
          </div>
          {selectedPoint && (
            <div className="mt-4 pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
              <span className="text-[#CBD5E1]">
                Selected Point:{' '}
                <strong className="text-[#F8FAFC]">{formatShortDate(selectedPoint.date)}</strong>
                {selectedPoint.isLatest && ' · Latest Added'}
              </span>
              <span className="font-mono text-[#FBBF24] tabular-nums">
                {selectedPoint.x.toFixed(2)}h sleep → {selectedPoint.y.toFixed(2)}/5 focus ({selectedPoint.studyHours}h · {selectedPoint.subjects.join(', ')})
              </span>
            </div>
          )}
        </div>

        <div className="lg:col-span-5 rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5 flex flex-col">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="w-4 h-4 text-[#60A5FA]" />
            <h3 className="text-sm font-semibold text-[#F8FAFC]">
              Sleep vs. Productivity Timeline
            </h3>
          </div>
          <p className="text-xs text-[#CBD5E1] mb-3">
            Tracks how nightly sleep duration and next-day focus move together across the window.
          </p>
          <div className="h-72 flex-1">
            <SleepVsProductivityTrendChart series={analytics.dailySeries} />
          </div>
        </div>
      </div>

      {/* Personalized Weekly Optimization Insights */}
      <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-6 space-y-5">
        <div className="flex items-center gap-2.5">
          <Sparkles className="w-5 h-5 text-[#FBBF24]" />
          <h3 className="text-base font-semibold text-[#F8FAFC]">
            Weekly Optimization Insights
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-3">
            <h4 className="text-xs font-semibold text-[#34D399]">Sleep Optimization</h4>
            {insights.sleepRecommendations.map((rec, i) => (
              <div key={i} className="flex items-start gap-2.5 text-sm text-[#CBD5E1]">
                <CheckCircle2 className="w-4 h-4 text-[#34D399] shrink-0 mt-0.5" />
                <span>{rec}</span>
              </div>
            ))}
          </div>
          <div className="space-y-3">
            <h4 className="text-xs font-semibold text-[#60A5FA]">Study Productivity</h4>
            {insights.studyRecommendations.map((rec, i) => (
              <div key={i} className="flex items-start gap-2.5 text-sm text-[#CBD5E1]">
                <CheckCircle2 className="w-4 h-4 text-[#60A5FA] shrink-0 mt-0.5" />
                <span>{rec}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
