import React, { useRef, useState } from 'react';
import type { Chart as ChartJS } from 'chart.js';
import {
  Activity,
  AlertCircle,
  ArrowUpRight,
  BatteryCharging,
  BookOpen,
  Clock,
  Info,
  Moon,
  Play,
  Plus,
  RotateCcw,
  Sparkles,
  Target,
  TrendingUp,
  X,
} from 'lucide-react';
import { formatHoursMinutes, formatShortDate, formatTime12h } from '../shared/math.ts';
import type { DashboardAnalytics, UserSettings } from '../shared/types.ts';
import {
  FocusTrendChart,
  SleepDurationChart,
  SleepFocusScatterChart,
  StudyHoursChart,
} from './Charts.tsx';
import { AnimatedNumber, DashboardSkeleton, EmptyState } from './ui.tsx';

export type NavSection =
  | 'dashboard'
  | 'sleep'
  | 'study'
  | 'analytics'
  | 'sleep-debt'
  | 'bedtime'
  | 'caffeine'
  | 'exams'
  | 'reports'
  | 'settings'
  | 'verify';

export function DashboardView({
  analytics,
  settings,
  loading,
  daysWindow,
  onChangeDaysWindow,
  onNavigate,
  onDismissOnboarding,
  onOpenQuickSleep,
  onOpenQuickStudy,
  onRunDemoScenario,
  onResetDemoScenario,
  runningDemo,
}: {
  analytics: DashboardAnalytics | null;
  settings: UserSettings;
  loading: boolean;
  daysWindow: number;
  onChangeDaysWindow: (days: number) => void;
  onNavigate: (tab: NavSection) => void;
  onDismissOnboarding: () => void;
  onOpenQuickSleep: () => void;
  onOpenQuickStudy: () => void;
  onRunDemoScenario: () => void;
  onResetDemoScenario: () => void;
  runningDemo: boolean;
}) {
  const scatterRef = useRef<ChartJS<'scatter'> | null>(null);
  const [selectedScatterDate, setSelectedScatterDate] = useState<string | null>(null);

  if (loading && !analytics) {
    return <DashboardSkeleton />;
  }

  if (!analytics) {
    return (
      <EmptyState
        icon={Moon}
        title="Unable to load analytics"
        description="Check your server connection or refresh to reload your DreamLog metrics."
      />
    );
  }

  const hasAnyData = analytics.totalSleepLogs > 0 || analytics.totalStudyLogs > 0;
  const selectedPoint = selectedScatterDate
    ? analytics.correlation.points.find((p) => p.date === selectedScatterDate) ?? null
    : analytics.correlation.points.find((p) => p.isLatest) ?? null;

  const consistencyColor =
    analytics.consistencyStatus === 'Consistent'
      ? 'text-[#34D399]'
      : analytics.consistencyStatus === 'Moderate Variance'
        ? 'text-[#F59E0B]'
        : analytics.consistencyStatus === 'Inconsistent'
          ? 'text-[#F87171]'
          : 'text-[#CBD5E1]';

  return (
    <div className="space-y-6">
      {/* Onboarding Guide Banner */}
      {!settings.onboardingDismissed && (
        <div className="rounded-xl border border-[#60A5FA]/30 bg-[#1E293B]/80 p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="p-2.5 rounded-lg bg-[#60A5FA]/15 text-[#60A5FA] shrink-0">
              <Info className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-[#F8FAFC]">
                Quick Onboarding: How to test your Sleep-Productivity Correlation
              </h3>
              <p className="mt-1 text-xs sm:text-sm text-[#CBD5E1] leading-relaxed">
                Click <strong>Run Demo Scenario</strong> to log today&apos;s 11:30 PM → 7:30 AM (8.0h, 4 stars) sleep and 4.5h Algorithms (&quot;5/5 - Deep Focus&quot;) via the REST API, or log your own sleep and study entries manually.
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={onRunDemoScenario}
              disabled={runningDemo}
              className="px-3.5 py-2 rounded-lg bg-[#FBBF24] text-[#0F172A] text-xs font-semibold hover:bg-[#FDE68A] disabled:opacity-50 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#FBBF24]"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{runningDemo ? 'Running...' : 'Run Demo Scenario'}</span>
            </button>
            <button
              type="button"
              onClick={onOpenQuickSleep}
              className="px-3.5 py-2 rounded-lg bg-[#60A5FA] text-[#0F172A] text-xs font-semibold hover:bg-[#93C5FD] transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
            >
              Log Sleep
            </button>
            <button
              type="button"
              onClick={onDismissOnboarding}
              className="p-2 text-[#CBD5E1] hover:text-[#F8FAFC] rounded-lg hover:bg-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
              aria-label="Dismiss onboarding guide"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Toolbar: Date Range Filter & Demo Scenario / Quick Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-[#111827] border border-slate-800 rounded-lg w-fit max-w-full">
          {[7, 14, 21, 30].map((d) => (
            <button
              key={d}
              type="button"
              onClick={() => onChangeDaysWindow(d)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA] ${
                daysWindow === d
                  ? 'bg-[#60A5FA] text-[#0F172A] font-semibold'
                  : 'text-[#CBD5E1] hover:text-[#F8FAFC]'
              }`}
            >
              Last {d} days
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={onRunDemoScenario}
            disabled={runningDemo}
            className="px-3.5 py-2 rounded-lg border border-[#FBBF24]/50 bg-[#FBBF24]/15 text-xs font-semibold text-[#FDE68A] hover:bg-[#FBBF24]/25 disabled:opacity-50 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#FBBF24]"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>
              {runningDemo
                ? 'Running...'
                : analytics.demoScenarioApplied
                  ? 'Re-run Demo Scenario'
                  : 'Run Demo Scenario'}
            </span>
          </button>
          {analytics.demoScenarioApplied && (
            <button
              type="button"
              onClick={onResetDemoScenario}
              className="px-3 py-2 rounded-lg border border-slate-700 bg-[#1E293B] text-xs font-medium text-[#CBD5E1] hover:text-[#F8FAFC] transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset demo</span>
            </button>
          )}
          <button
            type="button"
            onClick={onOpenQuickSleep}
            className="px-3.5 py-2 rounded-lg bg-[#1E293B] border border-slate-700 text-xs font-medium text-[#F8FAFC] hover:border-[#60A5FA]/60 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
          >
            <Plus className="w-3.5 h-3.5 text-[#60A5FA]" />
            <span>Log Sleep</span>
          </button>
          <button
            type="button"
            onClick={onOpenQuickStudy}
            className="px-3.5 py-2 rounded-lg bg-[#60A5FA] text-xs font-semibold text-[#0F172A] hover:bg-[#93C5FD] transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Log Study Session</span>
          </button>
        </div>
      </div>

      {/* 7 KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-[#CBD5E1]">Last Night&apos;s Sleep</span>
            <Moon className="w-4 h-4 text-[#60A5FA]" />
          </div>
          <div className="mt-2.5 text-2xl font-bold font-mono tabular-nums text-[#F8FAFC]">
            {analytics.lastNightSleep.duration !== null ? (
              <AnimatedNumber value={analytics.lastNightSleep.duration} decimals={2} suffix="h" />
            ) : (
              '—'
            )}
          </div>
          <p className="mt-1.5 text-xs text-[#CBD5E1] truncate">
            {analytics.lastNightSleep.date
              ? `${formatShortDate(analytics.lastNightSleep.date)} · ${formatTime12h(analytics.lastNightSleep.bedtime)} – ${formatTime12h(analytics.lastNightSleep.wakeTime)}`
              : 'No sleep logged yet'}
          </p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-[#CBD5E1]">Avg Weekly Sleep</span>
            <Clock className="w-4 h-4 text-[#60A5FA]" />
          </div>
          <div className="mt-2.5 text-2xl font-bold font-mono tabular-nums text-[#F8FAFC]">
            <AnimatedNumber value={analytics.averageWeeklySleep} decimals={2} suffix="h" />
          </div>
          <p className="mt-1.5 text-xs text-[#CBD5E1]">
            {formatHoursMinutes(analytics.averageWeeklySleep)} · Baseline {settings.sleepBaselineHours}h
          </p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-[#CBD5E1]">Study Hours (7d)</span>
            <BookOpen className="w-4 h-4 text-[#FBBF24]" />
          </div>
          <div className="mt-2.5 text-2xl font-bold font-mono tabular-nums text-[#F8FAFC]">
            <AnimatedNumber value={analytics.totalStudyHoursThisWeek} decimals={1} suffix="h" />
          </div>
          <p className="mt-1.5 text-xs text-[#CBD5E1]">
            Across {analytics.subjectStats.length} active subject{analytics.subjectStats.length === 1 ? '' : 's'}
          </p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-[#CBD5E1]">Avg Focus Rating</span>
            <Target className="w-4 h-4 text-[#FBBF24]" />
          </div>
          <div className="mt-2.5 text-2xl font-bold font-mono tabular-nums text-[#F8FAFC]">
            <AnimatedNumber value={analytics.averageFocusRating} decimals={2} suffix="/5" />
          </div>
          <p className="mt-1.5 text-xs text-[#CBD5E1]">
            {analytics.averageFocusRating >= 4
              ? 'Good to Deep Focus'
              : analytics.averageFocusRating >= 3
                ? 'Moderate Focus'
                : analytics.averageFocusRating > 0
                  ? 'Low Focus Window'
                  : 'No study sessions'}
          </p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-[#CBD5E1]">Weekly Sleep Debt</span>
            <BatteryCharging
              className={`w-4 h-4 ${analytics.weeklySleepDebt >= 5 ? 'text-[#F87171]' : 'text-[#34D399]'}`}
            />
          </div>
          <div
            className={`mt-2.5 text-2xl font-bold font-mono tabular-nums ${
              analytics.weeklySleepDebt >= 5 ? 'text-[#F87171]' : 'text-[#F8FAFC]'
            }`}
          >
            <AnimatedNumber value={analytics.weeklySleepDebt} decimals={1} suffix="h" />
          </div>
          <p className="mt-1.5 text-xs text-[#CBD5E1]">
            Goal completion {analytics.sleepDebt.goalCompletionPercent}%
          </p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5 sm:col-span-2 lg:col-span-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-[#CBD5E1]">
              Sleep-Productivity Correlation (Pearson r)
            </span>
            <TrendingUp className="w-4 h-4 text-[#34D399]" />
          </div>
          <div className="mt-2 flex flex-wrap items-baseline gap-3">
            <span className="text-2xl font-bold font-mono tabular-nums text-[#F8FAFC]">
              {analytics.correlation.hasConfidence && analytics.correlation.r !== null ? (
                <>
                  r = {analytics.correlation.r >= 0 ? '+' : ''}
                  {analytics.correlation.r.toFixed(2)}
                </>
              ) : (
                'Pending'
              )}
            </span>
            <span className="text-xs font-medium text-[#60A5FA]">
              {analytics.correlation.category} · n = {analytics.correlation.observationCount} paired days
            </span>
          </div>
          <p className="mt-1.5 text-xs text-[#CBD5E1] truncate">
            {analytics.correlation.confidenceWarning || analytics.correlation.explanation}
          </p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-[#CBD5E1]">Sleep Consistency</span>
            <Activity className="w-4 h-4 text-[#60A5FA]" />
          </div>
          <div className={`mt-2.5 text-xl font-bold font-display ${consistencyColor}`}>
            {analytics.consistencyStatus}
          </div>
          <p className="mt-1.5 text-xs text-[#CBD5E1]">
            ±{analytics.sleepDebt.sleepStdDevHours.toFixed(2)}h duration variance
          </p>
        </div>
      </div>

      {!hasAnyData ? (
        <EmptyState
          icon={Moon}
          title="Your DreamLog workspace is empty"
          description="Log your first night of sleep and study session to populate live charts, Sleep Debt tracking, and Sleep-Productivity Correlation insights."
          actionLabel="Log First Night of Sleep"
          onAction={onOpenQuickSleep}
        />
      ) : (
        <>
          {/* Primary Charts Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Scatter Plot Card */}
            <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5 flex flex-col">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                <div>
                  <span className="text-xs text-[#CBD5E1]">
                    Pearson r:{' '}
                    <strong className="font-mono text-[#F8FAFC]">
                      {analytics.correlation.hasConfidence && analytics.correlation.r !== null
                        ? `${analytics.correlation.r >= 0 ? '+' : ''}${analytics.correlation.r.toFixed(2)}`
                        : 'Pending'}
                    </strong>
                    {' '}
                    <span className="font-mono text-[#94A3B8]">
                      (n = {analytics.correlation.observationCount})
                    </span>
                    {analytics.correlation.ols && (
                      <>
                        {' · '}OLS:{' '}
                        <strong className="font-mono text-[#FBBF24]">
                          {analytics.correlation.ols.equation}
                        </strong>
                      </>
                    )}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => onNavigate('analytics')}
                  className="text-xs text-[#60A5FA] hover:underline inline-flex items-center gap-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA] rounded"
                >
                  <span>Sleep Shift Simulator</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {!analytics.correlation.hasConfidence && (
                <div className="mb-3 rounded-lg border border-[#F59E0B]/30 bg-[#F59E0B]/10 px-3 py-2 flex items-center gap-2 text-xs text-[#FDE68A]">
                  <AlertCircle className="w-4 h-4 shrink-0 text-[#FBBF24]" />
                  <span>{analytics.correlation.confidenceWarning}</span>
                </div>
              )}

              <div className="h-72">
                <SleepFocusScatterChart
                  correlation={analytics.correlation}
                  selectedDate={selectedScatterDate}
                  onSelectDate={setSelectedScatterDate}
                  chartRef={scatterRef}
                />
              </div>

              {selectedPoint && (
                <div className="mt-3 pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs text-[#CBD5E1]">
                  <span>
                    Highlighted:{' '}
                    <strong className="text-[#F8FAFC]">{formatShortDate(selectedPoint.date)}</strong>
                    {selectedPoint.isLatest && ' (Latest Entry)'}
                  </span>
                  <span className="font-mono tabular-nums text-[#FBBF24]">
                    {selectedPoint.x.toFixed(2)}h sleep · {selectedPoint.y.toFixed(2)}/5 focus ·{' '}
                    {selectedPoint.subjects.join(', ')}
                  </span>
                </div>
              )}
            </div>

            {/* Sleep Duration Chart */}
            <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5 flex flex-col">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h3 className="text-sm font-semibold text-[#F8FAFC]">Nightly Sleep Duration</h3>
                  <p className="text-xs text-[#CBD5E1]">
                    Compared against your {settings.sleepBaselineHours}h tracking baseline
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => onNavigate('sleep')}
                  className="text-xs text-[#60A5FA] hover:underline inline-flex items-center gap-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA] rounded"
                >
                  <span>Sleep Logs</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="h-72">
                <SleepDurationChart
                  series={analytics.dailySeries}
                  baseline={settings.sleepBaselineHours}
                />
              </div>
            </div>

            {/* Study Hours Chart */}
            <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5 flex flex-col">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h3 className="text-sm font-semibold text-[#F8FAFC]">Daily Study Hours</h3>
                  <p className="text-xs text-[#CBD5E1]">Total academic hours logged per day</p>
                </div>
                <button
                  type="button"
                  onClick={() => onNavigate('study')}
                  className="text-xs text-[#60A5FA] hover:underline inline-flex items-center gap-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA] rounded"
                >
                  <span>Study Logs</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="h-64">
                <StudyHoursChart series={analytics.dailySeries} />
              </div>
            </div>

            {/* Focus Rating Trend */}
            <div className="rounded-xl border border-slate-800 bg-[#1E293B]/75 p-5 flex flex-col">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h3 className="text-sm font-semibold text-[#F8FAFC]">Study Focus Rating Trend</h3>
                  <p className="text-xs text-[#CBD5E1]">Hour-weighted daily focus (1–5 scale)</p>
                </div>
              </div>
              <div className="h-64">
                <FocusTrendChart series={analytics.dailySeries} />
              </div>
            </div>
          </div>

          {/* Summary, Insights & Recent Activity */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-7 rounded-xl border border-slate-800 bg-[#1E293B]/75 p-6 space-y-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Sparkles className="w-4 h-4 text-[#FBBF24]" />
                  <h3 className="text-base font-semibold text-[#F8FAFC]">
                    Weekly Optimization Insights
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => onNavigate('reports')}
                  className="text-xs text-[#60A5FA] hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA] rounded"
                >
                  Export PDF Report
                </button>
              </div>

              <p className="text-sm text-[#CBD5E1] leading-relaxed bg-[#0F172A]/60 border border-slate-800 rounded-lg p-4">
                {analytics.insights.weeklySummary}
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <h4 className="text-xs font-semibold text-[#34D399] mb-2.5">
                    Positive Findings
                  </h4>
                  <ul className="space-y-2 text-xs text-[#CBD5E1] leading-relaxed">
                    {analytics.insights.positiveInsights.map((item, idx) => (
                      <li key={idx} className="pb-2 border-b border-slate-800/70 last:border-b-0">
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="text-xs font-semibold text-[#F59E0B] mb-2.5">
                    Areas to Optimize
                  </h4>
                  <ul className="space-y-2 text-xs text-[#CBD5E1] leading-relaxed">
                    {analytics.insights.improvementAreas.map((item, idx) => (
                      <li key={idx} className="pb-2 border-b border-slate-800/70 last:border-b-0">
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="lg:col-span-5 rounded-xl border border-slate-800 bg-[#1E293B]/75 p-6 flex flex-col">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-base font-semibold text-[#F8FAFC]">Recent Activity</h3>
                <span className="text-xs text-[#CBD5E1]">Latest 10 records</span>
              </div>

              <div className="divide-y divide-slate-800/80 flex-1 overflow-y-auto max-h-80">
                {analytics.recentActivity.map((act) => (
                  <div key={act.id} className="py-3 flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 text-xs">
                        <span className="font-medium text-[#F8FAFC] truncate">{act.title}</span>
                        {act.isDemo && (
                          <span className="text-[11px] text-[#CBD5E1]">· Demo</span>
                        )}
                      </div>
                      <p className="mt-0.5 text-xs text-[#CBD5E1] truncate">{act.detail}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="text-xs font-mono font-semibold text-[#60A5FA] tabular-nums">
                        {act.metric}
                      </div>
                      <div className="text-[11px] text-[#CBD5E1] mt-0.5">
                        {formatShortDate(act.date)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
