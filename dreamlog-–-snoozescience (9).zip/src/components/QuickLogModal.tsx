import React, { useMemo, useState } from 'react';
import { BookOpen, Clock, Moon, X } from 'lucide-react';
import { api } from '../api/client.ts';
import {
  calculateSleepDuration,
  formatHoursMinutes,
  getLocalDateStr,
} from '../shared/math.ts';
import { FOCUS_DESCRIPTIONS } from '../shared/types.ts';
import { StarRatingInput } from './ui.tsx';

export function QuickLogModal({
  mode,
  onClose,
  onSaved,
  onNotify,
}: {
  mode: 'sleep' | 'study' | null;
  onClose: () => void;
  onSaved: () => Promise<void>;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}) {
  const [date, setDate] = useState(getLocalDateStr(0));
  const [bedtime, setBedtime] = useState('23:30');
  const [wakeTime, setWakeTime] = useState('07:30');
  const [sleepQuality, setSleepQuality] = useState(4);

  const [subject, setSubject] = useState('Algorithms');
  const [studyHours, setStudyHours] = useState('4.5');
  const [focusRating, setFocusRating] = useState(5);
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  const duration = useMemo(() => calculateSleepDuration(bedtime, wakeTime), [bedtime, wakeTime]);

  if (!mode) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (mode === 'sleep') {
        if (duration < 0.25 || duration > 20) {
          onNotify('error', 'Sleep duration must be between 15 minutes and 20 hours.');
          setSaving(false);
          return;
        }
        await api.createSleepLog({ date, bedtime, wakeTime, sleepQuality, notes });
        onNotify('success', `Saved ${formatHoursMinutes(duration)} sleep log. Analytics updated.`);
      } else {
        const hrs = Number(studyHours);
        if (!subject.trim() || Number.isNaN(hrs) || hrs < 0.25 || hrs > 16) {
          onNotify('error', 'Provide a subject and study duration between 0.25 and 16 hours.');
          setSaving(false);
          return;
        }
        await api.createStudyLog({
          date,
          subject: subject.trim(),
          studyHours: hrs,
          focusRating,
          notes,
        });
        onNotify('success', `Saved ${hrs}h ${subject.trim()} (${focusRating}/5 focus). Scatter plot updated.`);
      }
      await onSaved();
      onClose();
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'Failed to save log.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-md rounded-2xl bg-[#1E293B] border border-slate-700 p-6 shadow-2xl">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2.5">
            {mode === 'sleep' ? (
              <Moon className="w-5 h-5 text-[#60A5FA]" />
            ) : (
              <BookOpen className="w-5 h-5 text-[#FBBF24]" />
            )}
            <h3 className="text-base font-semibold text-[#F8FAFC]">
              {mode === 'sleep' ? 'Quick Log: Nightly Sleep' : 'Quick Log: Study Session'}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#CBD5E1] hover:text-[#F8FAFC] hover:bg-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="quick-date" className="block text-xs font-medium text-[#CBD5E1] mb-1">Date</label>
            <input
              id="quick-date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              required
              className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-sm text-[#F8FAFC] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
            />
          </div>

          {mode === 'sleep' ? (
            <>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="quick-bedtime" className="block text-xs font-medium text-[#CBD5E1] mb-1">Bedtime</label>
                  <input
                    id="quick-bedtime"
                    type="time"
                    value={bedtime}
                    onChange={(e) => setBedtime(e.target.value)}
                    required
                    className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-sm font-mono text-[#F8FAFC] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
                  />
                </div>
                <div>
                  <label htmlFor="quick-waketime" className="block text-xs font-medium text-[#CBD5E1] mb-1">Wake-up</label>
                  <input
                    id="quick-waketime"
                    type="time"
                    value={wakeTime}
                    onChange={(e) => setWakeTime(e.target.value)}
                    required
                    className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-sm font-mono text-[#F8FAFC] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
                  />
                </div>
              </div>
              <div className="rounded-lg bg-[#0F172A] border border-slate-800 px-3.5 py-2.5 flex items-center justify-between text-xs">
                <span className="text-[#CBD5E1] flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-[#60A5FA]" />
                  Calculated Duration
                </span>
                <span className="font-mono font-bold text-[#60A5FA] tabular-nums">
                  {duration > 0 ? formatHoursMinutes(duration) : 'Invalid'}
                </span>
              </div>
              <div>
                <span className="block text-xs font-medium text-[#CBD5E1] mb-1">Sleep Quality</span>
                <StarRatingInput value={sleepQuality} onChange={setSleepQuality} />
              </div>
            </>
          ) : (
            <>
              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2">
                  <label htmlFor="quick-subject" className="block text-xs font-medium text-[#CBD5E1] mb-1">Subject</label>
                  <input
                    id="quick-subject"
                    type="text"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    required
                    className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-sm text-[#F8FAFC] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
                  />
                </div>
                <div>
                  <label htmlFor="quick-hours" className="block text-xs font-medium text-[#CBD5E1] mb-1">Hours</label>
                  <input
                    id="quick-hours"
                    type="number"
                    step="0.25"
                    min="0.25"
                    max="16"
                    value={studyHours}
                    onChange={(e) => setStudyHours(e.target.value)}
                    required
                    className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-sm font-mono text-[#F8FAFC] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
                  />
                </div>
              </div>
              <div>
                <span className="block text-xs font-medium text-[#CBD5E1] mb-1.5">
                  Focus: <strong className="text-[#FBBF24]">{focusRating}/5 – {FOCUS_DESCRIPTIONS[focusRating]}</strong>
                </span>
                <div className="grid grid-cols-5 gap-1.5">
                  {[1, 2, 3, 4, 5].map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setFocusRating(r)}
                      className={`py-2 rounded-lg text-xs font-mono font-semibold border focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA] ${
                        focusRating === r
                          ? 'bg-[#FBBF24] text-[#0F172A] border-[#FBBF24]'
                          : 'bg-[#0F172A] text-[#CBD5E1] border-slate-800'
                      }`}
                    >
                      {r}
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}

          <div>
            <label htmlFor="quick-notes" className="block text-xs font-medium text-[#CBD5E1] mb-1">Notes (optional)</label>
            <input
              id="quick-notes"
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Optional context..."
              className="w-full rounded-lg bg-[#0F172A] border border-slate-700 px-3 py-2 text-sm text-[#F8FAFC] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-slate-700 text-xs font-medium text-[#CBD5E1] hover:text-[#F8FAFC] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 rounded-lg bg-[#60A5FA] text-[#0F172A] text-xs font-semibold hover:bg-[#93C5FD] disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
            >
              {saving ? 'Saving...' : 'Save & Recalculate'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
