import React, { useMemo } from 'react';
import {
  BarElement,
  CategoryScale,
  Chart as ChartJS,
  Filler,
  Legend,
  LinearScale,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  type ChartData,
  type ChartOptions,
} from 'chart.js';
import { Bar, Line, Scatter } from 'react-chartjs-2';
import { formatShortDate } from '../shared/math.ts';
import type {
  CorrelationAnalysis,
  DailyMetricPoint,
  SimulationResult,
  SleepDebtSummary,
} from '../shared/types.ts';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler,
);

const GRID_COLOR = 'rgba(148, 163, 184, 0.12)';
const TICK_COLOR = '#CBD5E1';

export function SleepDurationChart({
  series,
  baseline = 8,
}: {
  series: DailyMetricPoint[];
  baseline?: number;
}) {
  const sleepDays = series.filter((d) => d.totalSleep > 0);

  const data: ChartData<'bar' | 'line'> = useMemo(
    () => ({
      labels: sleepDays.map((d) => formatShortDate(d.date)),
      datasets: [
        {
          type: 'bar' as const,
          label: 'Sleep Duration (h)',
          data: sleepDays.map((d) => d.totalSleep),
          backgroundColor: sleepDays.map((d) =>
            d.latestUpdated
              ? 'rgba(251, 191, 36, 0.85)'
              : d.totalSleep >= baseline
                ? 'rgba(52, 211, 153, 0.72)'
                : d.totalSleep >= 6.5
                  ? 'rgba(96, 165, 250, 0.72)'
                  : 'rgba(248, 113, 113, 0.72)',
          ),
          borderRadius: 6,
          borderSkipped: false,
        },
        {
          type: 'line' as const,
          label: `${baseline}h Baseline`,
          data: sleepDays.map(() => baseline),
          borderColor: 'rgba(248, 250, 252, 0.4)',
          borderDash: [5, 5],
          borderWidth: 1.5,
          pointRadius: 0,
          fill: false,
        },
      ],
    }),
    [sleepDays, baseline],
  );

  const options: ChartOptions<'bar'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        labels: { color: TICK_COLOR, boxWidth: 12, font: { family: 'DM Sans', size: 11 } },
      },
      tooltip: {
        backgroundColor: '#0F172A',
        borderColor: 'rgba(148, 163, 184, 0.25)',
        borderWidth: 1,
        titleColor: '#F8FAFC',
        bodyColor: '#CBD5E1',
      },
    },
    scales: {
      x: { grid: { display: false }, ticks: { color: TICK_COLOR, maxRotation: 0, autoSkip: true } },
      y: {
        min: 0,
        max: 11,
        grid: { color: GRID_COLOR },
        ticks: { color: TICK_COLOR, callback: (v) => `${v}h` },
      },
    },
  };

  return (
    <div
      className="w-full h-full relative"
      role="region"
      aria-label={`Nightly sleep duration bar chart against ${baseline}-hour baseline`}
    >
      <Bar data={data as ChartData<'bar'>} options={options} />
      <table className="sr-only">
        <caption>Nightly sleep duration table</caption>
        <thead>
          <tr>
            <th>Date</th>
            <th>Sleep Hours</th>
          </tr>
        </thead>
        <tbody>
          {sleepDays.map((d) => (
            <tr key={d.date}>
              <td>{d.date}</td>
              <td>{d.totalSleep}h</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function StudyHoursChart({ series }: { series: DailyMetricPoint[] }) {
  const studyDays = series.filter((d) => d.totalStudyHours > 0);

  const data: ChartData<'bar'> = useMemo(
    () => ({
      labels: studyDays.map((d) => formatShortDate(d.date)),
      datasets: [
        {
          label: 'Study Hours',
          data: studyDays.map((d) => d.totalStudyHours),
          backgroundColor: studyDays.map((d) =>
            d.latestUpdated ? 'rgba(251, 191, 36, 0.85)' : 'rgba(96, 165, 250, 0.72)',
          ),
          borderRadius: 6,
        },
      ],
    }),
    [studyDays],
  );

  const options: ChartOptions<'bar'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#0F172A',
        borderColor: 'rgba(148, 163, 184, 0.25)',
        borderWidth: 1,
      },
    },
    scales: {
      x: { grid: { display: false }, ticks: { color: TICK_COLOR, maxRotation: 0, autoSkip: true } },
      y: {
        min: 0,
        suggestedMax: 9,
        grid: { color: GRID_COLOR },
        ticks: { color: TICK_COLOR, callback: (v) => `${v}h` },
      },
    },
  };

  return (
    <div className="w-full h-full relative" role="region" aria-label="Daily study hours bar chart">
      <Bar data={data} options={options} />
      <table className="sr-only">
        <caption>Daily study hours table</caption>
        <thead>
          <tr>
            <th>Date</th>
            <th>Study Hours</th>
          </tr>
        </thead>
        <tbody>
          {studyDays.map((d) => (
            <tr key={d.date}>
              <td>{d.date}</td>
              <td>{d.totalStudyHours}h</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function FocusTrendChart({ series }: { series: DailyMetricPoint[] }) {
  const focusDays = series.filter((d) => d.averageFocus !== null);

  const data: ChartData<'line'> = useMemo(
    () => ({
      labels: focusDays.map((d) => formatShortDate(d.date)),
      datasets: [
        {
          label: 'Daily Weighted Focus (1–5)',
          data: focusDays.map((d) => d.averageFocus as number),
          borderColor: '#FBBF24',
          backgroundColor: 'rgba(251, 191, 36, 0.14)',
          fill: true,
          tension: 0.32,
          pointBackgroundColor: focusDays.map((d) => (d.latestUpdated ? '#34D399' : '#FBBF24')),
          pointRadius: focusDays.map((d) => (d.latestUpdated ? 6 : 3.5)),
          pointHoverRadius: 7,
        },
      ],
    }),
    [focusDays],
  );

  const options: ChartOptions<'line'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#0F172A',
        borderColor: 'rgba(148, 163, 184, 0.25)',
        borderWidth: 1,
      },
    },
    scales: {
      x: { grid: { display: false }, ticks: { color: TICK_COLOR, maxRotation: 0, autoSkip: true } },
      y: {
        min: 1,
        max: 5.2,
        grid: { color: GRID_COLOR },
        ticks: { color: TICK_COLOR, stepSize: 1 },
      },
    },
  };

  return (
    <div className="w-full h-full relative" role="region" aria-label="Study focus rating trend chart">
      <Line data={data} options={options} />
      <table className="sr-only">
        <caption>Study focus rating trend table</caption>
        <thead>
          <tr>
            <th>Date</th>
            <th>Focus Rating</th>
          </tr>
        </thead>
        <tbody>
          {focusDays.map((d) => (
            <tr key={d.date}>
              <td>{d.date}</td>
              <td>{d.averageFocus}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function SleepVsProductivityTrendChart({ series }: { series: DailyMetricPoint[] }) {
  const validDays = series.filter((d) => d.totalSleep > 0 || d.averageFocus !== null);

  const data: ChartData<'line'> = useMemo(
    () => ({
      labels: validDays.map((d) => formatShortDate(d.date)),
      datasets: [
        {
          label: 'Sleep Duration (h)',
          data: validDays.map((d) => (d.totalSleep > 0 ? d.totalSleep : null)),
          borderColor: '#60A5FA',
          backgroundColor: 'rgba(96, 165, 250, 0.12)',
          yAxisID: 'y',
          tension: 0.3,
          spanGaps: true,
          pointRadius: 3.5,
        },
        {
          label: 'Focus Rating (1–5)',
          data: validDays.map((d) => d.averageFocus),
          borderColor: '#FBBF24',
          backgroundColor: 'rgba(251, 191, 36, 0.1)',
          yAxisID: 'y1',
          tension: 0.3,
          spanGaps: true,
          pointRadius: 3.5,
        },
      ],
    }),
    [validDays],
  );

  const options: ChartOptions<'line'> = {
    responsive: true,
    maintainAspectRatio: false,
    interaction: { mode: 'index', intersect: false },
    plugins: {
      legend: {
        labels: { color: TICK_COLOR, boxWidth: 12, font: { family: 'DM Sans', size: 11 } },
      },
      tooltip: {
        backgroundColor: '#0F172A',
        borderColor: 'rgba(148, 163, 184, 0.25)',
        borderWidth: 1,
      },
    },
    scales: {
      x: { grid: { display: false }, ticks: { color: TICK_COLOR, maxRotation: 0, autoSkip: true } },
      y: {
        type: 'linear',
        position: 'left',
        min: 3,
        max: 10.5,
        grid: { color: GRID_COLOR },
        ticks: { color: '#60A5FA', callback: (v) => `${v}h` },
      },
      y1: {
        type: 'linear',
        position: 'right',
        min: 1,
        max: 5.2,
        grid: { drawOnChartArea: false },
        ticks: { color: '#FBBF24', stepSize: 1 },
      },
    },
  };

  return (
    <div
      className="w-full h-full relative"
      role="region"
      aria-label="Weekly sleep duration versus study focus timeline chart"
    >
      <Line data={data} options={options} />
      <table className="sr-only">
        <caption>Sleep duration and focus rating timeline</caption>
        <thead>
          <tr>
            <th>Date</th>
            <th>Sleep Hours</th>
            <th>Focus</th>
          </tr>
        </thead>
        <tbody>
          {validDays.map((d) => (
            <tr key={d.date}>
              <td>{d.date}</td>
              <td>{d.totalSleep}h</td>
              <td>{d.averageFocus ?? '—'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function SleepFocusScatterChart({
  correlation,
  simulation = null,
  selectedDate,
  onSelectDate,
  chartRef,
}: {
  correlation: CorrelationAnalysis;
  simulation?: SimulationResult | null;
  selectedDate?: string | null;
  onSelectDate?: (date: string) => void;
  chartRef?: React.RefObject<ChartJS<'scatter'> | null>;
}) {
  const highPoints = correlation.points.filter(
    (p) => p.y >= 4 && !p.isLatest && p.date !== selectedDate,
  );
  const midPoints = correlation.points.filter(
    (p) => p.y >= 2.5 && p.y < 4 && !p.isLatest && p.date !== selectedDate,
  );
  const lowPoints = correlation.points.filter(
    (p) => p.y < 2.5 && !p.isLatest && p.date !== selectedDate,
  );
  const highlightPoints = correlation.points.filter(
    (p) => p.isLatest || p.date === selectedDate,
  );

  const data = useMemo(() => {
    const datasets: ChartData<'scatter'>['datasets'] = [
      {
        label: 'High Focus (4–5)',
        data: highPoints.map((p) => ({ x: p.x, y: p.y })),
        backgroundColor: 'rgba(52, 211, 153, 0.85)',
        borderColor: '#34D399',
        pointStyle: 'circle',
        pointRadius: 6,
        pointHoverRadius: 8,
      },
      {
        label: 'Moderate Focus (2.5–3.9)',
        data: midPoints.map((p) => ({ x: p.x, y: p.y })),
        backgroundColor: 'rgba(96, 165, 250, 0.85)',
        borderColor: '#60A5FA',
        pointStyle: 'triangle',
        pointRadius: 6.5,
        pointHoverRadius: 8.5,
      },
      {
        label: 'Low Focus (1–2.4)',
        data: lowPoints.map((p) => ({ x: p.x, y: p.y })),
        backgroundColor: 'rgba(248, 113, 113, 0.85)',
        borderColor: '#F87171',
        pointStyle: 'rectRot',
        pointRadius: 6.5,
        pointHoverRadius: 8.5,
      },
    ];

    if (highlightPoints.length > 0) {
      datasets.push({
        label: 'Latest / Selected Entry',
        data: highlightPoints.map((p) => ({ x: p.x, y: p.y })),
        backgroundColor: '#FBBF24',
        borderColor: '#FEF3C7',
        borderWidth: 2.5,
        pointStyle: 'star',
        pointRadius: 10,
        pointHoverRadius: 12,
      });
    }

    if (simulation && simulation.projectedPoints.length > 0) {
      datasets.push({
        label: `Simulated (${simulation.nights}× ${simulation.sleepHours.toFixed(1)}h)`,
        data: simulation.projectedPoints.map((p) => ({ x: p.x, y: p.y })),
        backgroundColor: 'rgba(16, 185, 129, 0.35)',
        borderColor: '#34D399',
        borderWidth: 2,
        pointStyle: 'rectRounded',
        pointRadius: 8,
        pointHoverRadius: 10,
      });
    }

    if (correlation.ols && correlation.hasConfidence) {
      datasets.push({
        type: 'line' as unknown as 'scatter',
        label: `Current OLS (${correlation.ols.equation})`,
        data: correlation.ols.linePoints,
        borderColor: '#FBBF24',
        borderWidth: 2,
        borderDash: [6, 4],
        pointRadius: 0,
        fill: false,
      } as unknown as ChartData<'scatter'>['datasets'][number]);
    }

    if (simulation?.afterOls) {
      datasets.push({
        type: 'line' as unknown as 'scatter',
        label: `Projected OLS (${simulation.afterOls.equation})`,
        data: simulation.afterOls.linePoints,
        borderColor: '#34D399',
        borderWidth: 2.5,
        borderDash: [2, 3],
        pointRadius: 0,
        fill: false,
      } as unknown as ChartData<'scatter'>['datasets'][number]);
    }

    return { datasets };
  }, [highPoints, midPoints, lowPoints, highlightPoints, correlation, simulation]);

  const pointLookup = useMemo(() => {
    return [highPoints, midPoints, lowPoints, highlightPoints];
  }, [highPoints, midPoints, lowPoints, highlightPoints]);

  const options: ChartOptions<'scatter'> = {
    responsive: true,
    maintainAspectRatio: false,
    onClick: (_event, elements) => {
      if (!onSelectDate || elements.length === 0) return;
      const el = elements[0];
      const group = pointLookup[el.datasetIndex];
      const pt = group?.[el.index];
      if (pt) onSelectDate(pt.date);
    },
    plugins: {
      title: {
        display: true,
        text: 'How Sleep Affects Your Study Focus',
        color: '#F8FAFC',
        font: { family: 'Plus Jakarta Sans', size: 14, weight: 'bold' },
        padding: { bottom: 12 },
      },
      legend: {
        position: 'bottom',
        labels: {
          color: TICK_COLOR,
          usePointStyle: true,
          boxWidth: 10,
          font: { family: 'DM Sans', size: 11 },
        },
      },
      tooltip: {
        backgroundColor: '#0F172A',
        borderColor: 'rgba(148, 163, 184, 0.3)',
        borderWidth: 1,
        callbacks: {
          label: (ctx) => {
            const group = pointLookup[ctx.datasetIndex];
            const pt = group?.[ctx.dataIndex];
            if (!pt) {
              return `${ctx.dataset.label}: (${Number(ctx.parsed.x).toFixed(2)}h, ${Number(ctx.parsed.y).toFixed(2)})`;
            }
            return [
              `Date: ${pt.date}${pt.isLatest ? ' (Latest)' : ''}`,
              `Sleep: ${pt.x.toFixed(2)}h · Focus: ${pt.y.toFixed(2)}/5`,
              `Study: ${pt.studyHours.toFixed(1)}h · ${pt.subjects.join(', ')}`,
            ];
          },
        },
      },
    },
    scales: {
      x: {
        title: {
          display: true,
          text: 'Sleep Duration (Hours)',
          color: TICK_COLOR,
          font: { family: 'DM Sans', size: 12 },
        },
        min: 4,
        max: 10.5,
        grid: { color: GRID_COLOR },
        ticks: { color: TICK_COLOR, callback: (v) => `${v}h` },
      },
      y: {
        title: {
          display: true,
          text: 'Study Focus Rating (1–5)',
          color: TICK_COLOR,
          font: { family: 'DM Sans', size: 12 },
        },
        min: 0.8,
        max: 5.3,
        grid: { color: GRID_COLOR },
        ticks: { color: TICK_COLOR, stepSize: 1 },
      },
    },
  };

  return (
    <div
      className="w-full h-full relative"
      role="region"
      aria-label="Scatter plot showing How Sleep Affects Your Study Focus with OLS regression trendline"
    >
      <Scatter ref={chartRef} data={data} options={options} />
      <table className="sr-only">
        <caption>Sleep duration versus study focus paired observations</caption>
        <thead>
          <tr>
            <th>Date</th>
            <th>Sleep Hours</th>
            <th>Focus Rating</th>
            <th>Subjects</th>
          </tr>
        </thead>
        <tbody>
          {correlation.points.map((p) => (
            <tr key={p.date}>
              <td>{p.date}</td>
              <td>{p.x}h</td>
              <td>{p.y}/5</td>
              <td>{p.subjects.join(', ')}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function SleepDebtBarChart({ sleepDebt }: { sleepDebt: SleepDebtSummary }) {
  const data: ChartData<'bar'> = useMemo(
    () => ({
      labels: sleepDebt.dailyBreakdown.map((d) => formatShortDate(d.date)),
      datasets: [
        {
          label: 'Actual Sleep (h)',
          data: sleepDebt.dailyBreakdown.map((d) => d.actualSleep),
          backgroundColor: 'rgba(96, 165, 250, 0.78)',
          borderRadius: 5,
        },
        {
          label: `Sleep Debt vs ${sleepDebt.baselineHours}h (h)`,
          data: sleepDebt.dailyBreakdown.map((d) => d.debt),
          backgroundColor: 'rgba(248, 113, 113, 0.78)',
          borderRadius: 5,
        },
      ],
    }),
    [sleepDebt],
  );

  const options: ChartOptions<'bar'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        labels: { color: TICK_COLOR, boxWidth: 12, font: { family: 'DM Sans', size: 11 } },
      },
      tooltip: {
        backgroundColor: '#0F172A',
        borderColor: 'rgba(148, 163, 184, 0.25)',
        borderWidth: 1,
      },
    },
    scales: {
      x: { stacked: true, grid: { display: false }, ticks: { color: TICK_COLOR, maxRotation: 0 } },
      y: {
        stacked: true,
        min: 0,
        suggestedMax: 10,
        grid: { color: GRID_COLOR },
        ticks: { color: TICK_COLOR, callback: (v) => `${v}h` },
      },
    },
  };

  return (
    <div className="w-full h-full relative" role="region" aria-label="Daily actual sleep versus Sleep Debt stacked bar chart">
      <Bar data={data} options={options} />
      <table className="sr-only">
        <caption>Daily Sleep Debt breakdown</caption>
        <thead>
          <tr>
            <th>Date</th>
            <th>Actual Sleep</th>
            <th>Sleep Debt</th>
          </tr>
        </thead>
        <tbody>
          {sleepDebt.dailyBreakdown.map((d) => (
            <tr key={d.date}>
              <td>{d.date}</td>
              <td>{d.actualSleep}h</td>
              <td>{d.debt}h</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function CaffeineTimelineChart({
  points,
  bedtimeHourLabel,
}: {
  points: Array<{ label: string; remainingMg: number; isBedtime: boolean }>;
  bedtimeHourLabel: string;
}) {
  const data: ChartData<'line'> = useMemo(
    () => ({
      labels: points.map((p) => p.label),
      datasets: [
        {
          label: 'Estimated Remaining Caffeine (mg)',
          data: points.map((p) => p.remainingMg),
          borderColor: '#FBBF24',
          backgroundColor: 'rgba(251, 191, 36, 0.14)',
          fill: true,
          tension: 0.25,
          pointRadius: points.map((p) => (p.isBedtime ? 7 : 2.5)),
          pointBackgroundColor: points.map((p) => (p.isBedtime ? '#F87171' : '#FBBF24')),
        },
      ],
    }),
    [points],
  );

  const options: ChartOptions<'line'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        labels: { color: TICK_COLOR, boxWidth: 12, font: { family: 'DM Sans', size: 11 } },
      },
      tooltip: {
        backgroundColor: '#0F172A',
        borderColor: 'rgba(148, 163, 184, 0.25)',
        borderWidth: 1,
        callbacks: {
          afterLabel: (ctx) => {
            const pt = points[ctx.dataIndex];
            return pt?.isBedtime ? `Target Bedtime (${bedtimeHourLabel})` : '';
          },
        },
      },
    },
    scales: {
      x: { grid: { display: false }, ticks: { color: TICK_COLOR, maxRotation: 0, autoSkip: true } },
      y: {
        min: 0,
        grid: { color: GRID_COLOR },
        ticks: { color: TICK_COLOR, callback: (v) => `${v}mg` },
      },
    },
  };

  return (
    <div className="w-full h-full relative" role="region" aria-label="Estimated caffeine half-life decay curve across the day">
      <Line data={data} options={options} />
      <table className="sr-only">
        <caption>Estimated remaining caffeine by hour</caption>
        <thead>
          <tr>
            <th>Time</th>
            <th>Remaining Caffeine (mg)</th>
          </tr>
        </thead>
        <tbody>
          {points.map((p) => (
            <tr key={p.label}>
              <td>{p.label}</td>
              <td>{p.remainingMg}mg</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
