import React, { useRef, useState } from 'react';
import { Download, FileText, GraduationCap, Printer } from 'lucide-react';
import { EXAM_CONFIDENCE_WARNING_TEXT, formatShortDate } from '../shared/math.ts';
import type { DashboardAnalytics, UserSettings } from '../shared/types.ts';
import { SleepFocusScatterChart, SleepVsProductivityTrendChart } from './Charts.tsx';

import { buildWellnessReportPdf } from '../shared/pdfReport.ts';

export function ReportsView({
  analytics,
  settings,
  daysWindow,
  onChangeDaysWindow,
  onNotify,
}: {
  analytics: DashboardAnalytics;
  settings: UserSettings;
  daysWindow: number;
  onChangeDaysWindow: (days: number) => void;
  onNotify: (type: 'success' | 'error' | 'info', message: string) => void;
}) {
  const reportChartAreaRef = useRef<HTMLDivElement | null>(null);
  const [exporting, setExporting] = useState(false);

  const sleepDays = analytics.dailySeries.filter((d) => d.totalSleep > 0);
  const totalSleepHours = Math.round(sleepDays.reduce((a, d) => a + d.totalSleep, 0) * 100) / 100;
  const avgNightlySleep =
    sleepDays.length > 0 ? Math.round((totalSleepHours / sleepDays.length) * 100) / 100 : 0;
  const totalStudyHours =
    Math.round(analytics.dailySeries.reduce((a, d) => a + d.totalStudyHours, 0) * 100) / 100;

  const periodLabel =
    analytics.dailySeries.length > 0
      ? `${formatShortDate(analytics.dailySeries[0].date)} – ${formatShortDate(analytics.dailySeries[analytics.dailySeries.length - 1].date)} (Last ${daysWindow} days)`
      : `Last ${daysWindow} days`;

  const generatedDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const examPerf = analytics.examPerformance;

  const handleDownloadPdf = async () => {
    setExporting(true);
    try {
      const { jsPDF } = await import('jspdf');
      const canvases = Array.from(reportChartAreaRef.current?.querySelectorAll('canvas') ?? []).filter(
        (c) => c.width > 0 && c.height > 0,
      );
      const chartImages: string[] = [];
      for (const canvas of canvases.slice(0, 2)) {
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = canvas.width;
        tempCanvas.height = canvas.height;
        const ctx = tempCanvas.getContext('2d');
        if (ctx) {
          ctx.fillStyle = '#0F172A';
          ctx.fillRect(0, 0, tempCanvas.width, tempCanvas.height);
          ctx.drawImage(canvas, 0, 0);
          chartImages.push(tempCanvas.toDataURL('image/png'));
        }
      }

      const { doc, filename } = buildWellnessReportPdf({
        JsPDFCtor: jsPDF,
        analytics,
        settings,
        daysWindow,
        generatedDate,
        chartImages,
      });
      doc.save(filename);
      onNotify('success', 'Downloaded DreamLog Student Wellness PDF report.');
    } catch (err) {
      onNotify('error', err instanceof Error ? err.message : 'PDF generation failed.');
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 print:hidden">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-[#111827] border border-slate-800 rounded-lg max-w-full">
          {[7, 14, 21, 30].map((d) => (
            <button
              key={d}
              type="button"
              onClick={() => onChangeDaysWindow(d)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA] ${
                daysWindow === d
                  ? 'bg-[#60A5FA] text-[#0F172A] font-semibold'
                  : 'text-[#CBD5E1] hover:text-[#F8FAFC]'
              }`}
            >
              Last {d} days
            </button>
          ))}
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => window.print()}
            className="px-4 py-2 rounded-lg border border-slate-700 bg-[#1E293B] text-xs font-medium text-[#F8FAFC] hover:bg-slate-800 transition-colors inline-flex items-center gap-2 whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
          >
            <Printer className="w-4 h-4" />
            <span>Print Report</span>
          </button>
          <button
            type="button"
            disabled={exporting}
            onClick={handleDownloadPdf}
            className="px-4 py-2 rounded-lg bg-[#60A5FA] text-[#0F172A] text-xs font-semibold hover:bg-[#93C5FD] disabled:opacity-50 transition-colors inline-flex items-center gap-2 whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#60A5FA]"
          >
            <Download className="w-4 h-4" />
            <span>{exporting ? 'Generating PDF...' : 'Download PDF Report'}</span>
          </button>
        </div>
      </div>

      {/* Report Document Preview */}
      <div className="rounded-2xl border border-slate-800 bg-[#111827] p-6 sm:p-8 space-y-8 print:border-0 print:bg-white print:text-slate-900">
        {/* Report Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800 print:border-slate-300">
          <div>
            <div className="flex items-center gap-2 text-xs text-[#60A5FA] font-medium print:text-blue-700">
              <FileText className="w-4 h-4" />
              <span>Academic Advisor Wellness Summary</span>
            </div>
            <h2 className="mt-1 font-display text-2xl font-bold text-[#F8FAFC] print:text-slate-900">
              DreamLog – SnoozeScience Report
            </h2>
            <p className="mt-1 text-xs text-[#CBD5E1] print:text-slate-700">
              Student: <strong className="text-[#F8FAFC] print:text-slate-900">{settings.studentName}</strong> · Analysis Period:{' '}
              {periodLabel}
            </p>
          </div>
          <div className="text-left sm:text-right text-xs text-[#CBD5E1] print:text-slate-700">
            <div>Generated: {generatedDate}</div>
            {analytics.hasDemoData && (
              <div className="mt-1 text-[#FBBF24] print:text-amber-700">Note: Dataset includes DEMO DATA entries</div>
            )}
          </div>
        </div>

        {/* 6 Core Report Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {[
            { label: 'Total Sleep', val: `${totalSleepHours.toFixed(1)}h` },
            { label: 'Avg Nightly Sleep', val: `${avgNightlySleep.toFixed(2)}h` },
            { label: 'Weekly Sleep Debt', val: `${analytics.weeklySleepDebt.toFixed(1)}h` },
            { label: 'Total Study Hours', val: `${totalStudyHours.toFixed(1)}h` },
            { label: 'Avg Focus Rating', val: `${analytics.averageFocusRating.toFixed(2)}/5` },
            {
              label: `Pearson r (n=${analytics.correlation.observationCount})`,
              val:
                analytics.correlation.hasConfidence && analytics.correlation.r !== null
                  ? `${analytics.correlation.r >= 0 ? '+' : ''}${analytics.correlation.r.toFixed(2)}`
                  : 'n < 7',
            },
          ].map((m) => (
            <div key={m.label} className="rounded-lg border border-slate-800 bg-[#1E293B]/60 p-3.5 print:border-slate-300 print:bg-slate-50">
              <div className="text-[11px] text-[#CBD5E1] print:text-slate-600">{m.label}</div>
              <div className="mt-1 font-mono text-lg font-bold text-[#F8FAFC] tabular-nums print:text-slate-900">
                {m.val}
              </div>
            </div>
          ))}
        </div>

        {/* Embedded Live Charts */}
        <div ref={reportChartAreaRef} className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="rounded-xl border border-slate-800 bg-[#0F172A] p-4 print:border-slate-300">
            <div className="h-64">
              <SleepFocusScatterChart correlation={analytics.correlation} />
            </div>
          </div>
          <div className="rounded-xl border border-slate-800 bg-[#0F172A] p-4 print:border-slate-300">
            <h4 className="text-xs font-semibold text-[#F8FAFC] mb-2">
              Weekly Sleep vs. Study Focus Trend
            </h4>
            <div className="h-60">
              <SleepVsProductivityTrendChart series={analytics.dailySeries} />
            </div>
          </div>
        </div>

        {/* Sleep vs Exam Performance Section */}
        <div className="rounded-xl border border-slate-800 bg-[#0F172A]/80 p-5 space-y-4 print:border-slate-300 print:bg-slate-50">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-[#FBBF24]" />
              <h3 className="text-sm font-semibold text-[#F8FAFC] print:text-slate-900">
                Sleep vs Exam Performance
              </h3>
            </div>
            <span className="text-xs font-mono text-[#CBD5E1] print:text-slate-700">
              {examPerf.hasConfidence && examPerf.r !== null
                ? `r = ${examPerf.r >= 0 ? '+' : ''}${examPerf.r.toFixed(2)} (${examPerf.category}, n = ${examPerf.observationCount})`
                : `${examPerf.confidenceWarning || EXAM_CONFIDENCE_WARNING_TEXT} (n = ${examPerf.observationCount}/5)`}
            </span>
          </div>

          {examPerf.points.length === 0 ? (
            <p className="text-xs text-[#CBD5E1] print:text-slate-700">
              No completed exam scores logged yet. Add exam results in the Exam Week Sleep Preserver view to analyze pre-exam sleep versus test performance.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-[#CBD5E1] print:border-slate-300 print:text-slate-700">
                    <th className="py-2 pr-3">Exam Date</th>
                    <th className="py-2 px-3">Subject</th>
                    <th className="py-2 px-3 text-right">3-Night Pre-Exam Avg Sleep</th>
                    <th className="py-2 pl-3 text-right">Exam Score</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/70 print:divide-slate-200">
                  {examPerf.points.map((pt) => (
                    <tr key={pt.examId}>
                      <td className="py-2 pr-3 font-mono text-[#CBD5E1] print:text-slate-700">
                        {formatShortDate(pt.examDate)}
                      </td>
                      <td className="py-2 px-3 font-medium text-[#F8FAFC] print:text-slate-900">
                        {pt.subject}
                      </td>
                      <td className="py-2 px-3 text-right font-mono text-[#60A5FA] tabular-nums print:text-blue-700">
                        {pt.preExamAvgSleep !== null
                          ? `${pt.preExamAvgSleep.toFixed(2)}h (${pt.sleepNightsCount}/3 nights)`
                          : 'No pre-exam logs'}
                      </td>
                      <td className="py-2 pl-3 text-right font-mono font-semibold text-[#34D399] tabular-nums print:text-emerald-700">
                        {pt.scorePercent.toFixed(1)}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Findings & Recommendations */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-[#F8FAFC] print:text-slate-900">Summary of Findings</h3>
            <p className="text-xs sm:text-sm text-[#CBD5E1] leading-relaxed print:text-slate-700">
              {analytics.insights.weeklySummary}
            </p>
            <h4 className="text-xs font-semibold text-[#34D399] pt-2 print:text-emerald-700">Weekly Optimization Insights</h4>
            <ul className="space-y-1.5 text-xs text-[#CBD5E1] print:text-slate-700">
              {analytics.insights.positiveInsights.map((i, idx) => (
                <li key={idx}>• {i}</li>
              ))}
              {analytics.insights.improvementAreas.map((i, idx) => (
                <li key={`imp-${idx}`}>• {i}</li>
              ))}
            </ul>
          </div>

          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-[#F8FAFC] print:text-slate-900">
              Sleep &amp; Study Optimization Recommendations
            </h3>
            <ul className="space-y-2 text-xs sm:text-sm text-[#CBD5E1] print:text-slate-700">
              {analytics.insights.sleepRecommendations.map((r, idx) => (
                <li key={idx}>• {r}</li>
              ))}
              {analytics.insights.studyRecommendations.map((r, idx) => (
                <li key={`st-${idx}`}>• {r}</li>
              ))}
            </ul>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="rounded-lg border border-slate-800 bg-[#0F172A]/80 p-4 text-xs text-[#CBD5E1] print:border-slate-300 print:bg-slate-50 print:text-slate-700">
          <strong className="text-[#F8FAFC] print:text-slate-900">Statistical Disclaimer:</strong> Observed correlation coefficients summarize linear trends in your recorded logs and do not claim or prove causation. The 8-hour sleep tracking baseline is a reference metric, not a medical diagnosis.
        </div>
      </div>
    </div>
  );
}
