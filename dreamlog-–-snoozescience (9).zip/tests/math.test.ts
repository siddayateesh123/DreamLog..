import { describe, expect, it } from 'vitest';
import {
  addDaysToDateStr,
  calculateRemainingCaffeine,
  calculateSleepDuration,
  computeCorrelationAnalysis,
  computePearsonAndOLSFromPoints,
  computeSleepDebtMetrics,
  computeWeightedFocus,
  CONFIDENCE_WARNING_TEXT,
  estimateBedtimeCaffeine,
  generateProtectiveExamTimetable,
  rescheduleMissedExamTasks,
  validateExamTimetable,
  validateScheduleFeasibility,
} from '../src/shared/math.ts';
import type { DailyMetricPoint, ExamPlanTask, ExamSchedule } from '../src/shared/types.ts';

describe('1. calculateSleepDuration', () => {
  it('calculates normal same-day sleep duration accurately', () => {
    expect(calculateSleepDuration('01:00', '09:00')).toBe(8);
    expect(calculateSleepDuration('00:45', '06:45')).toBe(6);
  });

  it('handles midnight crossings cleanly', () => {
    expect(calculateSleepDuration('23:30', '07:30')).toBe(8);
    expect(calculateSleepDuration('22:15', '06:45')).toBe(8.5);
  });

  it('returns 0 for invalid time strings', () => {
    expect(calculateSleepDuration('25:00', '07:00')).toBe(0);
    expect(calculateSleepDuration('23:99', '07:00')).toBe(0);
    expect(calculateSleepDuration('invalid', '07:30')).toBe(0);
  });

  it('returns 0 when bedtime and wakeTime are equal', () => {
    expect(calculateSleepDuration('07:00', '07:00')).toBe(0);
    expect(calculateSleepDuration('23:30', '23:30')).toBe(0);
  });
});

describe('2. Pearson correlation', () => {
  it('computes perfect positive correlation (r = +1)', () => {
    const pts = [5, 6, 7, 8, 9, 6.5, 7.5].map((x) => ({ x, y: x - 4 }));
    const res = computePearsonAndOLSFromPoints(pts);
    expect(res.r).toBe(1);
    expect(res.category).toBe('Strong Positive Correlation');
    expect(res.hasConfidence).toBe(true);
  });

  it('computes perfect negative correlation (r = -1)', () => {
    const pts = [5, 6, 7, 8, 9, 6.5, 7.5].map((x) => ({ x, y: 10 - x }));
    const res = computePearsonAndOLSFromPoints(pts);
    expect(res.r).toBe(-1);
    expect(res.category).toBe('Strong Negative Correlation');
  });

  it('computes zero correlation on symmetric orthogonal points', () => {
    // Mean x = 7, Mean y = 3, sum(dx*dy) = 0, both variances > 0
    const pts = [
      { x: 5, y: 3 },
      { x: 6, y: 5 },
      { x: 7, y: 3 },
      { x: 8, y: 1 },
      { x: 9, y: 3 },
      { x: 6, y: 1 },
      { x: 8, y: 5 },
    ];
    const res = computePearsonAndOLSFromPoints(pts);
    expect(res.r).toBe(0);
    expect(res.category).toBe('No Linear Correlation');
  });

  it('guards against zero variance on X or Y without dividing by zero', () => {
    const constX = [1, 2, 3, 4, 5, 3, 4].map((y) => ({ x: 7.5, y }));
    const resX = computePearsonAndOLSFromPoints(constX);
    expect(resX.r).toBeNull();
    expect(resX.zeroVariance).toBe(true);
    expect(resX.category).toBe('Undefined (Zero Variance)');
    expect(resX.ols).toBeNull();

    const constY = [5, 6, 7, 8, 9, 7.5, 8.5].map((x) => ({ x, y: 4 }));
    const resY = computePearsonAndOLSFromPoints(constY);
    expect(resY.r).toBeNull();
    expect(resY.zeroVariance).toBe(true);
    expect(resY.ols).toBeNull();
  });

  it('withholds statistical confidence when n < 7 observations', () => {
    const under7 = [5, 6, 7, 8, 9, 7.5].map((x) => ({ x, y: x - 4 }));
    const res = computePearsonAndOLSFromPoints(under7);
    expect(res.r).toBeNull();
    expect(res.hasConfidence).toBe(false);
    expect(res.observationCount).toBe(6);
    expect(res.confidenceWarning).toBe(CONFIDENCE_WARNING_TEXT);
  });

  it('excludes missing paired observations (sleep-only or study-only dates)', () => {
    const baseDay = (
      date: string,
      totalSleep: number,
      averageFocus: number | null,
      studySessionsCount: number,
    ): DailyMetricPoint => ({
      date,
      totalSleep,
      sleepQuality: totalSleep > 0 ? 4 : null,
      bedtime: totalSleep > 0 ? '23:00' : null,
      wakeTime: totalSleep > 0 ? '07:00' : null,
      totalStudyHours: studySessionsCount > 0 ? 4 : 0,
      averageFocus,
      studySessionsCount,
      subjects: studySessionsCount > 0 ? ['Algorithms'] : [],
      sleepDebt: 0,
      caffeineTotalMg: 0,
      caffeineAtBedtimeMg: 0,
      isDemo: false,
      hasPairedData: totalSleep > 0 && averageFocus !== null && studySessionsCount > 0,
      latestUpdated: false,
    });

    const series: DailyMetricPoint[] = [
      baseDay('2026-03-01', 5, 1, 1),
      baseDay('2026-03-02', 6, 2, 1),
      baseDay('2026-03-03', 7, 3, 1),
      baseDay('2026-03-04', 8, 4, 1),
      baseDay('2026-03-05', 9, 5, 1),
      baseDay('2026-03-06', 6.5, 2.5, 1),
      baseDay('2026-03-07', 7.5, 3.5, 1),
      baseDay('2026-03-08', 8.5, null, 0), // Sleep-only (missing study)
      baseDay('2026-03-09', 0, 5, 1), // Study-only (missing sleep)
    ];

    const corr = computeCorrelationAnalysis(series);
    expect(corr.observationCount).toBe(7);
    expect(corr.r).toBe(1);
    expect(computeWeightedFocus([{ studyHours: 2, focusRating: 5 }, { studyHours: 6, focusRating: 3 }])).toBe(3.5);
  });
});

describe('3. OLS regression', () => {
  it('fits positive slope and intercept cleanly', () => {
    const pts = [5, 6, 7, 8, 9, 6.5, 7.5].map((x) => ({ x, y: x - 4 }));
    const res = computePearsonAndOLSFromPoints(pts);
    expect(res.ols).not.toBeNull();
    expect(res.ols?.slope).toBeCloseTo(1, 3);
    expect(res.ols?.intercept).toBeCloseTo(-4, 3);
    expect(res.ols?.equation).toBe('y = 1.00x - 4.00');
  });

  it('fits negative slope and preserves exact slope when clipped to [1, 5]', () => {
    const pts = [
      { x: 5, y: 5 },
      { x: 5.5, y: 4 },
      { x: 6, y: 3 },
      { x: 6.5, y: 2 },
      { x: 7, y: 1 },
      { x: 7.5, y: 1 },
      { x: 8, y: 1 },
    ];
    const res = computePearsonAndOLSFromPoints(pts);
    expect(res.ols).not.toBeNull();
    expect(res.ols!.slope).toBeLessThan(0);
    const [p1, p2] = res.ols!.linePoints;
    expect(p1.y).toBeLessThanOrEqual(5);
    expect(p2.y).toBeGreaterThanOrEqual(1);
    expect(Math.abs(p1.y - (res.ols!.slope * p1.x + res.ols!.intercept))).toBeLessThan(0.05);
  });

  it('produces zero slope for horizontal uncorrelated variance', () => {
    const pts = [
      { x: 5, y: 3 },
      { x: 6, y: 5 },
      { x: 7, y: 3 },
      { x: 8, y: 1 },
      { x: 9, y: 3 },
      { x: 6, y: 1 },
      { x: 8, y: 5 },
    ];
    const res = computePearsonAndOLSFromPoints(pts);
    expect(res.ols).not.toBeNull();
    expect(res.ols?.slope).toBe(0);
    expect(res.ols?.intercept).toBe(3);
  });

  it('returns null OLS for constant values and insufficient data', () => {
    const constVals = [1, 2, 3, 4, 5, 6, 7].map(() => ({ x: 8, y: 4 }));
    expect(computePearsonAndOLSFromPoints(constVals).ols).toBeNull();

    const tooFew = [5, 6, 7].map((x) => ({ x, y: x - 3 }));
    expect(computePearsonAndOLSFromPoints(tooFew).ols).toBeNull();
  });
});

describe('4. Sleep debt calculations', () => {
  it('computes normal deficit accurately against 8h baseline', () => {
    const days = [
      { date: '2026-03-01', totalSleep: 6.5 },
      { date: '2026-03-02', totalSleep: 7.0 },
      { date: '2026-03-03', totalSleep: 6.0 },
    ];
    const debt = computeSleepDebtMetrics(days, days, 8);
    expect(debt.weeklyCumulativeDebt).toBe(4.5);
    expect(debt.weeklyCumulativeSurplus).toBe(0);
  });

  it('keeps sleep surplus separate without subtracting from daily deficit', () => {
    const days = [
      { date: '2026-03-01', totalSleep: 6 },
      { date: '2026-03-02', totalSleep: 10 },
    ];
    const debt = computeSleepDebtMetrics(days, days, 8);
    expect(debt.weeklyCumulativeDebt).toBe(2);
    expect(debt.weeklyCumulativeSurplus).toBe(2);
  });

  it('tracks seven-day logged vs missing nights and excludes missing records', () => {
    const weekDays = [
      { date: '2026-03-01', totalSleep: 7 },
      { date: '2026-03-02', totalSleep: 0 }, // Missing log (e.g., study-only day)
      { date: '2026-03-03', totalSleep: 8 },
      { date: '2026-03-04', totalSleep: 6.5 },
    ];
    const debt = computeSleepDebtMetrics(weekDays, weekDays, 8);
    expect(debt.weeklyLoggedNights).toBe(3);
    expect(debt.weeklyMissingNights).toBe(4);
    expect(debt.weeklyCumulativeDebt).toBe(2.5); // Never penalizes 0h missing night as +8h debt!
    expect(debt.dailyBreakdown).toHaveLength(3);
  });

  it('handles calendar date-boundary arithmetic across leap years and month ends', () => {
    expect(addDaysToDateStr('2024-02-28', 2)).toBe('2024-03-01');
    expect(addDaysToDateStr('2025-12-31', 1)).toBe('2026-01-01');
    expect(addDaysToDateStr('2026-03-01', -1)).toBe('2026-02-28');
  });
});

describe('5. Caffeine half-life', () => {
  it('calculates standard half-life decay accurately', () => {
    expect(calculateRemainingCaffeine(100, 5, 5)).toBe(50);
    expect(calculateRemainingCaffeine(200, 10, 5)).toBe(50);
  });

  it('handles different elapsed times cleanly', () => {
    expect(calculateRemainingCaffeine(120, 0, 5)).toBe(120);
    expect(calculateRemainingCaffeine(100, 2.5, 5)).toBeCloseTo(70.7, 1);
  });

  it('sums multiple caffeine entries accurately at bedtime', () => {
    const logs = [
      { consumptionTime: '08:00', caffeineAmount: 100 }, // 15h before 23:00 -> 12.5mg
      { consumptionTime: '18:00', caffeineAmount: 100 }, // 5h before 23:00 -> 50mg
    ];
    expect(estimateBedtimeCaffeine(logs, '23:00', 5)).toBe(62.5);
  });

  it('handles midnight crossings between late intake and post-midnight bedtime', () => {
    const logs = [{ consumptionTime: '22:00', caffeineAmount: 100 }];
    // 22:00 -> 03:00 is 5h -> 50mg remaining
    expect(estimateBedtimeCaffeine(logs, '03:00', 5)).toBe(50);
  });
});

describe('6. Exam scheduling & Sleep Preserver innovation', () => {
  const sampleExams: ExamSchedule[] = [
    {
      id: 1,
      examDate: '2099-05-07',
      subject: 'Algorithms',
      topics: 'DP, Graphs, Flows',
      priority: 'High',
      estimatedHours: 8,
      createdAt: '',
    },
    {
      id: 2,
      examDate: '2099-05-12',
      subject: 'History',
      topics: 'Modern Era',
      priority: 'Low',
      estimatedHours: 4,
      createdAt: '',
    },
  ];

  it('protects >= 7h sleep and caps study at <= 8h/day even when user requests > 8h', () => {
    const plan = generateProtectiveExamTimetable(sampleExams, 12, '07:30', '2099-05-05');
    const val = validateExamTimetable(plan.tasks, '07:30');
    expect(val.valid).toBe(true);
    expect(val.maxDailyStudyHours).toBeLessThanOrEqual(8);
    expect(val.minSleepHours).toBeGreaterThanOrEqual(7);
    expect(val.overlapCount).toBe(0);
    expect(plan.decisions.some((d) => d.includes('capped at 8.0h/day'))).toBe(true);
  });

  it('prevents overlapping tasks across standard, early-bird, and night-owl midnight schedules', () => {
    for (const wake of ['06:00', '07:30', '21:00']) {
      const plan = generateProtectiveExamTimetable(sampleExams, 8, wake, '2099-05-05');
      const val = validateExamTimetable(plan.tasks, wake);
      expect(val.valid).toBe(true);
      expect(val.overlapCount).toBe(0);
      expect(val.minSleepHours).toBeGreaterThanOrEqual(7);
      expect(val.maxDailyStudyHours).toBeLessThanOrEqual(8);
    }
  });

  it('prioritizes High priority and closer deadlines ahead of Low priority distant exams', () => {
    const plan = generateProtectiveExamTimetable(sampleExams, 6, '07:30', '2099-05-05');
    const day1Study = plan.tasks.filter((t) => t.date === '2099-05-05' && t.type === 'study');
    expect(day1Study.length).toBeGreaterThan(0);
    expect(day1Study[0].subject).toBe('Algorithms');
    expect(day1Study[0].schedulingReason).toContain('High priority');
  });

  it('validates schedule feasibility and reports deficits when capacity is exceeded', () => {
    const overloaded: ExamSchedule[] = [
      {
        id: 3,
        examDate: '2099-05-06',
        subject: 'Quantum Physics',
        topics: 'Wavefunctions, Operators',
        priority: 'High',
        estimatedHours: 30,
        createdAt: '',
      },
    ];
    const plan = generateProtectiveExamTimetable(overloaded, 8, '07:30', '2099-05-05');
    const feasibility = validateScheduleFeasibility(
      plan.tasks,
      overloaded,
      8,
      '07:30',
      '2099-05-05',
    );
    expect(feasibility.feasible).toBe(false);
    expect(feasibility.deficitHours).toBeGreaterThan(0);
    expect(plan.capacityWarning).not.toBeNull();
  });

  it('reschedules missed tasks forward without violating sleep or study limits', () => {
    const pastPlan = generateProtectiveExamTimetable(sampleExams, 6, '07:30', '2099-05-04');
    const hydrated: ExamPlanTask[] = pastPlan.tasks.map((t, idx) => ({ ...t, id: idx + 1 }));
    const rescheduled = rescheduleMissedExamTasks(
      hydrated,
      sampleExams,
      6,
      '07:30',
      '2099-05-05',
    );
    const val = validateExamTimetable(rescheduled.tasks, '07:30');
    expect(rescheduled.rescheduledCount).toBeGreaterThan(0);
    expect(rescheduled.rescheduledHours).toBeGreaterThan(0);
    expect(val.valid).toBe(true);
    expect(val.overlapCount).toBe(0);
    expect(rescheduled.decisions[0]).toContain('Reallocated');
  });

  it('prioritizes higher topicDifficulty ahead of easier topics when priority & deadline tie', () => {
    const tiedExams: ExamSchedule[] = [
      {
        id: 10,
        examDate: '2099-06-10',
        subject: 'Intro Ethics',
        topics: 'Readings',
        priority: 'Medium',
        topicDifficulty: 1,
        estimatedHours: 4,
        createdAt: '',
      },
      {
        id: 11,
        examDate: '2099-06-10',
        subject: 'Compiler Design',
        topics: 'LR Parsing, SSA',
        priority: 'Medium',
        topicDifficulty: 5,
        estimatedHours: 4,
        createdAt: '',
      },
    ];
    const plan = generateProtectiveExamTimetable(tiedExams, 4, '07:30', '2099-06-08');
    const day1Study = plan.tasks.filter((t) => t.date === '2099-06-08' && t.type === 'study');
    expect(day1Study[0].subject).toBe('Compiler Design');
    expect(day1Study[0].schedulingReason).toContain('diff 5/5');
  });

  it('detects impossible milestone deadline bottlenecks without breaking sleep or study invariants', () => {
    const impossibleMilestone: ExamSchedule[] = [
      {
        id: 20,
        examDate: '2099-07-02', // Only 2 calendar days from 2099-07-01 => max 16h capacity
        subject: 'Real Analysis',
        topics: 'Measure Theory',
        priority: 'High',
        estimatedHours: 24,
        createdAt: '',
      },
      {
        id: 21,
        examDate: '2099-07-14',
        subject: 'Art History',
        topics: 'Renaissance',
        priority: 'Low',
        estimatedHours: 4,
        createdAt: '',
      },
    ];
    const plan = generateProtectiveExamTimetable(impossibleMilestone, 8, '07:30', '2099-07-01');
    expect(plan.feasibility.feasible).toBe(false);
    expect(plan.feasibility.warnings.some((w) => w.includes('Impossible deadline constraint'))).toBe(
      true,
    );
    const val = validateExamTimetable(plan.tasks, '07:30');
    expect(val.valid).toBe(true); // Never breaks 8h study or 7h sleep constraints even when impossible
  });
});

describe('7. Bedtime cycles, weighted focus & Sleep Shift Simulator', () => {
  it('calculates 90-minute bedtime cycles with latency and simulates sleep shifts', async () => {
    const { calculateBedtimeCycles, simulateSleepShift } = await import('../src/shared/math.ts');
    const cycles = calculateBedtimeCycles('07:30', 15);
    expect(cycles).toHaveLength(4);
    expect(cycles[0].cycles).toBe(6);
    expect(cycles[0].getInBedTime).toBe('22:15');
    expect(cycles[0].fallAsleepTime).toBe('22:30');

    const sim = simulateSleepShift(
      [
        { x: 5.5, y: 2 },
        { x: 6.0, y: 2.5 },
        { x: 6.5, y: 3 },
        { x: 7.0, y: 3.5 },
        { x: 7.5, y: 4 },
        { x: 8.0, y: 4.5 },
        { x: 8.5, y: 4.8 },
      ],
      8,
      3,
    );
    expect(sim.projectedPoints).toHaveLength(3);
    expect(sim.beforeR).not.toBeNull();
    expect(sim.afterR).not.toBeNull();
    expect(sim.afterOls).not.toBeNull();

    expect(computeWeightedFocus([])).toBeNull();
    expect(computeWeightedFocus([{ studyHours: 0, focusRating: 4 }])).toBe(4);
  });
});

describe('8. Daily metrics rebuild, Weekly Insights, Exam Performance & trend boundaries', () => {
  it('calculates study time-range hours cleanly including midnight wrap and invalid bounds', async () => {
    const { calculateTimeRangeHours } = await import('../src/shared/math.ts');
    expect(calculateTimeRangeHours('09:00', '12:30')).toBe(3.5);
    expect(calculateTimeRangeHours('22:30', '01:00')).toBe(2.5);
    expect(calculateTimeRangeHours('bad', '12:00')).toBe(0);
    expect(calculateTimeRangeHours('10:00', '10:00')).toBe(0);
  });

  it('analyzes pre-exam 3-night sleep correlation with n>=5 confidence threshold and missing-night guards', async () => {
    const { computeExamPerformanceAnalysis } = await import('../server/services/analyticsService.ts');
    const examResults = [
      { id: 1, subject: 'Math', examDate: '2026-04-10', scorePercent: 92, notes: '', isDemo: false, createdAt: '' },
      { id: 2, subject: 'OS', examDate: '2026-04-14', scorePercent: 70, notes: '', isDemo: false, createdAt: '' },
      { id: 3, subject: 'DB', examDate: '2026-04-18', scorePercent: 84, notes: '', isDemo: false, createdAt: '' },
      { id: 4, subject: 'AI', examDate: '2026-04-22', scorePercent: 88, notes: '', isDemo: false, createdAt: '' },
      { id: 5, subject: 'Net', examDate: '2026-04-26', scorePercent: 76, notes: '', isDemo: false, createdAt: '' },
      { id: 6, subject: 'NoSleep', examDate: '2026-05-05', scorePercent: 80, notes: '', isDemo: false, createdAt: '' },
    ];
    const sleepLogs = [
      { id: 1, date: '2026-04-08', bedtime: '23:00', wakeTime: '07:30', duration: 8.5, sleepQuality: 5, notes: '', isDemo: false, createdAt: '' },
      { id: 2, date: '2026-04-09', bedtime: '23:00', wakeTime: '07:30', duration: 8.5, sleepQuality: 5, notes: '', isDemo: false, createdAt: '' },
      { id: 3, date: '2026-04-12', bedtime: '01:30', wakeTime: '07:00', duration: 5.5, sleepQuality: 2, notes: '', isDemo: false, createdAt: '' },
      { id: 4, date: '2026-04-16', bedtime: '23:30', wakeTime: '07:00', duration: 7.5, sleepQuality: 4, notes: '', isDemo: false, createdAt: '' },
      { id: 5, date: '2026-04-20', bedtime: '23:00', wakeTime: '07:00', duration: 8.0, sleepQuality: 4, notes: '', isDemo: false, createdAt: '' },
      { id: 6, date: '2026-04-24', bedtime: '01:00', wakeTime: '07:00', duration: 6.0, sleepQuality: 3, notes: '', isDemo: false, createdAt: '' },
    ];

    const small = computeExamPerformanceAnalysis(examResults.slice(0, 3), sleepLogs);
    expect(small.hasConfidence).toBe(false);
    expect(small.r).toBeNull();
    expect(small.observationCount).toBe(3);

    const full = computeExamPerformanceAnalysis(examResults, sleepLogs);
    expect(full.hasConfidence).toBe(true);
    expect(full.observationCount).toBe(5); // 6th exam lacks prior 3-night sleep
    expect(full.r).not.toBeNull();
    expect(full.r!).toBeGreaterThan(0.9);
    expect(full.points.find((p) => p.subject === 'NoSleep')?.preExamAvgSleep).toBeNull();
  });

  it('rebuilds daily_metrics atomically in SQLite and generates personalized weekly optimization insights', async () => {
    const Database = (await import('better-sqlite3')).default;
    const { runMigrations } = await import('../server/db/migrations.ts');
    const {
      computeWeeklyInsightsFromSeries,
      getDashboardAnalyticsForUser,
      rebuildDailyMetricsForUser,
    } = await import('../server/services/analyticsService.ts');
    const { getLocalDateStr } = await import('../src/shared/math.ts');

    const db = new Database(':memory:');
    db.pragma('foreign_keys = ON');
    runMigrations(db);
    db.prepare(
      `INSERT INTO user_settings (userId, studentName, sleepBaselineHours, caffeineHalfLifeHours, preferredWakeTime, dailyAvailableHours)
       VALUES (1, 'Insight Tester', 8, 5, '07:30', 7)`,
    ).run();

    const today = getLocalDateStr(0);
    const yesterday = getLocalDateStr(-1);
    const lastWeekDay = getLocalDateStr(-8);

    // Log high sleep + high focus today, short sleep + caffeine + low focus yesterday, and baseline last week
    const insSleep = db.prepare(
      `INSERT INTO sleep_logs (userId, date, bedtime, wakeTime, duration, sleepQuality, notes, isDemo, createdAt)
       VALUES (1, ?, ?, ?, ?, ?, '', 0, ?)`,
    );
    insSleep.run(today, '23:00', '07:30', 8.5, 5, `${today}T08:00:00Z`);
    insSleep.run(yesterday, '01:30', '07:00', 5.5, 2, `${yesterday}T08:00:00Z`);
    insSleep.run(lastWeekDay, '23:30', '07:30', 8.0, 4, `${lastWeekDay}T08:00:00Z`);

    const insStudy = db.prepare(
      `INSERT INTO study_logs (userId, date, subject, studyHours, focusRating, startTime, endTime, notes, isDemo, createdAt)
       VALUES (1, ?, ?, ?, ?, '', '', '', 0, ?)`,
    );
    insStudy.run(today, 'Algorithms', 4, 5, `${today}T12:00:00Z`);
    insStudy.run(yesterday, 'Physics', 6.5, 2, `${yesterday}T14:00:00Z`);
    insStudy.run(lastWeekDay, 'Calculus', 3, 3, `${lastWeekDay}T12:00:00Z`);

    db.prepare(
      `INSERT INTO caffeine_logs (userId, date, beverageType, consumptionTime, caffeineAmount, notes, isDemo, createdAt)
       VALUES (1, ?, 'Coffee', '21:00', 180, '', 0, ?)`,
    ).run(yesterday, `${yesterday}T21:00:00Z`);

    rebuildDailyMetricsForUser(db, 1);
    const metrics = db.prepare('SELECT * FROM daily_metrics WHERE userId = 1 ORDER BY date ASC').all() as Array<{
      date: string;
      totalSleep: number;
      averageFocus: number;
      sleepDebt: number;
    }>;
    expect(metrics).toHaveLength(3);
    expect(metrics.find((m) => m.date === yesterday)?.sleepDebt).toBe(2.5);
    expect(metrics.find((m) => m.date === today)?.sleepDebt).toBe(0);

    const dash = getDashboardAnalyticsForUser(db, 1, 21);
    expect(dash.insights.positiveInsights.some((s) => s.includes('7.5+ hours of sleep'))).toBe(true);
    expect(dash.insights.improvementAreas.some((s) => s.includes('>= 40mg'))).toBe(true);
    expect(dash.insights.studyRecommendations.some((s) => s.includes('3–6 hour'))).toBe(true);
    expect(dash.consistencyStatus).toBe('Inconsistent');

    // Empty-series fallback produces friendly onboarding guidance without throwing
    const emptyDebt = computeSleepDebtMetrics([], [], 8);
    const emptyInsights = computeWeeklyInsightsFromSeries([], [], emptyDebt, {
      studentName: 'Empty',
      sleepBaselineHours: 8,
      caffeineHalfLifeHours: 5,
      preferredWakeTime: '07:30',
      dailyAvailableHours: 7,
      onboardingDismissed: false,
      demoCleared: false,
    });
    expect(emptyInsights.weeklySummary).toContain('No records logged');
    db.close();
  });
});


