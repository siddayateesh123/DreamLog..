import Database from 'better-sqlite3';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { describe, expect, it } from 'vitest';
import { createDatabaseConnection } from '../server/config/database.ts';
import {
  getAppliedMigrations,
  MIGRATIONS,
  rollbackLastMigration,
  runMigrations,
} from '../server/db/migrations.ts';
import { SleepRepository } from '../server/repositories/sleepRepository.ts';
import { UserRepository } from '../server/repositories/userRepository.ts';

describe('Database version-controlled migrations, constraints & persistence', () => {
  it('runs all migrations cleanly on a fresh database and supports rollback', () => {
    const db = new Database(':memory:');
    db.pragma('foreign_keys = ON');

    const applied = runMigrations(db);
    expect(applied.map((m) => m.version)).toEqual(MIGRATIONS.map((m) => m.version));
    expect(getAppliedMigrations(db)).toHaveLength(MIGRATIONS.length);

    // Roll back v4 safely and verify downgrade works cleanly
    const rolled = rollbackLastMigration(db);
    expect(rolled?.version).toBe(4);
    expect(getAppliedMigrations(db)).toHaveLength(3);

    // Re-apply v4 idempotently
    const reapplied = runMigrations(db);
    expect(reapplied.map((m) => m.version)).toEqual([4]);
    expect(getAppliedMigrations(db)).toHaveLength(4);

    db.close();
  });

  it('migrates legacy v1 single-user records through v4 with zero data loss', () => {
    const db = new Database(':memory:');
    db.pragma('foreign_keys = ON');

    // Simulate legacy database before migration system existed (v1 core tables + sample data)
    MIGRATIONS[0].up(db);
    db.prepare(
      `INSERT INTO user_settings (id, studentName, sleepBaselineHours, caffeineHalfLifeHours, preferredWakeTime, dailyAvailableHours, onboardingDismissed, demoCleared, seedVersion)
       VALUES (1, 'Legacy Student', 8, 5, '07:30', 7, 1, 0, 2)`,
    ).run();
    db.prepare(
      `INSERT INTO sleep_logs (date, bedtime, wakeTime, duration, sleepQuality, notes, isDemo, createdAt)
       VALUES ('2026-02-01', '23:00', '07:00', 8.0, 4, 'Preserved row', 0, '2026-02-01T07:00:00.000Z')`,
    ).run();
    db.prepare(
      `INSERT INTO daily_metrics (date, totalSleep, totalStudyHours, averageFocus, sleepDebt, correlationMetrics)
       VALUES ('2026-02-01', 8.0, 4.0, 4.5, 0, '{"paired":true}')`,
    ).run();
    db.prepare(
      `INSERT INTO exam_schedules (examDate, subject, topics, priority, estimatedHours, createdAt)
       VALUES ('2026-05-10', 'Algorithms', 'Graphs', 'High', 6, '2026-02-01T07:00:00.000Z')`,
    ).run();

    // Mark v1 applied and upgrade to v4
    db.exec(`
      CREATE TABLE schema_migrations (version INTEGER PRIMARY KEY, name TEXT NOT NULL, appliedAt TEXT NOT NULL);
      INSERT INTO schema_migrations (version, name, appliedAt) VALUES (1, '001_initial_core_tables', '2026-02-01T00:00:00Z');
    `);

    const newlyApplied = runMigrations(db);
    expect(newlyApplied.map((m) => m.version)).toEqual([2, 3, 4]);

    const preservedSleep = db
      .prepare('SELECT userId, notes, duration FROM sleep_logs WHERE date = ?')
      .get('2026-02-01') as { userId: number; notes: string; duration: number };
    expect(preservedSleep.userId).toBe(1);
    expect(preservedSleep.notes).toBe('Preserved row');
    expect(preservedSleep.duration).toBe(8);

    const preservedSettings = db
      .prepare('SELECT userId, studentName FROM user_settings WHERE userId = 1')
      .get() as { userId: number; studentName: string };
    expect(preservedSettings.studentName).toBe('Legacy Student');

    const preservedExam = db
      .prepare('SELECT userId, subject, topicDifficulty FROM exam_schedules WHERE subject = ?')
      .get('Algorithms') as { userId: number; subject: string; topicDifficulty: number };
    expect(preservedExam.userId).toBe(1);
    expect(preservedExam.topicDifficulty).toBe(3);

    db.close();
  });

  it('enforces foreign key constraints and rolls back failed transactions cleanly', () => {
    const db = new Database(':memory:');
    db.pragma('foreign_keys = ON');
    runMigrations(db);

    const userRepo = new UserRepository(db);
    const sleepRepo = new SleepRepository(db);

    // Foreign key constraint rejects orphaned session for non-existent userId
    expect(() =>
      userRepo.createSession({
        tokenHash: 'orphan-hash',
        userId: 999999,
        expiresAt: '2099-01-01T00:00:00.000Z',
      }),
    ).toThrow();

    // Failed transaction leaves prior state untouched
    expect(() =>
      db.transaction(() => {
        sleepRepo.createForUser(1, {
          date: '2026-01-10',
          bedtime: '23:00',
          wakeTime: '07:00',
          duration: 8,
          sleepQuality: 4,
          notes: 'Should roll back',
        });
        throw new Error('Simulated transaction crash');
      })(),
    ).toThrow('Simulated transaction crash');

    expect(sleepRepo.findAllByUser(1)).toHaveLength(0);
    db.close();
  });

  it('persists SQLite data safely across connection close and reopen on disk', () => {
    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'dreamlog-db-test-'));
    const dbPath = path.join(tmpDir, 'dreamlog-persist.db');
    try {
      const db1 = createDatabaseConnection(dbPath);
      runMigrations(db1);
      const sleep1 = new SleepRepository(db1);
      sleep1.createForUser(1, {
        date: '2026-01-20',
        bedtime: '23:15',
        wakeTime: '07:15',
        duration: 8,
        sleepQuality: 5,
        notes: 'Persisted across restart',
      });
      db1.close();

      // Ensure DELETE journal mode leaves no orphaned WAL sidecar files
      expect(fs.existsSync(`${dbPath}-wal`)).toBe(false);

      const db2 = createDatabaseConnection(dbPath);
      runMigrations(db2);
      const sleep2 = new SleepRepository(db2);
      const rows = sleep2.findAllByUser(1);
      expect(rows).toHaveLength(1);
      expect(rows[0].notes).toBe('Persisted across restart');
      db2.close();
    } finally {
      fs.rmSync(tmpDir, { recursive: true, force: true });
    }
  });
});
