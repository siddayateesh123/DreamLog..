import Database from 'better-sqlite3';
import { jsPDF } from 'jspdf';
import { describe, expect, it } from 'vitest';
import { runMigrations } from '../server/db/migrations.ts';
import { UserRepository } from '../server/repositories/userRepository.ts';
import { getDashboardAnalyticsForUser } from '../server/services/analyticsService.ts';
import { seedDemoDataForUser } from '../server/services/demoSeedService.ts';
import { buildWellnessReportPdf } from '../src/shared/pdfReport.ts';

describe('Wellness Report PDF generation', () => {
  it('generates a valid multi-section PDF binary from seeded analytics and exam results', () => {
    const db = new Database(':memory:');
    db.pragma('foreign_keys = ON');
    runMigrations(db);
    seedDemoDataForUser(db, 1);

    const settings = new UserRepository(db).getSettings(1);
    const analytics = getDashboardAnalyticsForUser(db, 1, 21);

    const result = buildWellnessReportPdf({
      JsPDFCtor: jsPDF,
      analytics,
      settings,
      daysWindow: 21,
      generatedDate: 'November 20, 2026',
    });

    expect(result.filename).toBe('DreamLog_Wellness_Report_Maya_Lin.pdf');
    expect(result.sections).toEqual(
      expect.arrayContaining([
        'Header',
        'KPI Summary',
        'Correlation & OLS Regression Analysis',
        'Sleep vs Exam Performance',
        'Recent Daily Sleep & Study Summary',
        'Summary of Findings',
        'Weekly Optimization Insights',
        'Sleep & Study Recommendations',
        'Methodological Note',
      ]),
    );
    expect(result.pageCount).toBeGreaterThanOrEqual(1);

    const buf = Buffer.from(result.doc.output('arraybuffer'));
    expect(buf.subarray(0, 5).toString('ascii')).toBe('%PDF-');
    expect(buf.byteLength).toBeGreaterThan(2000);

    db.close();
  });

  it('handles empty logs, missing exam results, and multi-page pagination cleanly', () => {
    const db = new Database(':memory:');
    db.pragma('foreign_keys = ON');
    runMigrations(db);
    const userRepo = new UserRepository(db);
    const user = userRepo.createUser({
      name: 'Empty Student',
      email: 'empty@college.edu',
      passwordHash: 'hash-not-needed-in-test',
    });
    const settings = userRepo.getSettings(user.id);
    const emptyAnalytics = getDashboardAnalyticsForUser(db, user.id, 7);

    const emptyPdf = buildWellnessReportPdf({
      JsPDFCtor: jsPDF,
      analytics: emptyAnalytics,
      settings,
      daysWindow: 7,
      generatedDate: 'November 20, 2026',
    });
    const emptyBytes = Buffer.from(emptyPdf.doc.output('arraybuffer'));
    expect(emptyBytes.subarray(0, 5).toString('ascii')).toBe('%PDF-');
    expect(emptyPdf.sections).toContain('Sleep vs Exam Performance');
    expect(emptyPdf.sections).toContain('Methodological Note');

    // Force multi-page overflow with many long recommendations & exam results
    const heavyAnalytics = {
      ...emptyAnalytics,
      examPerformance: {
        ...emptyAnalytics.examPerformance,
        points: Array.from({ length: 24 }, (_, idx) => ({
          examId: idx + 1,
          subject: `Subject Module ${idx + 1}`,
          examDate: '2026-11-01',
          scorePercent: 85,
          preExamAvgSleep: 7.5,
          sleepNightsCount: 3,
          notes: '',
        })),
      },
      insights: {
        ...emptyAnalytics.insights,
        sleepRecommendations: Array.from(
          { length: 20 },
          (_, idx) => `Recommendation ${idx + 1}: Maintain steady circadian wake schedule.`,
        ),
      },
    };

    const multiPagePdf = buildWellnessReportPdf({
      JsPDFCtor: jsPDF,
      analytics: heavyAnalytics,
      settings,
      daysWindow: 21,
      generatedDate: 'November 20, 2026',
    });
    expect(multiPagePdf.pageCount).toBeGreaterThanOrEqual(2);

    db.close();
  });
});
