import bcrypt from 'bcryptjs';
import Database from 'better-sqlite3';
import request from 'supertest';
import { afterEach, describe, expect, it } from 'vitest';
import { createApp } from '../server/app.ts';
import { validateEnvironment } from '../server/config/env.ts';
import { getLocalDateStr } from '../src/shared/math.ts';

function createTestContext(options: {
  seedDefaultDemo?: boolean;
  enableRateLimit?: boolean;
  authRateLimitMax?: number;
} = {}) {
  const db = new Database(':memory:');
  db.pragma('foreign_keys = ON');
  const app = createApp(db, {
    seedDefaultDemo: options.seedDefaultDemo ?? true,
    enableRateLimit: options.enableRateLimit ?? false,
    authRateLimitMax: options.authRateLimitMax,
  });
  return { db, app };
}

describe('API Integration, Authentication, Security & Multi-Tenancy', () => {
  const dbsToClose: Database.Database[] = [];

  afterEach(() => {
    delete process.env.NODE_ENV;
    while (dbsToClose.length > 0) {
      dbsToClose.pop()?.close();
    }
  });

  it('rejects unauthenticated requests with HTTP 401 and includes Helmet security headers', async () => {
    const { db, app } = createTestContext({ seedDefaultDemo: false });
    dbsToClose.push(db);

    const protectedEndpoints = [
      '/api/sleep',
      '/api/study',
      '/api/caffeine',
      '/api/analytics/dashboard',
      '/api/exams',
      '/api/exam-results',
      '/api/settings',
    ];

    for (const path of protectedEndpoints) {
      const res = await request(app).get(path);
      expect(res.status).toBe(401);
      expect(res.headers['x-content-type-options']).toBe('nosniff');
      expect(res.headers['x-powered-by']).toBeUndefined();
    }

    const health = await request(app).get('/api/health');
    expect(health.status).toBe(200);
    expect(health.body.latestMigrationVersion).toBe(4);
  });

  it('registers users with bcrypt hashing, validates login/logout/expiration, and avoids plaintext secrets', async () => {
    const { db, app } = createTestContext({ seedDefaultDemo: false });
    dbsToClose.push(db);

    const reg = await request(app).post('/api/auth/register').send({
      name: 'Alice Chen',
      email: 'alice@college.edu',
      password: 'SecurePassword123!',
    });
    expect(reg.status).toBe(201);
    expect(reg.body.user.email).toBe('alice@college.edu');
    expect(reg.body.token).toBeTypeOf('string');
    expect(reg.body.user.passwordHash).toBeUndefined();
    expect(reg.headers['set-cookie']?.[0]).toContain('HttpOnly');

    // Password in DB must be a bcrypt hash, never plaintext
    const stored = db
      .prepare('SELECT passwordHash FROM users WHERE email = ?')
      .get('alice@college.edu') as { passwordHash: string };
    expect(stored.passwordHash).not.toBe('SecurePassword123!');
    expect(stored.passwordHash.startsWith('$2')).toBe(true);
    expect(await bcrypt.compare('SecurePassword123!', stored.passwordHash)).toBe(true);

    // Duplicate registration returns 409
    const dup = await request(app).post('/api/auth/register').send({
      name: 'Alice Twin',
      email: 'alice@college.edu',
      password: 'AnotherPassword1!',
    });
    expect(dup.status).toBe(409);

    // Wrong password returns 401
    const badLogin = await request(app).post('/api/auth/login').send({
      email: 'alice@college.edu',
      password: 'WrongPassword',
    });
    expect(badLogin.status).toBe(401);

    // Valid login succeeds
    const goodLogin = await request(app).post('/api/auth/login').send({
      email: 'alice@college.edu',
      password: 'SecurePassword123!',
    });
    expect(goodLogin.status).toBe(200);
    const token = goodLogin.body.token as string;

    // Protected route works with Bearer token
    const me = await request(app)
      .get('/api/auth/me')
      .set('Authorization', `Bearer ${token}`);
    expect(me.status).toBe(200);
    expect(me.body.authenticated).toBe(true);

    // Simulate expired session timestamp -> rejected with 401 and session pruned
    db.prepare('UPDATE user_sessions SET expiresAt = ?').run('2000-01-01T00:00:00.000Z');
    const expiredRes = await request(app)
      .get('/api/sleep')
      .set('Authorization', `Bearer ${token}`);
    expect(expiredRes.status).toBe(401);

    // Re-login & test explicit logout invalidates active session
    const reLogin = await request(app).post('/api/auth/login').send({
      email: 'alice@college.edu',
      password: 'SecurePassword123!',
    });
    const freshToken = reLogin.body.token as string;

    await request(app)
      .post('/api/auth/logout')
      .set('Authorization', `Bearer ${freshToken}`)
      .expect(200);

    const afterLogout = await request(app)
      .get('/api/sleep')
      .set('Authorization', `Bearer ${freshToken}`);
    expect(afterLogout.status).toBe(401);
  });

  it('enforces login/registration rate limits, payload size limits, and validation guards', async () => {
    const { db, app } = createTestContext({
      seedDefaultDemo: false,
      enableRateLimit: true,
      authRateLimitMax: 3,
    });
    dbsToClose.push(db);

    // Trigger 3 failed login attempts then verify 4th is rate-limited with 429
    for (let i = 0; i < 3; i++) {
      const r = await request(app).post('/api/auth/login').send({
        email: 'nobody@college.edu',
        password: 'wrongpassword',
      });
      expect(r.status).toBe(401);
    }
    const throttled = await request(app).post('/api/auth/login').send({
      email: 'nobody@college.edu',
      password: 'wrongpassword',
    });
    expect(throttled.status).toBe(429);

    // Register valid user (on fresh limiter app) to verify 400, 404, 409, and 413 payload limits
    const ctx2 = createTestContext({ seedDefaultDemo: false });
    dbsToClose.push(ctx2.db);
    const reg = await request(ctx2.app).post('/api/auth/register').send({
      name: 'Security Tester',
      email: 'sec@college.edu',
      password: 'Password123!',
    });
    const token = reg.body.token as string;

    // Invalid future date -> 400
    await request(ctx2.app)
      .post('/api/sleep')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: '2099-12-31', bedtime: '23:00', wakeTime: '07:00', sleepQuality: 4 })
      .expect(400);

    // Duplicate same-day sleep entry -> 409
    const today = getLocalDateStr(0);
    await request(ctx2.app)
      .post('/api/sleep')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, bedtime: '23:00', wakeTime: '07:00', sleepQuality: 4 })
      .expect(201);
    await request(ctx2.app)
      .post('/api/sleep')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, bedtime: '23:30', wakeTime: '07:30', sleepQuality: 5 })
      .expect(409);

    // Missing resource ID -> 404
    await request(ctx2.app)
      .delete('/api/sleep/999999')
      .set('Authorization', `Bearer ${token}`)
      .expect(404);

    // Oversized body (>256kb) -> 413
    const hugeNotes = 'x'.repeat(300 * 1024);
    const oversized = await request(ctx2.app)
      .post('/api/study')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, subject: 'Math', studyHours: 2, focusRating: 4, notes: hugeNotes });
    expect(oversized.status).toBe(413);

    // Malformed JSON -> 400
    const badJson = await request(ctx2.app)
      .post('/api/study')
      .set('Authorization', `Bearer ${token}`)
      .set('Content-Type', 'application/json')
      .send('{"broken":');
    expect(badJson.status).toBe(400);

    // Environment validation guards against weak SESSION_SECRET or bad PORT
    expect(() => validateEnvironment({ SESSION_SECRET: 'short' })).toThrow();
    expect(() => validateEnvironment({ PORT: '99999' })).toThrow();
  });

  it('strictly isolates sleep, study, caffeine, exams, and analytics across tenants', async () => {
    const { db, app } = createTestContext({ seedDefaultDemo: true });
    dbsToClose.push(db);

    const userA = await request(app).post('/api/auth/register').send({
      name: 'Student A',
      email: 'a@uni.edu',
      password: 'PasswordA1!',
    });
    const userB = await request(app).post('/api/auth/register').send({
      name: 'Student B',
      email: 'b@uni.edu',
      password: 'PasswordB2!',
    });
    const tokenA = userA.body.token as string;
    const tokenB = userB.body.token as string;

    const today = getLocalDateStr(0);
    const sleepA = await request(app)
      .post('/api/sleep')
      .set('Authorization', `Bearer ${tokenA}`)
      .send({
        date: today,
        bedtime: '23:00',
        wakeTime: '07:00',
        sleepQuality: 4,
        notes: 'Private A note',
      });
    expect(sleepA.status).toBe(201);
    const sleepAId = sleepA.body.id as number;

    await request(app)
      .post('/api/study')
      .set('Authorization', `Bearer ${tokenA}`)
      .send({ date: today, subject: 'Secret Thesis', studyHours: 3.5, focusRating: 5 })
      .expect(201);

    await request(app)
      .post('/api/caffeine')
      .set('Authorization', `Bearer ${tokenA}`)
      .send({ date: today, beverageType: 'Coffee', consumptionTime: '09:00', caffeineAmount: 95 })
      .expect(201);

    // User B sees 0 records of User A
    const listSleepB = await request(app)
      .get('/api/sleep')
      .set('Authorization', `Bearer ${tokenB}`);
    expect(listSleepB.status).toBe(200);
    expect(listSleepB.body).toHaveLength(0);

    const listStudyB = await request(app)
      .get('/api/study')
      .set('Authorization', `Bearer ${tokenB}`);
    expect(listStudyB.body).toHaveLength(0);

    const dashB = await request(app)
      .get('/api/analytics/dashboard?days=21')
      .set('Authorization', `Bearer ${tokenB}`);
    expect(dashB.status).toBe(200);
    expect(dashB.body.totalSleepLogs).toBe(0);
    expect(dashB.body.totalStudyLogs).toBe(0);

    // Cross-tenant PUT / DELETE must return 404
    await request(app)
      .put(`/api/sleep/${sleepAId}`)
      .set('Authorization', `Bearer ${tokenB}`)
      .send({ date: today, bedtime: '22:00', wakeTime: '08:00', sleepQuality: 5 })
      .expect(404);

    await request(app)
      .delete(`/api/sleep/${sleepAId}`)
      .set('Authorization', `Bearer ${tokenB}`)
      .expect(404);

    // User A still sees their intact sleep record
    const listSleepA = await request(app)
      .get('/api/sleep')
      .set('Authorization', `Bearer ${tokenA}`);
    expect(listSleepA.body).toHaveLength(1);
    expect(listSleepA.body[0].notes).toBe('Private A note');
  });

  it('supports demo workspace session, 21-day r=+0.78 scenario, settings, and exam rescheduling API', async () => {
    const { db, app } = createTestContext({ seedDefaultDemo: true });
    dbsToClose.push(db);

    const demoAuth = await request(app).post('/api/auth/demo-session');
    expect(demoAuth.status).toBe(200);
    const cookieHeader = demoAuth.headers['set-cookie'];
    expect(cookieHeader).toBeDefined();

    // Baseline 21-day correlation = +0.78
    const dash = await request(app)
      .get('/api/analytics/dashboard?days=21')
      .set('Cookie', cookieHeader);
    expect(dash.status).toBe(200);
    expect(dash.body.correlation.r).toBe(0.78);
    expect(dash.body.correlation.observationCount).toBe(21);

    // Demo Scenario runner adds 8.0h sleep + 4.5h Algorithms 5/5 focus
    const demoRun = await request(app)
      .post('/api/demo/run-scenario')
      .set('Cookie', cookieHeader);
    expect(demoRun.status).toBe(200);
    expect(demoRun.body.correlation.r).toBe(0.78);
    expect(demoRun.body.correlation.observationCount).toBe(22);
    expect(demoRun.body.lastNightSleep.duration).toBe(8);

    // Reset scenario restores clean 21-day baseline
    const demoReset = await request(app)
      .post('/api/demo/reset-scenario')
      .set('Cookie', cookieHeader);
    expect(demoReset.status).toBe(200);
    expect(demoReset.body.correlation.observationCount).toBe(21);

    // Exam generation, feasibility & missed-task rescheduling
    const gen = await request(app)
      .post('/api/exams/generate')
      .set('Cookie', cookieHeader)
      .send({ dailyAvailableHours: 7, preferredWakeTime: '07:30' });
    expect(gen.status).toBe(200);
    expect(gen.body.feasibility.overlapCount).toBe(0);
    expect(gen.body.feasibility.minSleepHours).toBeGreaterThanOrEqual(7);
    expect(gen.body.feasibility.maxDailyStudyHours).toBeLessThanOrEqual(8);

    const feas = await request(app)
      .get('/api/exams/feasibility')
      .set('Cookie', cookieHeader);
    expect(feas.status).toBe(200);
    expect(feas.body.minSleepHours).toBeGreaterThanOrEqual(7);

    const studyTask = (gen.body.tasks as Array<{ id: number; type: string }>).find(
      (t) => t.type === 'study',
    );
    expect(studyTask).toBeDefined();

    const reschedule = await request(app)
      .post('/api/exams/reschedule')
      .set('Cookie', cookieHeader)
      .send({ missedTaskIds: [studyTask!.id], dailyAvailableHours: 7, preferredWakeTime: '07:30' });
    expect(reschedule.status).toBe(200);
    expect(reschedule.body.rescheduledCount).toBe(1);
    expect(reschedule.body.feasibility.overlapCount).toBe(0);

    // Settings update and analytics sub-endpoints
    await request(app)
      .put('/api/settings')
      .set('Cookie', cookieHeader)
      .send({ studentName: 'Maya Updated', sleepBaselineHours: 8, preferredWakeTime: '07:30' })
      .expect(200);

    await request(app)
      .get('/api/analytics/correlation?days=21')
      .set('Cookie', cookieHeader)
      .expect(200);

    await request(app)
      .get('/api/analytics/sleep-debt?days=21')
      .set('Cookie', cookieHeader)
      .expect(200);

    await request(app)
      .get('/api/analytics/weekly-insights?days=21')
      .set('Cookie', cookieHeader)
      .expect(200);

    await request(app)
      .post('/api/analytics/simulate')
      .set('Cookie', cookieHeader)
      .send({ sleepHours: 8, nights: 3, daysWindow: 21 })
      .expect(200);

    // Demo clear and reset lifecycle
    await request(app).post('/api/demo/clear').set('Cookie', cookieHeader).expect(200);
    const clearedDash = await request(app)
      .get('/api/analytics/dashboard?days=21')
      .set('Cookie', cookieHeader)
      .expect(200);
    expect(clearedDash.body.demoCount).toBe(0);

    await request(app).post('/api/demo/reset').set('Cookie', cookieHeader).expect(200);
    const resetDash = await request(app)
      .get('/api/analytics/dashboard?days=21')
      .set('Cookie', cookieHeader)
      .expect(200);
    expect(resetDash.body.correlation.observationCount).toBe(21);
  });

  it('validates and persists full CRUD lifecycles for sleep, study, caffeine, exams, and exam results', async () => {
    const { db, app } = createTestContext({ seedDefaultDemo: false });
    dbsToClose.push(db);

    const reg = await request(app).post('/api/auth/register').send({
      name: 'CRUD Student',
      email: 'crud@uni.edu',
      password: 'Password123!',
    });
    const token = reg.body.token as string;
    const today = getLocalDateStr(0);

    // 1. Sleep CRUD + validation
    await request(app)
      .post('/api/sleep')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, bedtime: '07:00', wakeTime: '07:00', sleepQuality: 4 })
      .expect(400);

    const sCreated = await request(app)
      .post('/api/sleep')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, bedtime: '23:00', wakeTime: '07:00', sleepQuality: 4, notes: 'Good' })
      .expect(201);
    const sUpdated = await request(app)
      .put(`/api/sleep/${sCreated.body.id}`)
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, bedtime: '22:30', wakeTime: '07:00', sleepQuality: 5, notes: 'Great' })
      .expect(200);
    expect(sUpdated.body.duration).toBe(8.5);
    await request(app)
      .delete(`/api/sleep/${sCreated.body.id}`)
      .set('Authorization', `Bearer ${token}`)
      .expect(200);

    // 2. Study CRUD + >24h daily cap guard
    const st1 = await request(app)
      .post('/api/study')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, subject: 'Algorithms', studyHours: 14, focusRating: 5 })
      .expect(201);

    await request(app)
      .post('/api/study')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, subject: 'Physics', studyHours: 11, focusRating: 4 })
      .expect(400); // 14 + 11 > 24h cap

    const stUpdated = await request(app)
      .put(`/api/study/${st1.body.id}`)
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, subject: 'Algorithms II', studyHours: 6, focusRating: 4 })
      .expect(200);
    expect(stUpdated.body.subject).toBe('Algorithms II');
    await request(app)
      .delete(`/api/study/${st1.body.id}`)
      .set('Authorization', `Bearer ${token}`)
      .expect(200);

    // 3. Caffeine CRUD + validation
    await request(app)
      .post('/api/caffeine')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, beverageType: 'Coffee', consumptionTime: '25:99', caffeineAmount: 95 })
      .expect(400);

    const c1 = await request(app)
      .post('/api/caffeine')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, beverageType: 'Coffee', consumptionTime: '09:30', caffeineAmount: 120 })
      .expect(201);
    const cafList = await request(app)
      .get('/api/caffeine')
      .set('Authorization', `Bearer ${token}`)
      .expect(200);
    expect(cafList.body).toHaveLength(1);
    await request(app)
      .delete(`/api/caffeine/${c1.body.id}`)
      .set('Authorization', `Bearer ${token}`)
      .expect(200);

    // 4. Exam Schedule & Timetable Task CRUD with topicDifficulty
    const futureExamDate = getLocalDateStr(5);
    const ex1 = await request(app)
      .post('/api/exams')
      .set('Authorization', `Bearer ${token}`)
      .send({
        examDate: futureExamDate,
        subject: 'Operating Systems',
        topics: 'Threads, Virtual Memory',
        priority: 'High',
        estimatedHours: 8,
        topicDifficulty: 5,
      })
      .expect(201);
    expect(ex1.body.topicDifficulty).toBe(5);

    const exUpdated = await request(app)
      .put(`/api/exams/${ex1.body.id}`)
      .set('Authorization', `Bearer ${token}`)
      .send({
        examDate: futureExamDate,
        subject: 'Operating Systems II',
        topics: 'Concurrency',
        priority: 'Medium',
        estimatedHours: 6,
        topicDifficulty: 4,
      })
      .expect(200);
    expect(exUpdated.body.topicDifficulty).toBe(4);

    const plan = await request(app)
      .post('/api/exams/generate')
      .set('Authorization', `Bearer ${token}`)
      .send({ dailyAvailableHours: 6, preferredWakeTime: '07:30' })
      .expect(200);
    const studyTask = (plan.body.tasks as Array<{ id: number; type: string }>).find(
      (t) => t.type === 'study',
    );
    expect(studyTask).toBeDefined();
    await request(app)
      .put(`/api/exams/plan/${studyTask!.id}`)
      .set('Authorization', `Bearer ${token}`)
      .send({ completed: true })
      .expect(200);

    await request(app)
      .get('/api/exams')
      .set('Authorization', `Bearer ${token}`)
      .expect(200);
    await request(app)
      .get('/api/exams/plan')
      .set('Authorization', `Bearer ${token}`)
      .expect(200);

    await request(app)
      .delete(`/api/exams/${ex1.body.id}`)
      .set('Authorization', `Bearer ${token}`)
      .expect(200);

    // 5. Exam Results CRUD + validation
    await request(app)
      .post('/api/exam-results')
      .set('Authorization', `Bearer ${token}`)
      .send({ subject: 'Calculus', examDate: today, scorePercent: 150 })
      .expect(400);

    const er1 = await request(app)
      .post('/api/exam-results')
      .set('Authorization', `Bearer ${token}`)
      .send({ subject: 'Calculus', examDate: today, scorePercent: 91.5, notes: 'Midterm' })
      .expect(201);
    const erUpdated = await request(app)
      .put(`/api/exam-results/${er1.body.id}`)
      .set('Authorization', `Bearer ${token}`)
      .send({ subject: 'Calculus', examDate: today, scorePercent: 94.0, notes: 'Regraded' })
      .expect(200);
    expect(erUpdated.body.scorePercent).toBe(94);

    const erList = await request(app)
      .get('/api/exam-results')
      .set('Authorization', `Bearer ${token}`)
      .expect(200);
    expect(erList.body).toHaveLength(1);

    await request(app)
      .delete(`/api/exam-results/${er1.body.id}`)
      .set('Authorization', `Bearer ${token}`)
      .expect(200);
  });

  it('validates controller edge inputs, logger secret redaction, production env rules, and sanitized 500 errors', async () => {
    const { redactSensitiveMetadata } = await import('../server/config/logger.ts');

    // Verify nested sensitive fields are masked while operational context remains visible
    const redacted = redactSensitiveMetadata({
      userId: 42,
      password: 'plain-password',
      nested: { token: 'abc', passwordHash: '$2b$10$xyz', safeField: 'ok' },
      headers: [{ authorization: 'Bearer 123', cookie: 'dreamlog_session=xyz' }],
    }) as Record<string, unknown>;
    expect(redacted.userId).toBe(42);
    expect(redacted.password).toBe('[REDACTED]');
    expect((redacted.nested as Record<string, unknown>).token).toBe('[REDACTED]');
    expect((redacted.nested as Record<string, unknown>).passwordHash).toBe('[REDACTED]');
    expect((redacted.nested as Record<string, unknown>).safeField).toBe('ok');
    expect(((redacted.headers as Array<Record<string, unknown>>)[0]).authorization).toBe('[REDACTED]');

    // Verify production environment validation enforces strong non-placeholder SESSION_SECRET
    expect(() =>
      validateEnvironment({ NODE_ENV: 'production', REQUIRE_SESSION_SECRET: 'true' }),
    ).toThrow(/SESSION_SECRET is required/);
    expect(() =>
      validateEnvironment({ NODE_ENV: 'production', SESSION_SECRET: 'my_session_secret' }),
    ).toThrow(/weak placeholder/);
    expect(() =>
      validateEnvironment({ LOG_LEVEL: 'invalid-level' }),
    ).toThrow(/Invalid LOG_LEVEL/);
    expect(() =>
      validateEnvironment({ RATE_LIMIT_MAX: '0' }),
    ).toThrow(/Invalid RATE_LIMIT_MAX/);
    expect(
      validateEnvironment({
        NODE_ENV: 'production',
        REQUIRE_SESSION_SECRET: 'true',
        SESSION_SECRET: '0123456789abcdef0123456789abcdef',
      }).isProduction,
    ).toBe(true);

    // Exhaustive controller validation & 400/404 coverage
    const { db, app } = createTestContext({ seedDefaultDemo: false });
    dbsToClose.push(db);

    const reg = await request(app).post('/api/auth/register').send({
      name: 'Edge Validator',
      email: 'edge@uni.edu',
      password: 'Password123!',
    });
    const token = reg.body.token as string;
    const today = getLocalDateStr(0);
    const yesterday = getLocalDateStr(-1);

    // Sleep invalid inputs
    await request(app)
      .post('/api/sleep')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: '2026-02-30', bedtime: '23:00', wakeTime: '07:00', sleepQuality: 4 })
      .expect(400);
    await request(app)
      .post('/api/sleep')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, bedtime: 'bad', wakeTime: '07:00', sleepQuality: 4 })
      .expect(400);
    await request(app)
      .post('/api/sleep')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, bedtime: '23:00', wakeTime: '07:00', sleepQuality: 6 })
      .expect(400);
    await request(app)
      .put('/api/sleep/abc')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, bedtime: '23:00', wakeTime: '07:00', sleepQuality: 4 })
      .expect(400);
    await request(app)
      .put('/api/sleep/9999')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, bedtime: '23:00', wakeTime: '07:00', sleepQuality: 4 })
      .expect(404);
    await request(app)
      .delete('/api/sleep/not-a-number')
      .set('Authorization', `Bearer ${token}`)
      .expect(400);

    // Sleep update 409 date conflict
    const sToday = await request(app)
      .post('/api/sleep')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, bedtime: '23:00', wakeTime: '07:00', sleepQuality: 4 })
      .expect(201);
    await request(app)
      .post('/api/sleep')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: yesterday, bedtime: '23:00', wakeTime: '07:00', sleepQuality: 4 })
      .expect(201);
    await request(app)
      .put(`/api/sleep/${sToday.body.id}`)
      .set('Authorization', `Bearer ${token}`)
      .send({ date: yesterday, bedtime: '23:00', wakeTime: '07:00', sleepQuality: 4 })
      .expect(409);

    // Study invalid inputs & startTime/endTime auto-duration computation
    await request(app)
      .post('/api/study')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: '2099-01-01', subject: 'Math', studyHours: 2, focusRating: 4 })
      .expect(400);
    await request(app)
      .post('/api/study')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, subject: '', studyHours: 2, focusRating: 4 })
      .expect(400);
    await request(app)
      .post('/api/study')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, subject: 'Math', studyHours: 20, focusRating: 4 })
      .expect(400);
    await request(app)
      .post('/api/study')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, subject: 'Math', studyHours: 2, focusRating: 9 })
      .expect(400);
    const autoDurStudy = await request(app)
      .post('/api/study')
      .set('Authorization', `Bearer ${token}`)
      .send({
        date: today,
        subject: 'Compilers',
        startTime: '09:00',
        endTime: '12:30',
        focusRating: 5,
      })
      .expect(201);
    expect(autoDurStudy.body.studyHours).toBe(3.5);
    await request(app)
      .put('/api/study/invalid')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, subject: 'Compilers', studyHours: 2, focusRating: 4 })
      .expect(400);
    await request(app)
      .put('/api/study/9999')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, subject: 'Compilers', studyHours: 2, focusRating: 4 })
      .expect(404);
    await request(app)
      .delete('/api/study/9999')
      .set('Authorization', `Bearer ${token}`)
      .expect(404);

    // Caffeine invalid inputs
    await request(app)
      .post('/api/caffeine')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: '2099-01-01', beverageType: 'Coffee', consumptionTime: '09:00', caffeineAmount: 90 })
      .expect(400);
    await request(app)
      .post('/api/caffeine')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, beverageType: 'Soda', consumptionTime: '09:00', caffeineAmount: 90 })
      .expect(400);
    await request(app)
      .post('/api/caffeine')
      .set('Authorization', `Bearer ${token}`)
      .send({ date: today, beverageType: 'Tea', consumptionTime: '09:00', caffeineAmount: 2000 })
      .expect(400);
    await request(app)
      .delete('/api/caffeine/bad-id')
      .set('Authorization', `Bearer ${token}`)
      .expect(400);
    await request(app)
      .delete('/api/caffeine/9999')
      .set('Authorization', `Bearer ${token}`)
      .expect(404);

    // Exam & task & analytics simulate validation
    await request(app)
      .post('/api/exams')
      .set('Authorization', `Bearer ${token}`)
      .send({ examDate: 'bad', subject: 'Bio', priority: 'High' })
      .expect(400);
    await request(app)
      .post('/api/exams')
      .set('Authorization', `Bearer ${token}`)
      .send({ examDate: getLocalDateStr(5), subject: 'Bio', priority: 'Urgent' })
      .expect(400);
    await request(app)
      .delete('/api/exams/9999')
      .set('Authorization', `Bearer ${token}`)
      .expect(404);
    await request(app)
      .put('/api/exams/plan/9999')
      .set('Authorization', `Bearer ${token}`)
      .send({ completed: true })
      .expect(404);
    await request(app)
      .post('/api/analytics/simulate')
      .set('Authorization', `Bearer ${token}`)
      .send({ sleepHours: 2, nights: 3 })
      .expect(400);
    await request(app)
      .post('/api/analytics/simulate')
      .set('Authorization', `Bearer ${token}`)
      .send({ sleepHours: 8, nights: 99 })
      .expect(400);

    // Production 500 error sanitization (never leaks SQLite table/constraint internals to clients)
    process.env.NODE_ENV = 'production';
    db.exec('DROP TABLE sleep_logs');
    const prodErrRes = await request(app)
      .get('/api/sleep')
      .set('Authorization', `Bearer ${token}`);
    expect(prodErrRes.status).toBe(500);
    expect(prodErrRes.body.error).toBe('Internal server error.');
    expect(JSON.stringify(prodErrRes.body)).not.toContain('no such table');
  });
});

