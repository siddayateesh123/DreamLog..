# Architecture Overview — DreamLog – SnoozeScience

## 1. High-Level Three-Tier Architecture

DreamLog enforces a strict separation between presentation, pure mathematical domain rules, API controllers, business services, data repositories, and SQLite configuration:

```text
┌────────────────────────────────────────────────────────────────────────────┐
│ Tier 1: Presentation Layer (React 19 + TypeScript + Tailwind v4 + Chart.js)│
│  src/App.tsx (ErrorBoundary, React.lazy views, AuthModal, /#verify routing)│
│  ├── Views: LandingPage, DashboardView, SleepTrackerView, StudyTrackerView │
│  ├── Analytics: AnalyticsView (Sleep Shift Simulator), SleepDebtView       │
│  ├── Labs: BedtimeView, CaffeineView, ExamPlannerView, ReportsView         │
│  ├── Verification: VerificationView (/#verify live self-tests)             │
│  └── Client: src/api/client.ts (typed REST client, credentials: 'include') │
└──────────────────────────────────────┬─────────────────────────────────────┘
                                       │ Zero Duplicated Domain Logic
                                       ▼
┌────────────────────────────────────────────────────────────────────────────┐
│ Shared Pure Domain Engine (src/shared/)                                    │
│  ├── src/shared/types.ts     (strict domain interfaces & DTOs)             │
│  ├── src/shared/math.ts      (Pearson r, OLS, Simulator, Sleep Debt,       │
│  │                            90-min Cycles, Caffeine t1/2, Constraint     │
│  │                            Exam Scheduler + Feasibility + Rescheduler)  │
│  └── src/shared/pdfReport.ts (testable jsPDF Wellness Report builder)      │
└──────────────────────────────────────┬─────────────────────────────────────┘
                                       │ REST JSON (/api/*)
                                       ▼
┌────────────────────────────────────────────────────────────────────────────┐
│ Tier 2 & 3: Express Backend & SQLite Persistence (server.ts + server/)     │
│  ├── server.ts            (Env validation, port 3000, Vite/dist, shutdown) │
│  ├── server/app.ts        (Helmet, rate limits, body limits, routes, errors│
│  ├── server/config/       (env.ts, database.ts PRAGMAs, logger.ts Winston) │
│  ├── server/middleware/   (authMiddleware.ts, requestLogger.ts)            │
│  ├── server/controllers/  (validation.ts + 7 resource controllers)         │
│  ├── server/services/     (authService, analyticsService,                  │
│  │                         examPlannerService, demoSeedService)            │
│  ├── server/repositories/ (user, sleep, study, caffeine, exam repositories)│
│  └── server/db/           (migrations.ts transactional v1–v4 + rollback)   │
└────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Backend Layer Responsibilities

- **Configuration (`server/config/`):**
  - `env.ts`: Validates `PORT`, `LOG_LEVEL`, `SESSION_SECRET` (rejects `<16` chars and weak placeholder strings; requires explicit `SESSION_SECRET` in production when `REQUIRE_SESSION_SECRET=true`, otherwise falls back to a runtime CSPRNG secret), `RATE_LIMIT_MAX`, and `AUTH_RATE_LIMIT_MAX`.
  - `database.ts`: Initializes SQLite via `better-sqlite3` (`journal_mode = DELETE`, `wal_checkpoint(TRUNCATE)`, `busy_timeout = 5000`, `foreign_keys = ON`) so `data/dreamlog.db` remains clean with no leftover `-wal`/`-shm` sidecar files.
  - `logger.ts`: Configures Winston structured logging with timestamps, dev/prod formatting, and recursive redaction of sensitive keys.
- **Middleware (`server/middleware/`):**
  - `requestLogger.ts`: Logs HTTP method, route, status code, duration (ms), and authenticated `userId` (never tokens or cookies).
  - `authMiddleware.ts`: Extracts `Authorization: Bearer` or `HttpOnly` `dreamlog_session` cookie tokens, validates SHA-256 HMAC token hashes against `user_sessions`, enforces expiration, and returns `401` on unauthorized access.
- **Controllers (`server/controllers/`):**
  - Validate request payloads via shared helpers in `validation.ts` (`validateSleepPayload`, `validateStudyPayload`, `parseDaysWindow`, ISO date/time checks, positive integer IDs).
  - Forward unexpected async errors via `next(err)` (`authController.ts`) to Express's centralized `/api` error middleware.
  - Wrap multi-table write + `daily_metrics` rebuild operations inside atomic `db.transaction(...)` blocks (`sleepController.ts`, `studyController.ts`).
- **Services (`server/services/`):**
  - `authService.ts`: Password hashing (`bcryptjs`), credential verification, session token issuance/revocation.
  - `analyticsService.ts`: Rebuilds materialized `daily_metrics` rows, joins sleep/study/caffeine histories, builds rolling windows (`7`/`14`/`21`/`30`), generates data-driven insights, and correlates 3-night pre-exam sleep with exam scores.
  - `examPlannerService.ts`: Invokes `generateProtectiveExamTimetable` and `rescheduleMissedExamTasks` and persists timetables atomically.
  - `demoSeedService.ts`: Deterministically seeds/resets the 21-day baseline dataset (`r = +0.78`), 3 upcoming exams, initial timetable, and 3 completed exam results.
- **Repositories (`server/repositories/`):**
  - Parameterized SQL queries only (`?` placeholders) — zero SQL interpolation.
  - Every table query filters explicitly by `userId` to prevent cross-tenant access.

---

## 3. Database Schema & Version-Controlled Migrations (`server/db/migrations.ts`)

| Version | Migration ID | Summary | Rollback Strategy |
|---|---|---|---|
| **v1** | `001_initial_core_tables` | Creates `sleep_logs`, `study_logs`, `daily_metrics`, `caffeine_logs`, `exam_schedules`, `exam_plan_tasks`, `exam_results`, `user_settings`. | Drops tables in reverse dependency order inside a transaction. |
| **v2** | `002_auth_users_and_sessions` | Creates `users` and `user_sessions` (with `FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE`) and provisions the isolated Demo Student (`id = 1`). | Drops `user_sessions` and `users`. |
| **v3** | `003_multi_tenant_user_scoping` | Safely upgrades single-tenant rows into per-user records (`userId DEFAULT 1`), adds `schedulingReason` to `exam_plan_tasks`, and upgrades `user_settings` & `daily_metrics` to composite `(userId, date)` keys without data loss. | Rebuilds single-tenant schema preserving `userId = 1` rows. |
| **v4** | `004_exam_topic_difficulty_and_session_expiry_index` | Adds `topicDifficulty` (`1–5`, default `3`) to `exam_schedules` and adds `idx_user_sessions_expiresAt`. | Drops index and rebuilds `exam_schedules` without `topicDifficulty`. |

---

## 4. Constraint-Based Exam Scheduler (`src/shared/math.ts`)

- **Inputs:** Upcoming exam dates, subject priority (`High = 3.0`, `Medium = 1.8`, `Low = 1.0`), topic difficulty (`1–5`, multiplier `0.90x–1.50x`), estimated study hours, user daily available hours, completed study blocks, and missed tasks.
- **Hard Constraints Enforced:**
  - Maximum **8.0h/day** study duration.
  - Minimum **7.0h/night** (`7.5h` reserved) sleep window anchored to `preferredWakeTime`.
  - Non-overlapping wake-relative intervals across Breakfast, Lunch, Dinner, 15-minute circadian breaks, study blocks, and sleep (including overnight midnight crossings).
  - Strict exam deadline ceiling (`examDate >= scheduledDate`).
- **Impossible Schedule Detection:** Evaluates cumulative requested hours at every exam milestone (`cumulativeRequested <= daysToDeadline * safeDaily`). Flags explicit impossible deadline bottlenecks while continuing to enforce the 7h sleep and 8h study safety floor.
