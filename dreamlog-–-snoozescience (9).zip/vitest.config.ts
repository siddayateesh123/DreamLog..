import path from 'path';
import { defineConfig } from 'vitest/config';

export default defineConfig({
  resolve: {
    alias: {
      '@': path.resolve(process.cwd(), '.'),
    },
  },
  test: {
    environment: 'node',
    globals: false,
    include: ['tests/**/*.test.ts'],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'json-summary'],
      include: ['src/shared/**/*.ts', 'server/**/*.ts'],
      exclude: ['server.ts', 'server/analytics.ts', 'server/db.ts', 'src/shared/types.ts'],
      thresholds: {
        statements: 85,
        branches: 72,
        functions: 95,
        lines: 85,
      },
    },
  },
});
