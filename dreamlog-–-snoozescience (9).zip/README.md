# DreamLog – SnoozeScience

**DreamLog – SnoozeScience** is a full-stack student sleep and academic productivity analytics platform built with React 19, TypeScript, Tailwind CSS v4, Chart.js, Express, and SQLite (`better-sqlite3`). Designed for college students who trade rest for extra study hours, DreamLog tracks nightly sleep across midnight boundaries, subject-wise study sessions, daily focus ratings, caffeine clearance, exam results, and exam-week schedules to compute empirical **Sleep–Productivity Correlation** ($r$) with Ordinary Least Squares (OLS) regression, cumulative **Sleep Debt**, and data-driven **Weekly Optimization Insights**.

---

## Evaluate in 3 Steps

1. **Run the Demo Scenario (≤ 2 clicks from Landing Page):**
   Click **Run Demo Scenario** on the Landing Page (or in the Dashboard toolbar). DreamLog initializes an authenticated workspace session, sends `POST /api/demo/run-scenario` logging `11:30 PM → 7:30 AM` (`8.0h`, 4 stars) plus `4.5h` of `Algorithms` at `"5/5 - Deep Focus"`, recalculates the 21-day dataset, highlights today's new scatter point, and updates the correlation to **`r = +0.78` ("Strong Positive Correlation")**. Use **Reset demo** anytime to restore the baseline 21-day seed.
2. **Simulate an 8-Hour Sleep Shift (Analytics):**
   Open **Analytics** → **Sleep Shift Simulator**. Adjust target sleep hours (default `8.0h`) and upcoming nights (default `3`). Without mutating stored logs, `POST /api/analytics/simulate` projects predicted focus from your current OLS fit and plots both the **Current OLS** and **Projected OLS** trendlines side-by-side with before/after $r$ and slope deltas.
3. **Verify Mathematics & Export the Wellness Report:**
   Open **System Verification** (`/#verify` from the landing footer or sidebar footer) to execute live unit and REST API assertions against `src/shared/math.ts` and SQLite. Then visit **Labs → Wellness Reports** to inspect the **Sleep vs Exam Performance** correlation table and download a multi-section client-side PDF with embedded Chart.js canvas snapshots.

---

## Three-Tier Architecture

DreamLog enforces a clean three-tier separation between presentation, shared pure domain math, controllers, services, repositories, and SQLite configuration:

```text
┌───────────────────────────────────────────────────────────────────────────┐
│ Tier 1: Frontend Presentation Layer (React 19 + TypeScript + Chart.js)    │
│  src/App.tsx (ErrorBoundary, React.lazy views, AuthModal, Labs, /#verify) │
│  ├── LandingPage, AuthModal, DashboardView, SleepTrackerView, StudyTracker │
│  ├── AnalyticsView (Sleep Shift Simulator), SleepDebtView                 │
│  ├── Labs: BedtimeView, CaffeineView, ExamPlannerView, ReportsView        │
│  ├── VerificationView (/#verify live self-tests & compliance matrix)      │
│  └── src/api/client.ts (typed REST client with credentials: 'include')    │
└─────────────────────────────────────┬─────────────────────────────────────┘
                                      │ Shared Pure Logic (Zero Duplication)
                                      ▼
┌───────────────────────────────────────────────────────────────────────────┐
│ Shared Mathematical & Domain Engine (src/shared/math.ts, src/shared/types)│
│  Pearson r, OLS fit, Sleep Shift Simulator, Hour-Weighted Focus,          │
│  Sleep Debt, 90-min Cycles, Caffeine Half-Life, Protective Exam Scheduler │
│  & Missed-Task Rescheduler + Feasibility Validator                        │
└─────────────────────────────────────┬─────────────────────────────────────┘
                                      │ REST JSON (/api/*)
                                      ▼
┌───────────────────────────────────────────────────────────────────────────┐
│ Tier 2 & 3: Express Backend + Clean Layering (server.ts & server/)        │
│  ├── server.ts            (HTTP server, port 3000, Vite/dist, shutdown)   │
│  ├── server/app.ts        (Express wiring, cookies, routes, error handler)│
│  ├── server/config/       (database.ts SQLite PRAGMAs, logger.ts Winston) │
│  ├── server/middleware/   (authMiddleware.ts, requestLogger.ts)           │
│  ├── server/controllers/  (validation + HTTP req/res orchestration)       │
│  ├── server/services/     (authService, analyticsService,                 │
│  │                         examPlannerService, demoSeedService)           │
│  ├── server/repositories/ (userRepository, sleepRepository,               │
│  │                         studyRepository, caffeineRepository,           │
│  │                         examRepository — strictly userId-scoped)       │
│  └── server/db/           (migrations.ts transactional v1–v3 + rollback)  │
└───────────────────────────────────────────────────────────────────────────┘
```

### Structured Logging (`server/config/logger.ts`)
- Built with **Winston** (`winston`), logging server lifecycle events, HTTP request timings (`requestLogger.ts`), validation errors (`4xx`), database errors, and unhandled API exceptions (`5xx`).
- Development mode uses readable colored timestamps (`YYYY-MM-DD HH:mm:ss`); production emits structured JSON logs (`LOG_LEVEL` configurable via `.env`).
- Recursive metadata redaction automatically masks `password`, `passwordHash`, `token`, `tokenHash`, `authorization`, `cookie`, `secret`, and `sessionSecret` fields.

---

## Installation & Environment Variables

### Prerequisites
- Node.js `>= 20` and npm

### Setup & Local Run
```bash
npm install
npm run lint      # TypeScript strict check (tsc --noEmit)
npm run test      # Automated Vitest + Supertest suite
npm run build     # Production Vite bundle (dist/)
npm run dev       # Express + Vite middleware on http://0.0.0.0:3000
```

### Environment Variables (`.env.example`)
- `NODE_ENV`: Runtime mode (`development` for local work, `production` for deployed builds).
- `PORT`: HTTP server port (defaults to `3000`).
- `APP_URL`: Public host URL when deployed behind a proxy.
- `GEMINI_API_KEY`: Optional runtime secret if external AI integrations are enabled.
- `SESSION_SECRET`: Signing secret (`>= 16` chars, non-placeholder) for HMAC-SHA256 session tokens. In local development, leave empty to auto-generate a cryptographically random ephemeral secret at process boot (`crypto.randomBytes(32)`).
- `REQUIRE_SESSION_SECRET`: Recommended `true` in production deployments (`REQUIRE_SESSION_SECRET=true`) so startup aborts immediately if `SESSION_SECRET` is missing.
- `RATE_LIMIT_MAX` / `AUTH_RATE_LIMIT_MAX`: 15-minute API (`600`) and `/api/auth/{login,register}` (`25`) request ceilings.
- `LOG_LEVEL`: Winston log verbosity (`info`, `debug`, `warn`, `error`; defaults to `info`).

---

## Authentication & Multi-Tenancy

DreamLog supports multi-user workspaces alongside a zero-friction Demo Student workspace:
- **Password Hashing:** User passwords are salted and hashed with **bcryptjs** (`bcrypt.hash` with cost factor `10`). Plaintext passwords are never stored, returned in responses, or logged.
- **Session Tokens & Cookies:** Sessions issue cryptographically random tokens (`crypto.randomBytes(32)`), storing only HMAC-SHA256 hashes (`tokenHash`) in `user_sessions` with a 7-day sliding TTL. Tokens are delivered via `HttpOnly; SameSite=Lax; Path=/` cookies (`dreamlog_session`) and also accepted via `Authorization: Bearer <token>`.
- **Route Protection (`requireAuth`):** Every user resource endpoint (`/api/sleep`, `/api/study`, `/api/analytics/*`, `/api/caffeine`, `/api/exams/*`, `/api/exam-results`, `/api/settings`, `/api/demo/*`) requires an authenticated session (`401 Unauthorized` otherwise).
- **Tenant Isolation:** Every database query in `server/repositories/*` filters explicitly by `req.authUser.id` (`WHERE userId = ?`), preventing cross-tenant read, update, or deletion access.
- **Seamless Demo Entry:** Entering **Workspace**, clicking **Run Demo Scenario**, or visiting **System Verification** automatically initializes the isolated Demo Student workspace (`POST /api/auth/demo-session`) if no custom user is signed in. Users can register/sign in anytime via **Sign In / Switch Account**.

---

## Security & Hardening Summary

- **HTTP & Transport Security (`server/app.ts`):** Uses `helmet` (`X-Content-Type-Options: nosniff`, `Referrer-Policy`, `Strict-Transport-Security`, disabled `X-Powered-By`), `trust proxy`, and `256kb` JSON/URL-encoded body size limits (`HTTP 413` on oversized requests).
- **Rate Limiting:** `express-rate-limit` throttles general `/api/*` traffic (`600 / 15m`) and enforces strict login/registration limits (`25 / 15m` → `HTTP 429`).
- **Authentication & Sessions:** `bcryptjs` password hashing (`cost = 10`), HMAC-SHA256 hashed 256-bit tokens stored in `user_sessions` (7-day expiry), `HttpOnly; SameSite=Lax` cookies (`secure: true` on HTTPS), and strict `userId` isolation across every repository query.
- **Environment & Error Safety:** `server/config/env.ts` validates `PORT`, `LOG_LEVEL`, `SESSION_SECRET` (rejects placeholders/weak strings and enforces presence when `REQUIRE_SESSION_SECRET=true` in production), and rate-limit settings on boot. Production `500` errors withhold internal details and stack traces from API responses while Winston logs sanitized diagnostics server-side. See [SECURITY.md](./SECURITY.md) for full details.

---

## Database Migrations & SQLite Storage (`server/db/migrations.ts`)

DreamLog stores data in a single clean SQLite file at `data/dreamlog.db` configured with `journal_mode = DELETE`, `busy_timeout = 5000`, and `foreign_keys = ON` (avoiding leftover `-wal`/`-shm` sidecars; `data/` and `*.db*` are ignored in `.gitignore`).

Schema changes execute transactionally through the version-controlled `schema_migrations` registry (`runMigrations(db)` / `rollbackLastMigration(db)`):

| Version | Migration ID | Changes Applied | Rollback Strategy |
|---|---|---|---|
| **v1** | `001_initial_core_tables` | Creates core tables (`sleep_logs`, `study_logs`, `daily_metrics`, `caffeine_logs`, `exam_schedules`, `exam_plan_tasks`, `exam_results`, `user_settings`). | Drops core tables in reverse order inside a transaction. |
| **v2** | `002_auth_users_and_sessions` | Creates `users` and `user_sessions` (`ON DELETE CASCADE`), token/user indexes, and provisions the isolated Demo Student (`id = 1`, `demo@dreamlog.local`). | Drops `user_sessions` and `users`. |
| **v3** | `003_multi_tenant_user_scoping` | Migrates existing single-tenant records without data loss: adds `userId` foreign keys (`DEFAULT 1`), `schedulingReason` on `exam_plan_tasks`, and upgrades `user_settings` & `daily_metrics` to per-user keys (`(userId, date)` composite PK). | Rebuilds legacy single-tenant tables (`userId = 1` rows preserved) cleanly within a transaction. |
| **v4** | `004_exam_topic_difficulty_and_session_expiry_index` | Adds `topicDifficulty` (`1–5`, default `3`) to `exam_schedules` and `idx_user_sessions_expiresAt` index. | Drops index and rebuilds `exam_schedules` without `topicDifficulty`. |

---

## Automated Testing & Coverage (`npm run test` / `npm run test:coverage`)

Automated tests run via **Vitest v5.1.1**, **Supertest**, and **`@vitest/coverage-v8`** (`vitest.config.ts`, `tests/`) with enforced thresholds (`85%` statements/lines, `95%` functions, `72%` branches):

| Test Suite | Coverage |
|---|---|
| `tests/math.test.ts` | **33 unit tests** covering all mathematical, analytics & scheduling domains: `calculateSleepDuration` (normal, midnight crossing, equal times, invalid HH:mm), Pearson correlation (`+1`, `-1`, `0`, zero variance, $n < 7$ guard, missing/unpaired dates), OLS regression (slopes, constant/insufficient data, clipped `[1, 5]` accuracy), Sleep Debt (deficits, surpluses, 7d missing nights excluded, UTC leap/DST boundaries), Caffeine half-life (single/multi-dose, elapsed times, midnight crossing), 90-min bedtime cycles, Sleep Shift Simulator, Hour-weighted focus, `rebuildDailyMetricsForUser` + Weekly Insights, Exam Performance ($n\ge 5$ pre-exam sleep lookback), and Exam Preserver (`>=7h` sleep, `<=8h/day` study, zero overlaps, priority + `topicDifficulty` + deadline urgency, impossible deadline detection, missed-task rescheduling). |
| `tests/migrations.test.ts` | **4 database tests** verifying `v1 → v4` migrations & rollback, legacy `v1 → v4` zero-data-loss upgrade, foreign key constraints & atomic transaction rollback, and disk SQLite persistence across restarts. |
| `tests/api.integration.test.ts` | **7 end-to-end Supertest tests** verifying `401` guards, Helmet headers, `bcryptjs` hashing + session expiration + logout, login/register `429` rate limits, `256kb` payload limits (`413`), malformed JSON (`400`), `REQUIRE_SESSION_SECRET=true` & Winston redaction, production `500` error masking, strict cross-tenant isolation, live Demo Scenario (`r = +0.78`), Exam rescheduling, and exhaustive controller validation & CRUD persistence. |
| `tests/pdf.test.ts` | **2 PDF tests** generating real `jsPDF` binary documents (`%PDF-`) and verifying all required report sections, empty/missing-data resilience, and multi-page pagination. |

```bash
npm install
npm run lint           # TypeScript strict check (tsc --noEmit)
npm run test           # 46/46 automated tests
npm run test:coverage  # V8 code coverage (91.92% Stmts / 92.73% Lines)
npm run build          # Production Vite bundle (dist/)
npm run dev            # Start Express + Vite server on port 3000
```

---

## Additional Engineering Documentation

- [ARCHITECTURE.md](./ARCHITECTURE.md) — Three-tier architecture, transaction boundaries, migrations, and constraint scheduler
- [SECURITY.md](./SECURITY.md) — Helmet, rate limiting, cookies, environment validation, SQLi & multi-tenancy controls
- [REQUIREMENTS_TRACEABILITY.md](./REQUIREMENTS_TRACEABILITY.md) — End-to-end FSD traceability matrix
- [TEST_REPORT.md](./TEST_REPORT.md) — Executed Vitest results and V8 coverage breakdown


## Statistical Formulas & Mathematical Engine

- **Overnight Midnight Crossing:** Converts `HH:mm` into minutes; when `wakeMin < bedMin`, adds `1440` minutes (`24h`). Equal timestamps return `0` and are rejected by API validation.
- **Hour-Weighted Daily Focus:** $\bar{F}_d = \frac{\sum (h_i \cdot f_i)}{\sum h_i}$ so short sessions never distort multi-hour deep-focus days.
- **Pearson Correlation ($r$) & OLS Regression:** Evaluates paired days having both `sleep > 0h` and `studySessions > 0`. Enforces $n \ge 7$ paired observations (`CONFIDENCE_WARNING_TEXT` otherwise) and guards zero variance ($\sum (x_i - \bar{x})^2 < 10^{-9}$ or $\sum (y_i - \bar{y})^2 < 10^{-9}$ → `"Undefined (Zero Variance)"` with no trendline). Clipped OLS endpoints solve exact intercept intersections on `[minY, maxY]` and normalize `-0` values.
- **Sleep Debt:** Evaluates the exact 7-calendar-day reporting window (`[today - 6d .. today]`). Daily deficit $\max(0, B - S_d)$ and surplus $\max(0, S_d - B)$ are accumulated separately so surpluses never mask deficits, and unlogged nights are excluded rather than treated as `0h`.
- **90-Minute Bedtime Cycles:** Evaluates `6, 5, 4, 3` cycles (`9.0h, 7.5h, 6.0h, 4.5h` asleep), subtracting `90 * cycles + sleepLatencyMinutes` from target wake time.
- **Caffeine Half-Life Model:** Single-compartment exponential decay $C(t) = \sum C_{0,i} \cdot 0.5^{\Delta t_i / t_{1/2}}$ through target bedtime (handles midnight wrap).
- **Exam Week Sleep Preserver:** Scores backlog demand by priority weight (`High = 3.0`, `Medium = 1.8`, `Low = 1.0`) and deadline proximity urgency (`1 / max(1, daysRemaining)`), interleaves heavy subjects to limit cognitive fatigue, reserves meals + recovery breaks with zero overlap, guarantees `>= 7h` sleep every night and `<= 8h/day` study, supports dynamic missed-task rescheduling (`POST /api/exams/reschedule`), and reports transparent scheduling explanations (`decisions[]`, `schedulingReason`, `ScheduleFeasibilityReport`).

---

## Project Requirements Mapping

| Brief Requirement | Implementation (`server/` & `src/shared/`) | UI Location |
|---|---|---|
| Nightly Sleep Logger (midnight wrap, 1–5 quality) | `calculateSleepDuration` (`src/shared/math.ts`), `sleepController.ts` / `sleepRepository.ts` | **Sleep Tracker** & Quick `+ Sleep` modal |
| Study Tracker (subjects, hours, 1–5 focus) | `computeWeightedFocus` (`src/shared/math.ts`), `studyController.ts` / `studyRepository.ts` | **Study Tracker** & Quick `+ Study` modal |
| Pearson $r$ & Interactive Scatter + OLS Trendline | `computePearsonAndOLSFromPoints` (`src/shared/math.ts`), `SleepFocusScatterChart` | **Dashboard** & **Analytics** |
| Under-7-day statistical confidence badge | `CONFIDENCE_WARNING_TEXT` (`n < 7` → `r = null`) | **Dashboard** & **Analytics** |
| Sleep Shift Simulator (before/after curve) | `simulateSleepShift` (`src/shared/math.ts`), `POST /api/analytics/simulate` | **Analytics → Sleep Shift Simulator** |
| Sleep Debt Calculator (weekly deficit vs baseline) | `computeSleepDebtMetrics` (`src/shared/math.ts`), `SleepDebtBarChart` | **Sleep Debt** |
| Weekly Optimization Insights | `buildDashboardAnalytics` (`server/services/analyticsService.ts`) | **Dashboard** & **Analytics** |
| Optimal Bedtime Recommender (90-min cycles) | `calculateBedtimeCycles` (`src/shared/math.ts`) | **Labs → Optimal Bedtime Recommender** |
| Caffeine half-life clearance overlay | `calculateRemainingCaffeine`, `estimateBedtimeCaffeine` (`src/shared/math.ts`) | **Labs → Caffeine Tracker** |
| Exam Week Sleep Preserver + Missed Rescheduling | `generateProtectiveExamTimetable`, `rescheduleMissedExamTasks`, `validateScheduleFeasibility` | **Labs → Exam Week Sleep Preserver** |
| Exportable PDF + Sleep vs Exam Performance | `computeExamPerformanceAnalysis`, lazy `jsPDF` (`src/components/ReportsView.tsx`) | **Labs → Wellness Reports** |
| Multi-Tenant Auth & Scoped Persistence | `authService.ts`, `authMiddleware.ts`, `userRepository.ts`, `migrations.ts` | **Header / Sidebar → Sign In / Switch Account** |
| 21-day Demo Seed + Clear / Restore Controls | `demoSeedService.ts`, `POST /api/demo/clear`, `POST /api/demo/reset` | **Settings** & Top Banner |
| In-App Self-Test & Compliance Matrix | `VerificationView` (`src/components/VerificationView.tsx`) | **System Verification** (`/#verify`) |

---

## Known Limitations

- Caffeine clearance uses a uniform single-compartment exponential half-life approximation rather than individualized CYP1A2 metabolism kinetics.
- Statistical confidence requires at least 7 paired sleep-study days (and at least 5 completed exams for the **Sleep vs Exam Performance** $r$ metric; 3 past exams are seeded out of the box so the threshold behavior is immediately demonstrable).
- PDF wellness exports render snapshots on the client browser via `jsPDF` + Chart.js canvas data URLs rather than a headless server-side PDF generator.
