# Automated Test & Coverage Report — DreamLog – SnoozeScience

## 1. Execution Command & Environment

- **Test Runner:** Vitest `v5.1.1` with `@vitest/coverage-v8` and `supertest` `v7.3.2`
- **Enforced Coverage Thresholds (`vitest.config.ts`):** `85%` statements, `85%` lines, `95%` functions, `72%` branches
- **Verification Commands:**
  - `npm install`
  - `npm run lint` (`tsc --noEmit`)
  - `npm run test` (`vitest run`)
  - `npm run test:coverage` (`vitest run --coverage`)
  - `npm run build` (`vite build`)

---

## 2. Verified Test Suite Results (`vitest run --coverage`)

| Test File | Tests Executed | Passed | Failed | Scope Covered |
|---|---|---|---|---|
| `tests/math.test.ts` | 33 | 33 | 0 | Sleep duration & midnight wrapping, Pearson $r$, OLS slope/clipping, zero-variance & $n<7$ guards, Sleep Debt & UTC boundaries, Caffeine $t_{1/2}$, 90-min bedtime cycles, Sleep Shift Simulator, Hour-weighted focus, study time-range wraps, Exam Performance ($n\ge 5$ + 3-night sleep lookback), `rebuildDailyMetricsForUser` SQLite persistence & Weekly Optimization Insights, and Exam Week Sleep Preserver constraints |
| `tests/api.integration.test.ts` | 7 | 7 | 0 | Unauthenticated `401` guards, Helmet headers, `bcryptjs` hashing + session expiration + logout, `/api/auth/*` rate limiting (`429`), 256 KB body limit (`413`), malformed JSON (`400`), `REQUIRE_SESSION_SECRET=true` & placeholder env guards, Winston secret redaction, production `500` error masking, strict cross-tenant isolation, 21-day Demo Scenario (`r = +0.78`), Exam rescheduling, and exhaustive controller validation + CRUD persistence |
| `tests/migrations.test.ts` | 4 | 4 | 0 | Fresh `v1 → v4` migrations & `v4` rollback, legacy `v1 → v4` zero-data-loss upgrade, SQLite foreign-key enforcement & atomic transaction rollback, disk persistence across close/reopen without `-wal` sidecars |
| `tests/pdf.test.ts` | 2 | 2 | 0 | Real `jsPDF` Wellness Report binary generation (`%PDF-`), all required sections, empty/missing-data safety, and multi-page pagination |
| **Total** | **46** | **46** | **0** | **100% pass rate across all 4 test files** |

---

## 3. Verified Code Coverage Summary (`@vitest/coverage-v8`)

Measured across critical domain logic (`src/shared/**/*.ts`) and server modules (`server/**/*.ts`, excluding entrypoint `server.ts` and thin compatibility facades):

| Module / Layer | Statements | Branches | Functions | Lines |
|---|---|---|---|---|
| `src/shared` (`math.ts`, `pdfReport.ts`) | **91.93%** | 75.93% | **98.76%** | **93.32%** |
| `server/services` (`analytics`, `auth`, `demoSeed`, `examPlanner`) | **96.27%** | 81.46% | **100.00%** | **96.84%** |
| `server/repositories` (`user`, `sleep`, `study`, `caffeine`, `exam`) | **95.86%** | 70.42% | **100.00%** | **100.00%** |
| `server/middleware` (`authMiddleware`, `requestLogger`) | **95.34%** | 85.18% | **100.00%** | **95.23%** |
| `server/app.ts` | **97.72%** | 81.48% | **100.00%** | **97.72%** |
| `server/config` (`database.ts`, `env.ts`, `logger.ts`) | **87.83%** | 81.69% | **88.88%** | **87.32%** |
| `server/controllers` (`validation` + 7 REST controllers) | **87.10%** | 78.52% | **98.46%** | **86.93%** |
| `server/db/migrations.ts` | **80.76%** | 40.62% | **84.21%** | **82.19%** |
| **All Included Critical Files** | **91.92%** | **77.11%** | **98.19%** | **92.73%** |

---

## 4. Build, TypeScript & Live Runtime Checks

- **`npm run lint` (`tsc --noEmit`):** `0` errors, strict TypeScript enabled, zero `any` usage in `server/` or `src/`.
- **`npm run build` (`vite build`):** Clean Vite production build outputting `dist/index.html` and code-split lazy bundles (`AnalyticsView`, `CaffeineView`, `ExamPlannerView`, `ReportsView`, `VerificationView`).
- **Live Server & SQLite Check (`http://127.0.0.1:3000`):** Verified live `/api/health` (`v4`), HTTP `401` enforcement, Helmet headers, Demo Scenario `r = +0.78`, Exam feasibility (`>=7h` sleep, `<=8h/day` study), multi-tenant isolation, and clean single-file SQLite storage (`data/dreamlog.db` only, zero `-wal`/`-shm` sidecars).
